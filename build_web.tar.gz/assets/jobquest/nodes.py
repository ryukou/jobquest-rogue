"""Slay the Spire風のラン進行 (pygame非依存の純ロジック).

フロアごとにノード (そうぐう/きょうてき/たからばこ/みせ) を提示し、
戦闘勝利後は 武器/おまもり/ひでんのしょ の3択報酬を出す。
"""

from __future__ import annotations

import random
from dataclasses import dataclass, replace

MAX_FLOOR = 10
RECRUIT_FLOOR = 3
GUARDIAN_FLOOR = 5


def theme_for(floor: int) -> str:
    if floor <= 3:
        return "grass"
    if floor <= 6:
        return "tech"
    return "ruin"


THEME_NAMES = {"grass": "そうげんの かいそう",
               "tech": "きかいの かいそう",
               "ruin": "いせきの かいそう"}


def enemy_scale(floor: int) -> float:
    return 1.0 + 0.16 * (floor - 1)


def reward_tier(floor: int) -> int:
    """1..4。エリート報酬は +1 される."""
    return min(4, 1 + (floor - 1) // 3)


GROUP_POOLS = {
    "grass": [["goblin"], ["goblin", "goblin"], ["goblin", "wolf"],
              ["wolf", "wolf"]],
    "tech": [["robot"], ["robot", "mutant"], ["mutant", "mutant"],
             ["robot", "robot", "mutant"]],
    "ruin": [["mage", "golem"], ["golem", "golem"],
             ["mage", "mage", "goblin"], ["mage", "robot", "robot"]],
}

ELITE_POOLS = {
    "grass": [["wolf", "wolf", "wolf"], ["goblin", "goblin", "goblin",
                                         "wolf"]],
    "tech": [["robot", "robot", "robot"], ["mutant", "mutant", "robot"]],
    "ruin": [["golem", "golem", "mage"], ["mage", "mage", "robot",
                                          "robot"]],
}


# ---------------------------------------------------------------------------
# ノード (フロアの選択肢)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Node:
    kind: str                # battle / elite / treasure / shop / event / boss
    label: str
    desc: str
    group: tuple[str, ...] = ()   # battle/elite/boss の敵構成
    boss_id: str | None = None
    sprite: str = ""              # カードに描く絵 (敵spriteかdecor名)
    route_id: int = -1            # RunMap内のノードid。単発生成では -1


def _battle_node(theme: str, rng: random.Random) -> Node:
    from jobquest.models import SPECIES

    group = tuple(rng.choice(GROUP_POOLS[theme]))
    return Node("battle", "そうぐう", "ふつうの てきと たたかう",
                group=group, sprite=SPECIES[group[0]].sprite)


def _elite_node(theme: str, rng: random.Random) -> Node:
    from jobquest.models import SPECIES

    group = tuple(rng.choice(ELITE_POOLS[theme]))
    return Node("elite", "きょうてき", "つよいてき。ほうしゅうも ごうか",
                group=group, sprite=SPECIES[group[0]].sprite)


def _event_node() -> Node:
    return Node("event", "イベント", "なにかが おこる みち",
                sprite="event")


def generate_nodes(floor: int, rng: random.Random) -> list[Node]:
    """フロアの選択肢 (1〜3個) を返す."""
    theme = theme_for(floor)
    if floor >= MAX_FLOOR:
        return [Node("boss", "まおうグラドス", "さいごの たたかい！",
                     group=("maou",), boss_id="maou", sprite="boss")]
    if floor == GUARDIAN_FLOOR:
        return [Node("boss", "ガーディアン",
                     "たおせば ガイが なかまになる",
                     group=("guardian",), boss_id="guardian",
                     sprite="guardian")]
    if floor == RECRUIT_FLOOR:
        return [Node("boss", "とらわれの ルナ",
                     "たおせば ルナが なかまになる",
                     group=("bandit",), boss_id="luna_join",
                     sprite="bandit")]
    if floor == 1:
        return [_battle_node(theme, rng)]

    nodes = [_battle_node(theme, rng)]
    extras = ["elite", "treasure", "shop", "event"]
    weights = [0.38 if floor >= 4 else 0.25, 0.25, 0.22, 0.15]
    for _ in range(2):
        kind = rng.choices(extras, weights=weights, k=1)[0]
        if kind == "elite" and not any(n.kind == "elite" for n in nodes):
            nodes.append(_elite_node(theme, rng))
        elif kind == "treasure" \
                and not any(n.kind == "treasure" for n in nodes):
            nodes.append(Node("treasure", "たからばこ",
                              "たたかわずに おたからを もらう",
                              sprite="chest"))
        elif kind == "shop" and not any(n.kind == "shop" for n in nodes):
            nodes.append(Node("shop", "みせ",
                              "ギルで そうびを かう", sprite="chest"))
        elif kind == "event" and not any(n.kind == "event" for n in nodes):
            nodes.append(_event_node())
    return nodes[:3]


# ---------------------------------------------------------------------------
# 分岐マップ (Slay the Spire風のルート)
# ---------------------------------------------------------------------------

@dataclass
class MapSpot:
    id: int
    floor: int
    lane: int
    node: Node
    next_ids: tuple[int, ...] = ()


class RunMap:
    def __init__(self, floors: dict[int, list[MapSpot]]) -> None:
        self._floors = floors
        self._by_id = {
            spot.id: spot
            for spots in floors.values()
            for spot in spots
        }

    def floor_nodes(self, floor: int) -> list[MapSpot]:
        return list(self._floors.get(floor, []))

    def start_choices(self) -> list[MapSpot]:
        return self.floor_nodes(1)

    def next_choices(self, spot_id: int | None) -> list[MapSpot]:
        if spot_id is None:
            return self.start_choices()
        spot = self._by_id[spot_id]
        return [self._by_id[next_id] for next_id in spot.next_ids]


def _route_node(node: Node, route_id: int) -> Node:
    return replace(node, route_id=route_id)


def _random_route_node(floor: int, rng: random.Random,
                       used_kinds: set[str] = frozenset()) -> Node:
    theme = theme_for(floor)
    if floor >= MAX_FLOOR:
        return Node("boss", "まおうグラドス", "さいごの たたかい！",
                    group=("maou",), boss_id="maou", sprite="boss")
    if floor == GUARDIAN_FLOOR:
        return Node("boss", "ガーディアン",
                    "たおせば ガイが なかまになる",
                    group=("guardian",), boss_id="guardian",
                    sprite="guardian")
    if floor == RECRUIT_FLOOR:
        return Node("boss", "とらわれの ルナ",
                    "たおせば ルナが なかまになる",
                    group=("bandit",), boss_id="luna_join",
                    sprite="bandit")
    if floor == 1:
        return _battle_node(theme, rng)
    choices = ("battle", "elite", "treasure", "shop", "event")
    weights = (0.38, 0.20 if floor >= 4 else 0.12, 0.18, 0.14, 0.18)
    kind = rng.choices(choices, weights=weights, k=1)[0]
    # "battle" 以外の特殊ノードは同フロア内で重複させない (選択が無意味になるため)
    if kind != "battle" and kind in used_kinds:
        kind = "battle"
    if kind == "battle":
        return _battle_node(theme, rng)
    if kind == "elite":
        return _elite_node(theme, rng)
    if kind == "treasure":
        return Node("treasure", "たからばこ",
                    "たたかわずに おたからを もらう", sprite="chest")
    if kind == "shop":
        return Node("shop", "みせ", "ギルで そうびを かう",
                    sprite="chest")
    return _event_node()


def generate_run_map(rng: random.Random) -> RunMap:
    floors: dict[int, list[MapSpot]] = {}
    next_id = 1
    for floor in range(1, MAX_FLOOR + 1):
        width = 1 if floor in (1, RECRUIT_FLOOR, GUARDIAN_FLOOR,
                               MAX_FLOOR) else 3
        spots: list[MapSpot] = []
        used_kinds: set[str] = set()
        for lane in range(width):
            node = _random_route_node(floor, rng, used_kinds)
            used_kinds.add(node.kind)
            node = _route_node(node, next_id)
            spots.append(MapSpot(next_id, floor, lane, node))
            next_id += 1
        floors[floor] = spots

    # イベントが全く無いとStSらしい未知マス感が薄いので、固定で1つ混ぜる。
    if not any(s.node.kind == "event"
               for floor in range(2, MAX_FLOOR)
               for s in floors[floor]):
        target = floors[2][1]
        target.node = _route_node(_event_node(), target.id)

    for floor in range(1, MAX_FLOOR):
        current = floors[floor]
        nxt = floors[floor + 1]
        for spot in current:
            if len(nxt) == 1 or len(current) == 1:
                spot.next_ids = tuple(s.id for s in nxt)
                continue
            lane_ids = [
                s.id for s in nxt
                if abs(s.lane - spot.lane) <= 1
            ]
            spot.next_ids = tuple(lane_ids)

    return RunMap(floors)


# ---------------------------------------------------------------------------
# 武器 / おまもり / ひでんのしょ (報酬)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Weapon:
    name: str
    atk: int = 0
    mag: int = 0
    spd: int = 0
    vit: int = 0

    @property
    def desc(self) -> str:
        parts = []
        for label, val in (("こうげき", self.atk), ("まりょく", self.mag),
                           ("すばやさ", self.spd), ("たいりょく", self.vit)):
            if val:
                parts.append(f"{label}+{val}")
        return " ".join(parts)


_WEAPON_ARCHETYPES = [
    # (tier別の名前, atk, mag, spd, vit) 数値はtier 1..4
    (("ブロンズソード", "アイアンソード", "ミスリルソード", "エクスカリバー"),
     (4, 7, 11, 16), (0, 0, 0, 0), (0, 0, 0, 0), (0, 0, 0, 0)),
    (("きのつえ", "まどうのつえ", "けんじゃのつえ", "ユグドラシル"),
     (0, 0, 0, 0), (4, 7, 11, 16), (0, 0, 0, 0), (0, 0, 0, 0)),
    (("ダガー", "スピードダガー", "かぜきりのやいば", "アサシンダガー"),
     (1, 2, 3, 5), (0, 0, 0, 0), (3, 5, 8, 12), (0, 0, 0, 0)),
    (("こんぼう", "ウォーハンマー", "グレートメイス", "ガイアクラッシャー"),
     (3, 5, 8, 12), (0, 0, 0, 0), (0, 0, 0, 0), (2, 3, 5, 7)),
]

TRINKETS = [
    ("HPのおまもり", "p_hp20"),
    ("ちからのおまもり", "p_atk25"),
    ("しんそくのおまもり", "p_spd25"),
    ("カウンターのおまもり", "p_counter"),
    ("かげのおまもり", "p_kage"),
    ("せんこうのおまもり", "p_sakigake"),
]

TOME_ABP = (15, 25, 40, 60)


@dataclass(frozen=True)
class Reward:
    kind: str        # weapon / trinket / tome
    name: str
    desc: str
    weapon: Weapon | None = None
    passive: str = ""
    abp: int = 0
    price: int = 0   # ショップ用


def make_weapon(tier: int, rng: random.Random) -> Weapon:
    tier = max(1, min(4, tier))
    names, atk, mag, spd, vit = rng.choice(_WEAPON_ARCHETYPES)
    i = tier - 1
    return Weapon(names[i], atk=atk[i], mag=mag[i], spd=spd[i], vit=vit[i])


def _one_reward(tier: int, rng: random.Random) -> Reward:
    from jobquest.jobs import ABILITIES

    roll = rng.random()
    if roll < 0.45:
        w = make_weapon(tier, rng)
        return Reward("weapon", w.name, w.desc, weapon=w,
                      price=60 + tier * 50)
    if roll < 0.75:
        name, pid = rng.choice(TRINKETS)
        return Reward("trinket", name, ABILITIES[pid].name + "を える",
                      passive=pid, price=80 + tier * 40)
    abp = TOME_ABP[max(1, min(4, tier)) - 1]
    return Reward("tome", "ひでんのしょ",
                  f"げんざいのジョブに ABP+{abp}", abp=abp,
                  price=50 + tier * 45)


def generate_rewards(tier: int, rng: random.Random,
                     count: int = 3) -> list[Reward]:
    """かぶりの少ない報酬候補を count 個返す."""
    out: list[Reward] = []
    for _ in range(24):
        if len(out) >= count:
            break
        r = _one_reward(tier, rng)
        if all(o.name != r.name for o in out):
            out.append(r)
    while len(out) < count:
        out.append(_one_reward(tier, rng))
    return out


_STAT_IDX = {"atk": 2, "mag": 3, "spd": 4, "vit": 5}

_TRINKET_STAT = {
    "p_atk25": "atk", "p_spd25": "spd", "p_kage": "spd", "p_sakigake": "spd",
    "p_hp20": "vit", "p_hp30": "vit", "p_counter": "atk",
}


def _weapon_score(ch, weapon) -> float:
    if weapon is None:
        return 0.0
    return sum(getattr(weapon, key, 0) * ch.job.mods[idx]
              for key, idx in _STAT_IDX.items())


def _trinket_score(ch, passive: str | None) -> float:
    key = _TRINKET_STAT.get(passive or "")
    return ch.job.mods[_STAT_IDX[key]] if key else 0.0


def _tome_score(ch, abp: int) -> tuple[bool, int]:
    """(このABPで ジョブレベルが あがるか, -げんざいのジョブレベル)."""
    from jobquest.jobs import JOBS

    old_lv = ch.job_level(ch.job_id)
    pts = ch.job_abp(ch.job_id) + abp
    new_lv = 1 + sum(1 for cost, _ in JOBS[ch.job_id].learnset if pts >= cost)
    return (new_lv > old_lv, -old_lv)


def pick_best_target(party, reward: Reward):
    """報酬をもっとも活かせるキャラを自動で選ぶ (スマホの手間を減らす)。

    武器/おまもりは装備差分によるステータス上昇量、ひでんのしょは
    ジョブレベルが上がるかどうかを基準に、いちばん恩恵の大きい相手を選ぶ。
    """
    if reward.kind == "weapon" and reward.weapon is not None:
        return max(party, key=lambda c: _weapon_score(c, reward.weapon)
                   - _weapon_score(c, c.weapon))
    if reward.kind == "trinket" and reward.passive:
        return max(party, key=lambda c: _trinket_score(c, reward.passive)
                   - _trinket_score(c, c.trinket))
    if reward.kind == "tome" and reward.abp:
        return max(party, key=lambda c: _tome_score(c, reward.abp))
    return party[0]


def apply_reward(ch, reward: Reward) -> list[str]:
    """報酬を対象キャラへ適用し、表示用メッセージを返す."""
    if reward.kind == "weapon" and reward.weapon is not None:
        ch.weapon = reward.weapon
        ch.hp = min(ch.hp, ch.max_hp)
        ch.mp = min(ch.mp, ch.max_mp)
        return [f"{ch.name}は 『{reward.name}』を そうびした！"]
    if reward.kind == "trinket" and reward.passive:
        ch.trinket = reward.passive
        ch.hp = min(ch.hp, ch.max_hp)
        ch.mp = min(ch.mp, ch.max_mp)
        return [f"{ch.name}は 『{reward.name}』を みにつけた！"]
    if reward.kind == "tome" and reward.abp:
        lines = [f"{ch.name}は 『{reward.name}』を よんだ！"]
        lines += ch.gain_abp(reward.abp)
        return lines
    return []


def full_restore(party) -> None:
    """戦闘後回復: 戦闘不能も含め HP/MP を最大まで戻す."""
    for ch in party:
        ch.flags.clear()
        ch.hp = ch.max_hp
        ch.mp = ch.max_mp
        ch.atb = 0.0


@dataclass(frozen=True)
class EventResult:
    lines: list[str]


def apply_event(party, inventory, floor: int,
                rng: random.Random) -> EventResult:
    """イベントマスの即時効果。戦闘せずに少しだけランを動かす."""
    roll = rng.random()
    if roll < 0.4:
        gil = 45 + floor * 18
        inventory.gil += gil
        lines = ["ふるい さいふを みつけた！",
                 f"{gil}ギルを てにいれた。"]
    elif roll < 0.75:
        abp = 5 + floor * 3
        lines = ["たびの ししょうに であった！",
                 f"ぜんいんの げんざいジョブに ABP+{abp}"]
        for ch in party:
            lines += ch.gain_abp(abp)
    else:
        lines = ["ちいさな いずみを みつけた！",
                 "HPとMPが ぜんかいふくした。"]
    full_restore(party)
    return EventResult(lines)
