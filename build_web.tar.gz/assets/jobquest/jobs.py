"""FF5-style job / ability master data (pygame非依存の純ロジック)."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Ability:
    """kind: 'action'(単発コマンド) / 'spell'(魔法) / 'passive'.

    魔法カテゴリメニュー (旧kind 'cmd_menu') は廃止。技/魔法は個別に
    コマンドスロット (models.ACTIVE_SLOTS) へセットして直接使う。
    """

    id: str
    name: str
    kind: str
    tag: str = ""       # phys / phys_all / magic / magic_all / heal / raise /
    #                     protect / haste / slow / steal / mug / charge / defend
    power: float = 0.0
    mp: int = 0
    target: str = "enemy"   # enemy / enemies / ally / allies / self / ally_ko
    school: str = ""        # spell の系統表示用: black / white / time
    desc: str = ""
    radius: int = 0         # >0 なら対象の周囲(px)も巻き込む円形範囲 (CT風)
    effect: str = ""        # 戦闘エフェクト: slash/fire/ice/bolt/heal/
    #                         burst/status/wind (未指定は物理=slash扱い)
    element: str = ""       # 属性ロジック: fire(やけど) / ice(ATB遅延) /
    #                         bolt(きかい特効)。engine.py が解決する
    family: str = ""        # スキルツリー: 同じfamilyのわざは 上位rankを
    #                         おぼえると コマンドスロットの中で自動的に
    #                         レベルアップして 置き換わる (models._collapse_families)
    rank: int = 0           # family内でのランク (1=無印 / 2=ラ / 3=ガ)


_ABILITY_LIST = [
    # --- ジョブコマンド / 技 ---
    Ability("tsuyogiri", "つよぎり", "action", tag="phys", power=1.8,
            desc="つよりょくな ぶつりこうげき", effect="slash"),
    Ability("tameru", "ためる", "action", tag="charge", target="self",
            desc="つぎの こうげきの いりょく2ばい", effect="status"),
    Ability("keri", "けり", "action", tag="phys_all", power=0.8,
            target="enemy", radius=140,
            desc="ねらったてきの まわりを まきこんで ける", effect="slash"),
    Ability("nusumu", "ぬすむ", "action", tag="steal",
            desc="てきから ギルを ぬすむ"),
    Ability("bundoru", "ぶんどる", "action", tag="mug", power=1.0,
            desc="こうげきしながら ぬすむ", effect="slash"),
    Ability("shuriken", "しゅりけん", "action", tag="phys", power=1.5,
            desc="しゅりけんを なげつける", effect="slash"),
    Ability("bunshin", "ぶんしん", "action", tag="bunshin", target="self",
            desc="ぶつりこうげきを 1かい かわす", effect="status"),
    # --- 黒魔法 (スキルツリー: 同じ系統は ファイア→ファイラ→ファイガ の
    #     ように 習得すると 自動でレベルアップして 同じスロットの中で
    #     置き換わる。属性ごとの追加効果は ランクが上がっても共通) ---
    Ability("fire", "ファイア", "spell", tag="magic", power=26, mp=4,
            school="black", effect="fire", element="fire",
            family="fire", rank=1, desc="ほのお: ついかで やけど"),
    Ability("fira", "ファイラ", "spell", tag="magic", power=58, mp=12,
            school="black", effect="fire", element="fire",
            family="fire", rank=2, desc="ほのお: ついかで やけど"),
    Ability("firaga", "ファイガ", "spell", tag="magic", power=100, mp=20,
            school="black", effect="fire", element="fire",
            family="fire", rank=3, desc="ほのお: ついかで やけど"),
    Ability("blizzard", "ブリザド", "spell", tag="magic", power=30, mp=5,
            school="black", effect="ice", element="ice",
            family="ice", rank=1, desc="こおり: てきの ATBを おくらせる"),
    Ability("blizzara", "ブリザラ", "spell", tag="magic_all", power=48, mp=16,
            school="black", target="enemies", effect="ice", element="ice",
            family="ice", rank=2,
            desc="こおり: ぜんたいの ATBを おくらせる"),
    Ability("blizzaga", "ブリザガ", "spell", tag="magic_all", power=80, mp=26,
            school="black", target="enemies", effect="ice", element="ice",
            family="ice", rank=3,
            desc="こおり: ぜんたいの ATBを おおきく おくらせる"),
    Ability("thunder", "サンダー", "spell", tag="magic", power=34, mp=6,
            school="black", effect="bolt", element="bolt",
            family="thunder", rank=1, desc="かみなり: きかいに とくこう"),
    Ability("thundara", "サンダラ", "spell", tag="magic", power=62, mp=14,
            school="black", effect="bolt", element="bolt",
            family="thunder", rank=2, desc="かみなり: きかいに とくこう"),
    Ability("thundaga", "サンダガ", "spell", tag="magic", power=105, mp=22,
            school="black", effect="bolt", element="bolt",
            family="thunder", rank=3,
            desc="かみなり: きかいに だいとくこう"),
    # --- 白魔法 (ケアル系もスキルツリーでレベルアップする) ---
    Ability("cure", "ケアル", "spell", tag="heal", power=30, mp=4,
            school="white", target="ally", effect="heal",
            family="cure", rank=1),
    Ability("cura", "ケアルラ", "spell", tag="heal", power=75, mp=10,
            school="white", target="ally", effect="heal",
            family="cure", rank=2),
    Ability("curaga", "ケアルガ", "spell", tag="heal", power=140, mp=18,
            school="white", target="ally", effect="heal",
            family="cure", rank=3),
    Ability("protes", "プロテス", "spell", tag="protect", mp=5,
            school="white", target="ally", effect="status"),
    Ability("raise", "レイズ", "spell", tag="raise", mp=16,
            school="white", target="ally_ko", effect="heal"),
    # --- 時空魔法 ---
    Ability("haste", "ヘイスト", "spell", tag="haste", mp=8,
            school="time", target="ally", effect="status"),
    Ability("slow", "スロウ", "spell", tag="slow", mp=6, school="time",
            effect="status"),
    Ability("meteo", "メテオ", "spell", tag="magic_all", power=90, mp=30,
            school="time", target="enemies", effect="burst"),
    # --- パッシブ ---
    Ability("p_hp20", "HP+20%", "passive", desc="さいだいHPが 20%あがる"),
    Ability("p_hp30", "HP+30%", "passive", desc="さいだいHPが 30%あがる"),
    Ability("p_atk25", "りょうてもち", "passive", desc="こうげきが 25%あがる"),
    Ability("p_spd25", "しんそく", "passive", desc="すばやさが 25%あがる"),
    Ability("p_counter", "カウンター", "passive",
            desc="ぶつりこうげきに はんげきする"),
    Ability("p_sakigake", "さきがけ", "passive",
            desc="せんとうかいしじ ATBまんたん"),
    Ability("p_kage", "かげのころも", "passive",
            desc="25%で ぶつりこうげきを かわす"),
]

ABILITIES: dict[str, Ability] = {a.id: a for a in _ABILITY_LIST}


@dataclass(frozen=True)
class Job:
    id: str
    name: str
    color: tuple[int, int, int]        # 服の色 (ドット絵用)
    mods: tuple[float, float, float, float, float, float]  # hp mp atk mag spd vit
    command: str = ""                  # ジョブ固有コマンドの ability id
    innate_spell: str = ""             # このジョブ中は無条件で使える魔法
    learnset: tuple[tuple[int, str], ...] = ()  # (必要ABP累計, ability id)


_JOB_LIST = [
    Job("suppin", "すっぴん", (168, 168, 176),
        (1.0, 1.0, 1.0, 1.0, 1.0, 1.0)),
    Job("knight", "ナイト", (88, 120, 216),
        (1.25, 0.7, 1.3, 0.7, 0.9, 1.25), command="tsuyogiri",
        learnset=((15, "p_hp20"), (40, "tsuyogiri"), (80, "p_atk25"))),
    Job("monk", "モンク", (232, 144, 72),
        (1.4, 0.5, 1.25, 0.6, 1.0, 1.1), command="tameru",
        learnset=((15, "keri"), (40, "p_counter"), (80, "p_hp30"))),
    Job("thief", "シーフ", (96, 192, 120),
        (1.0, 0.7, 1.0, 0.8, 1.4, 0.95), command="nusumu",
        learnset=((15, "p_spd25"), (40, "bundoru"), (80, "p_sakigake"))),
    Job("ninja", "にんじゃ", (64, 72, 104),
        (1.0, 0.6, 1.15, 0.7, 1.3, 0.9), command="shuriken",
        learnset=((20, "bunshin"), (45, "shuriken"), (90, "p_kage"))),
    # キャスターは固有コマンドを持たず、innate_spell と習得した魔法を
    # コマンドスロットへ個別にセットして戦う
    Job("black", "くろまどうし", (72, 64, 128),
        (0.8, 1.4, 0.7, 1.4, 1.0, 0.8),
        innate_spell="fire",
        learnset=((10, "blizzard"), (20, "thunder"), (35, "fira"),
                  (50, "blizzara"), (65, "thundara"), (80, "firaga"),
                  (95, "blizzaga"), (110, "thundaga"))),
    Job("white", "しろまどうし", (232, 224, 208),
        (0.85, 1.3, 0.75, 1.25, 1.0, 0.9),
        innate_spell="cure",
        learnset=((12, "protes"), (30, "cura"), (55, "raise"),
                  (75, "curaga"))),
    Job("time", "ときまどうし", (152, 104, 200),
        (0.8, 1.35, 0.7, 1.3, 1.1, 0.85),
        innate_spell="haste",
        learnset=((14, "slow"), (55, "meteo"))),
]

JOBS: dict[str, Job] = {j.id: j for j in _JOB_LIST}
JOB_ORDER = [j.id for j in _JOB_LIST]


@dataclass(frozen=True)
class Combo:
    """クロノトリガー風の連携技 (2人=ダブル / 3人=トリプル)。

    members はキャラ名の組。全員のATBが満タンのとき発動できる。
    ダメージは members の atk+mag 合計 × power で決まる。
    """

    id: str
    name: str
    members: tuple[str, ...]
    power: float
    mp: tuple[int, ...]  # 各メンバーの消費MP
    target: str = "enemy"
    radius: int = 0      # >0 なら対象の周囲(px)も巻き込む (CT風)
    effect: str = "slash"


COMBOS = [
    Combo("x_giri", "Ｘぎり", ("クリス", "ガイ"), 1.9, (0, 0)),
    Combo("kaenzan", "かえんざん", ("クリス", "ルナ"), 1.6, (0, 6),
          effect="fire"),
    Combo("shippu", "しっぷうけん", ("ルナ", "ガイ"), 1.0,
          (6, 0), target="enemies", effect="wind"),
    Combo("trinity", "トリニティアタック", ("クリス", "ルナ", "ガイ"), 1.5,
          (4, 12, 4), target="enemies", effect="burst"),
]
