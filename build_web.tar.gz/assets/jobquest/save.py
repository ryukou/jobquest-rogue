"""Save / load (pygame非依存).

ローグライク方式: 保存するのは「メタ進行」のみ。
- 各キャラのジョブABP / 現在ジョブ / 装備アビリティ (レベルは保存しない)
- ロボ解放フラグ / 最深到達フロア / 累計プレイ時間
死んでもジョブの熟練だけは残る、が引き継ぎの核。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from jobquest.models import Character

SAVE_PATH = Path(__file__).with_name("save.json")
VERSION = 3


def build_meta(party: list[Character], robo_unlocked: bool,
               best_floor: int, play_time: float,
               runs: int = 0, clears: int = 0) -> dict[str, Any]:
    return {
        "version": VERSION,
        "chars": {
            ch.name: {
                "abp": dict(ch.abp),
                "job_id": ch.job_id,
                "equipped": ch.equipped,
            }
            for ch in party
        },
        "robo_unlocked": robo_unlocked,
        "best_floor": int(best_floor),
        "play_time": int(play_time),
        "runs": int(runs),
        "clears": int(clears),
    }


def apply_meta(data: dict[str, Any],
               party: list[Character]) -> dict[str, Any]:
    """メタ進行をレベル1の新パーティへ反映し、フラグ類を返す."""
    chars = data.get("chars", {})
    for ch in party:
        row = chars.get(ch.name)
        if row is None:
            continue
        ch.abp = {k: int(v) for k, v in row.get("abp", {}).items()}
        ch.job_id = row.get("job_id", ch.job_id)
        ch.equipped = row.get("equipped")
        ch.hp = ch.max_hp
        ch.mp = ch.max_mp
    return {
        "robo_unlocked": bool(data.get("robo_unlocked")),
        "best_floor": int(data.get("best_floor", 0)),
        "play_time": int(data.get("play_time", 0)),
        "runs": int(data.get("runs", 0)),
        "clears": int(data.get("clears", 0)),
    }


def write(data: dict[str, Any], path: Path | None = None) -> None:
    (path or SAVE_PATH).write_text(
        json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")


def read(path: Path | None = None) -> dict[str, Any] | None:
    p = path or SAVE_PATH
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    if data.get("version") != VERSION:
        return None  # 旧形式 (RPG時代) は引き継がない
    return data


def exists(path: Path | None = None) -> bool:
    return read(path) is not None
