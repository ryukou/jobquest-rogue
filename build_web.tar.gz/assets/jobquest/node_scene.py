"""Card-choice run scenes: node selection, rewards, and shop."""

from __future__ import annotations

import random
from typing import Callable

import pygame

from jobquest import config as C
from jobquest import sfx, sprites, ui
from jobquest.models import Character, Inventory
from jobquest.nodes import (Node, Reward, apply_reward, generate_rewards,
                            reward_tier)


ConfirmCallback = Callable[[], None]


def _is_confirm(key: int) -> bool:
    return key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE)


def _is_cancel(key: int) -> bool:
    return key in (pygame.K_x, pygame.K_ESCAPE)


class NodeSelectScene:
    """One-floor route choice replacing walking exploration."""

    def __init__(self, floor: int, nodes: list[Node],
                 party: list[Character], inventory: Inventory,
                 rng: random.Random,
                 on_battle: Callable[[Node], None],
                 on_rewards: Callable[[list[Reward]], None],
                 on_shop: Callable[[list[Reward]], None],
                 on_menu: ConfirmCallback,
                 on_event: Callable[[Node], None] | None = None) -> None:
        self.floor = floor
        self.nodes = nodes
        self.party = party
        self.inventory = inventory
        self.rng = rng
        self.on_battle = on_battle
        self.on_rewards = on_rewards
        self.on_shop = on_shop
        self.on_menu = on_menu
        self.on_event = on_event
        self.index = 0
        self.time = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        key = event.key
        if key in (pygame.K_LEFT, pygame.K_UP):
            self.index = (self.index - 1) % len(self.nodes)
            sfx.play("cursor")
        elif key in (pygame.K_RIGHT, pygame.K_DOWN):
            self.index = (self.index + 1) % len(self.nodes)
            sfx.play("cursor")
        elif _is_confirm(key):
            sfx.play("confirm")
            self._choose(self.nodes[self.index])
        elif _is_cancel(key) or key == pygame.K_m:
            sfx.play("cancel")
            self.on_menu()

    def _choose(self, node: Node) -> None:
        if node.kind in ("battle", "elite", "boss"):
            self.on_battle(node)
        elif node.kind == "treasure":
            self.on_rewards(generate_rewards(reward_tier(self.floor),
                                             self.rng))
        elif node.kind == "shop":
            self.on_shop(generate_rewards(reward_tier(self.floor),
                                          self.rng, count=4))
        elif node.kind == "event" and self.on_event is not None:
            self.on_event(node)

    def update(self, dt: float) -> None:
        self.time += dt

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((18, 22, 34))
        self._draw_header(dst)
        self._draw_cards(dst)
        self._draw_party(dst)

    def _draw_header(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(20, 18, 920, 74)
        ui.draw_window(dst, rect)
        ui.text(dst, f"B{self.floor}F  つぎの みちを えらぶ",
                (rect.x + 22, rect.y + 12), 24, C.COLOR_TEXT_YELLOW)
        ui.text(dst, f"{self.inventory.gil}ギル    X:メニュー",
                (rect.right - 220, rect.y + 18), 20, C.COLOR_TEXT_DIM)

    def _draw_cards(self, dst: pygame.Surface) -> None:
        count = len(self.nodes)
        card_w = 260
        gap = 22
        start_x = (C.SCREEN_W - (card_w * count + gap * (count - 1))) // 2
        for i, node in enumerate(self.nodes):
            rect = pygame.Rect(start_x + i * (card_w + gap), 130,
                               card_w, 270)
            selected = i == self.index
            if selected:
                pygame.draw.rect(dst, C.COLOR_CURSOR, rect.inflate(10, 10),
                                 width=4, border_radius=8)
            ui.draw_window(dst, rect)
            ui.text_center(dst, node.label, (rect.centerx, rect.y + 36),
                           24, C.COLOR_TEXT_YELLOW if selected
                           else C.COLOR_TEXT)
            self._draw_node_icon(dst, node, (rect.centerx, rect.y + 126))
            for row, line in enumerate(_wrap(node.desc, 14)[:3]):
                ui.text_center(dst, line, (rect.centerx, rect.y + 204
                                           + row * 28), 18,
                               C.COLOR_TEXT_DIM)

    def _draw_node_icon(self, dst: pygame.Surface, node: Node,
                        center: tuple[int, int]) -> None:
        if node.kind == "event":
            x, y = center
            pygame.draw.circle(dst, (100, 90, 150), center, 42)
            pygame.draw.circle(dst, (220, 210, 255), center, 42, 3)
            ui.text_center(dst, "?", (x, y - 2), 58, C.COLOR_TEXT_YELLOW)
            return
        if node.sprite in ("chest", ""):
            x, y = center
            pygame.draw.rect(dst, (176, 112, 48), (x - 34, y - 24, 68, 48))
            pygame.draw.rect(dst, (240, 200, 88), (x - 34, y - 24, 68, 12))
            pygame.draw.rect(dst, (70, 50, 40), (x - 4, y - 6, 8, 18))
            return
        scale = 5 if node.kind == "boss" else 4
        img = sprites.enemy(node.sprite, scale)
        dst.blit(img, img.get_rect(center=center))

    def _draw_party(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(80, 440, 800, 150)
        ui.draw_window(dst, rect)
        for i, ch in enumerate(self.party):
            x = rect.x + 28 + i * 190
            img = sprites.chara(ch, 3)
            dst.blit(img, (x, rect.y + 26))
            ui.text(dst, ch.name, (x + 58, rect.y + 22), 20)
            ui.text(dst, f"HP {ch.hp}/{ch.max_hp}",
                    (x + 58, rect.y + 50), 16,
                    C.COLOR_TEXT if ch.alive else C.COLOR_HP_LOW)
            ui.text(dst, f"MP {ch.mp}/{ch.max_mp}",
                    (x + 58, rect.y + 74), 16, C.COLOR_MPNUM)


class RewardSelectScene:
    """Pick one reward, then who receives it."""

    def __init__(self, party: list[Character], rewards: list[Reward],
                 inventory: Inventory,
                 on_done: ConfirmCallback,
                 shop: bool = False) -> None:
        self.party = party
        self.rewards = rewards
        self.inventory = inventory
        self.on_done = on_done
        self.shop = shop
        self.mode = "reward"
        self.index = 0
        self.p_index = 0
        self.selected: Reward | None = None
        self.message: list[str] = []
        self.time = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        key = event.key
        if self.message:
            if _is_confirm(key) or _is_cancel(key):
                self.on_done()
            return
        if self.mode == "reward":
            self._handle_reward_key(key)
        elif self.mode == "target":
            self._handle_target_key(key)

    def _handle_reward_key(self, key: int) -> None:
        if key in (pygame.K_LEFT, pygame.K_UP):
            self.index = (self.index - 1) % len(self.rewards)
            sfx.play("cursor")
        elif key in (pygame.K_RIGHT, pygame.K_DOWN):
            self.index = (self.index + 1) % len(self.rewards)
            sfx.play("cursor")
        elif _is_confirm(key):
            reward = self.rewards[self.index]
            if self.shop and self.inventory.gil < reward.price:
                sfx.play("cancel")
                self.message = ["ギルが たりない！"]
                return
            sfx.play("confirm")
            self.selected = reward
            self.mode = "target"
        elif _is_cancel(key):
            sfx.play("cancel")
            self.on_done()

    def _handle_target_key(self, key: int) -> None:
        if key in (pygame.K_LEFT, pygame.K_UP):
            self.p_index = (self.p_index - 1) % len(self.party)
            sfx.play("cursor")
        elif key in (pygame.K_RIGHT, pygame.K_DOWN):
            self.p_index = (self.p_index + 1) % len(self.party)
            sfx.play("cursor")
        elif _is_confirm(key):
            reward = self.selected
            if reward is None:
                return
            if self.shop:
                self.inventory.gil -= reward.price
            self.message = apply_reward(self.party[self.p_index], reward)
            sfx.play("confirm")
            self.on_done()
        elif _is_cancel(key):
            sfx.play("cancel")
            self.mode = "reward"

    def update(self, dt: float) -> None:
        self.time += dt

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((20, 18, 34))
        title = "みせ" if self.shop else "ほうしゅう"
        rect = pygame.Rect(20, 18, 920, 68)
        ui.draw_window(dst, rect)
        ui.text(dst, title, (rect.x + 24, rect.y + 14), 26,
                C.COLOR_TEXT_YELLOW)
        ui.text(dst, f"{self.inventory.gil}ギル",
                (rect.right - 160, rect.y + 18), 20, C.COLOR_TEXT_DIM)
        self._draw_rewards(dst)
        self._draw_targets(dst)
        if self.message:
            self._draw_message(dst)

    def _draw_rewards(self, dst: pygame.Surface) -> None:
        count = len(self.rewards)
        card_w = 210 if count >= 4 else 250
        gap = 18
        start_x = (C.SCREEN_W - (card_w * count + gap * (count - 1))) // 2
        for i, reward in enumerate(self.rewards):
            rect = pygame.Rect(start_x + i * (card_w + gap), 120,
                               card_w, 230)
            selected = self.mode == "reward" and i == self.index
            if selected:
                pygame.draw.rect(dst, C.COLOR_CURSOR, rect.inflate(8, 8),
                                 width=4, border_radius=8)
            ui.draw_window(dst, rect)
            ui.text_center(dst, reward.name, (rect.centerx, rect.y + 34),
                           20, C.COLOR_TEXT_YELLOW)
            ui.text_center(dst, _kind_label(reward), (rect.centerx,
                           rect.y + 72), 16, C.COLOR_TEXT_DIM)
            for row, line in enumerate(_wrap(reward.desc, 12)[:3]):
                ui.text_center(dst, line, (rect.centerx, rect.y + 116
                                           + row * 26), 17)
            if self.shop:
                color = C.COLOR_TEXT if self.inventory.gil >= reward.price \
                    else C.COLOR_TEXT_DIM
                ui.text_center(dst, f"{reward.price}ギル",
                               (rect.centerx, rect.bottom - 26), 18, color)

    def _draw_targets(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(80, 400, 800, 170)
        ui.draw_window(dst, rect)
        label = "だれに わたす？" if self.mode == "target" \
            else "えらぶ"
        ui.text(dst, label, (rect.x + 22, rect.y + 12), 20,
                C.COLOR_TEXT_DIM)
        for i, ch in enumerate(self.party):
            x = rect.x + 34 + i * 185
            if self.mode == "target" and i == self.p_index:
                ui.cursor(dst, (x - 20, rect.y + 60))
            img = sprites.chara(ch, 3)
            dst.blit(img, (x, rect.y + 52))
            ui.text(dst, ch.name, (x + 56, rect.y + 48), 18)
            weapon = ch.weapon.name if ch.weapon else "ぶきなし"
            ui.text(dst, weapon, (x + 56, rect.y + 74), 15,
                    C.COLOR_TEXT_DIM)
            trinket = ch.trinket or "おまもりなし"
            ui.text(dst, trinket, (x + 56, rect.y + 96), 15,
                    C.COLOR_TEXT_DIM)

    def _draw_message(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(180, 248, 600, 110)
        ui.draw_window(dst, rect)
        for i, line in enumerate(self.message[:2]):
            ui.text_center(dst, line, (rect.centerx, rect.y + 34 + i * 34),
                           22)


class EventScene:
    """Show a non-combat event result, then continue the route."""

    def __init__(self, lines: list[str], on_done: ConfirmCallback) -> None:
        self.lines = lines
        self.on_done = on_done
        self.time = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and (
                _is_confirm(event.key) or _is_cancel(event.key)):
            sfx.play("confirm")
            self.on_done()

    def update(self, dt: float) -> None:
        self.time += dt

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((18, 20, 34))
        rect = pygame.Rect(90, 170, 780, 260)
        ui.draw_window(dst, rect)
        ui.text_center(dst, "イベント", (rect.centerx, rect.y + 42),
                       28, C.COLOR_TEXT_YELLOW)
        for i, line in enumerate(self.lines[:5]):
            ui.text_center(dst, line, (rect.centerx, rect.y + 96 + i * 34),
                           22)
        ui.text_center(dst, "A:すすむ", (rect.centerx, rect.bottom - 34),
                       18, C.COLOR_TEXT_DIM)


def _kind_label(reward: Reward) -> str:
    return {"weapon": "ぶき", "trinket": "おまもり",
            "tome": "ひでんのしょ"}.get(reward.kind, reward.kind)


def _wrap(text: str, width: int) -> list[str]:
    return [text[i:i + width] for i in range(0, len(text), width)] or [""]
