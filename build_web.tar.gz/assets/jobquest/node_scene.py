"""Card-choice run scenes: node selection, rewards, and shop."""

from __future__ import annotations

import math
import random
from typing import Callable

import pygame

from jobquest import config as C
from jobquest import sfx, sprites, touch, ui
from jobquest.models import Character, Inventory
from jobquest.nodes import (Node, Reward, RunMap, apply_reward,
                            generate_rewards, pick_best_target, reward_tier)

# ノードの種類ごとの色 (ルート先読みマップの点の色分けに使う)
NODE_COLOR = {
    "battle": (168, 176, 192), "elite": (232, 96, 96),
    "treasure": (240, 200, 88), "shop": (96, 176, 240),
    "event": (180, 140, 232), "boss": (232, 96, 200),
}

NODE_CHOICE_ORDER = {
    "battle": 0, "elite": 0, "boss": 0,
    "treasure": 1, "shop": 2, "event": 3,
}


ConfirmCallback = Callable[[], None]


def _is_confirm(key: int) -> bool:
    return key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE)


def _is_cancel(key: int) -> bool:
    return key in (pygame.K_x, pygame.K_ESCAPE)


class NodeSelectScene:
    """One-floor route choice replacing walking exploration."""

    def __init__(self, floor: int, nodes: list[Node],
                 party: list[Character], inventory: Inventory,
                 rng: random.Random,
                 on_battle: Callable[[Node], None],
                 on_rewards: Callable[[list[Reward]], None],
                 on_shop: Callable[[list[Reward]], None],
                 on_menu: ConfirmCallback,
                 on_event: Callable[[Node], None] | None = None,
                 run_map: RunMap | None = None) -> None:
        self.floor = floor
        self.nodes = sorted(nodes,
                            key=lambda node: NODE_CHOICE_ORDER.get(
                                node.kind, 9))
        self.party = party
        self.inventory = inventory
        self.rng = rng
        self.on_battle = on_battle
        self.on_rewards = on_rewards
        self.on_shop = on_shop
        self.on_menu = on_menu
        self.on_event = on_event
        self.run_map = run_map
        self.index = 0
        self.time = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        key = event.key
        if key in (pygame.K_LEFT, pygame.K_UP):
            self.index = (self.index - 1) % len(self.nodes)
            sfx.play("cursor")
        elif key in (pygame.K_RIGHT, pygame.K_DOWN):
            self.index = (self.index + 1) % len(self.nodes)
            sfx.play("cursor")
        elif _is_confirm(key):
            sfx.play("confirm")
            self._choose(self.nodes[self.index])
        elif _is_cancel(key) or key == pygame.K_m:
            sfx.play("cancel")
            self.on_menu()

    def _card_rects(self) -> list[pygame.Rect]:
        return ui.center_row_rects(len(self.nodes), 260, 270, 22, 144)

    _MENU_BTN = pygame.Rect(760, 26, 168, 58)

    def handle_tap(self, pos: tuple[float, float]) -> None:
        if self._MENU_BTN.collidepoint(pos):
            sfx.play("confirm")
            self.on_menu()
            return
        ui.tap_in_rects(pos, self._card_rects(), self.index,
                        lambda v: setattr(self, "index", v))

    def _choose(self, node: Node) -> None:
        if node.kind in ("battle", "elite", "boss"):
            self.on_battle(node)
        elif node.kind == "treasure":
            self.on_rewards(generate_rewards(reward_tier(self.floor),
                                             self.rng))
        elif node.kind == "shop":
            self.on_shop(generate_rewards(reward_tier(self.floor),
                                          self.rng, count=4))
        elif node.kind == "event" and self.on_event is not None:
            self.on_event(node)

    def update(self, dt: float) -> None:
        self.time += dt

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((18, 22, 34))
        self._draw_header(dst)
        self._draw_cards(dst)
        self._draw_party(dst)

    def _draw_header(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(20, 18, 920, 116)
        ui.draw_window(dst, rect)
        ui.text(dst, f"B{self.floor}F  つぎの みちを えらぶ",
                (rect.x + 22, rect.y + 12), 24, C.COLOR_TEXT_YELLOW)
        ui.text(dst, "このさきの みち", (rect.x + 340, rect.y + 18),
                14, C.COLOR_TEXT_DIM)
        ui.text(dst, f"{self.inventory.gil}ギル",
                (rect.right - 330, rect.y + 20), 20, C.COLOR_TEXT_DIM)
        ui.draw_window(dst, self._MENU_BTN)
        ui.text_center(dst, "メニュー", self._MENU_BTN.center, 22)
        self._draw_route_preview(dst, rect)

    # -- ルート先読み: いま選んでいる みちの「このさき」を小さく示す ------

    def _draw_route_preview(self, dst: pygame.Surface,
                            header: pygame.Rect) -> None:
        if self.run_map is None:
            return
        cols_x = (header.x + 70, header.x + 230, header.x + 390)
        y = header.bottom - 30

        col0 = [(n, n is self.nodes[self.index]) for n in self.nodes]
        self._draw_node_dots(dst, col0, cols_x[0], y)

        cur = self.nodes[self.index]
        col1 = self._next_spots(cur.route_id)
        self._draw_node_dots(dst, [(s.node, False) for s in col1],
                             cols_x[1], y)
        self._draw_links(dst, cols_x[0], y, len(col0), self.index,
                         cols_x[1], y, len(col1))

        if col1:
            col2 = self._next_spots(col1[0].node.route_id)
            self._draw_node_dots(dst, [(s.node, False) for s in col2],
                                 cols_x[2], y)
            self._draw_links(dst, cols_x[1], y, len(col1), 0,
                             cols_x[2], y, len(col2))

    def _next_spots(self, route_id: int) -> list:
        if self.run_map is None or route_id < 0:
            return []
        return self.run_map.next_choices(route_id)

    @staticmethod
    def _dot_positions(x: int, y: int, count: int) -> list[tuple[int, int]]:
        gap = 22
        top = y - (count - 1) * gap // 2
        return [(x, top + i * gap) for i in range(count)]

    def _draw_node_dots(self, dst: pygame.Surface,
                        entries: list[tuple[Node, bool]],
                        x: int, y: int) -> None:
        for (node, current), (px, py) in zip(
                entries, self._dot_positions(x, y, len(entries))):
            color = NODE_COLOR.get(node.kind, C.COLOR_TEXT_DIM)
            r = 9 if current else 6
            if current:
                bounce = int(abs(math.sin(self.time * 6)) * 3)
                pygame.draw.circle(dst, C.COLOR_CURSOR, (px, py), r + 3
                                   + bounce, 2)
            pygame.draw.circle(dst, color, (px, py), r)
            pygame.draw.circle(dst, (16, 16, 32), (px, py), r, 1)

    def _draw_links(self, dst: pygame.Surface, x0: int, y0: int, n0: int,
                    from_index: int, x1: int, y1: int, n1: int) -> None:
        if n0 == 0 or n1 == 0:
            return
        fx, fy = self._dot_positions(x0, y0, n0)[from_index]
        for tx, ty in self._dot_positions(x1, y1, n1):
            pygame.draw.line(dst, C.COLOR_TEXT_DIM, (fx, fy), (tx, ty), 1)

    def _draw_cards(self, dst: pygame.Surface) -> None:
        for i, (node, rect) in enumerate(zip(self.nodes,
                                             self._card_rects())):
            selected = i == self.index
            if selected:
                pygame.draw.rect(dst, C.COLOR_CURSOR, rect.inflate(10, 10),
                                 width=4, border_radius=8)
            ui.draw_window(dst, rect)
            ui.text_center(dst, node.label, (rect.centerx, rect.y + 36),
                           24, C.COLOR_TEXT_YELLOW if selected
                           else C.COLOR_TEXT)
            self._draw_node_icon(dst, node, (rect.centerx, rect.y + 126))
            for row, line in enumerate(_wrap(node.desc, 14)[:3]):
                ui.text_center(dst, line, (rect.centerx, rect.y + 204
                                           + row * 28), 18,
                               C.COLOR_TEXT_DIM)

    def _draw_node_icon(self, dst: pygame.Surface, node: Node,
                        center: tuple[int, int]) -> None:
        if node.kind == "event":
            x, y = center
            pygame.draw.circle(dst, (100, 90, 150), center, 42)
            pygame.draw.circle(dst, (220, 210, 255), center, 42, 3)
            ui.text_center(dst, "?", (x, y - 2), 58, C.COLOR_TEXT_YELLOW)
            return
        if node.sprite in ("chest", ""):
            x, y = center
            pygame.draw.rect(dst, (176, 112, 48), (x - 34, y - 24, 68, 48))
            pygame.draw.rect(dst, (240, 200, 88), (x - 34, y - 24, 68, 12))
            pygame.draw.rect(dst, (70, 50, 40), (x - 4, y - 6, 8, 18))
            return
        scale = 5 if node.kind == "boss" else 4
        img = sprites.enemy(node.sprite, scale)
        dst.blit(img, img.get_rect(center=center))

    def _draw_party(self, dst: pygame.Surface) -> None:
        width = touch.safe_width(80, 440, 150, 800)
        rect = pygame.Rect(80, 440, width, 150)
        ui.draw_window(dst, rect)
        spacing = min(190, (width - 40) // max(1, len(self.party)))
        for i, ch in enumerate(self.party):
            x = rect.x + 28 + i * spacing
            img = sprites.chara(ch, 3)
            dst.blit(img, (x, rect.y + 26))
            ui.text(dst, ch.name, (x + 58, rect.y + 18), 20,
                    ui.readable_color(ch.job.color))
            ui.text(dst, ch.job.name, (x + 58, rect.y + 42), 15,
                    C.COLOR_TEXT_DIM)
            ui.text(dst, f"HP {ch.hp}/{ch.max_hp}",
                    (x + 58, rect.y + 64), 16,
                    C.COLOR_TEXT if ch.alive else C.COLOR_HP_LOW)
            ui.text(dst, f"MP {ch.mp}/{ch.max_mp}",
                    (x + 58, rect.y + 86), 16, C.COLOR_MPNUM)


class RewardSelectScene:
    """Pick one reward, then choose who receives it.

    わたす相手は手動で選ぶ。ただし初期カーソルは nodes.pick_best_target が
    すすめる「いちばん恩恵の大きいキャラ」(★おすすめ表示) に合わせておく。
    """

    def __init__(self, party: list[Character], rewards: list[Reward],
                 inventory: Inventory,
                 on_done: ConfirmCallback,
                 shop: bool = False) -> None:
        self.party = party
        self.rewards = rewards
        self.inventory = inventory
        self.on_done = on_done
        self.shop = shop
        self.mode = "reward"          # reward / target
        self.index = 0
        self.p_index = 0
        self.recommended = 0          # ★おすすめ表示用
        self.selected: Reward | None = None
        self.message: list[str] = []
        self._done_after_message = False
        self.time = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        key = event.key
        if self.message:
            if _is_confirm(key) or _is_cancel(key):
                if self._done_after_message:
                    self.on_done()
                else:  # ギル不足など: 閉じて選びなおし
                    self.message = []
            return
        if self.mode == "reward":
            self._handle_reward_key(key)
        else:
            self._handle_target_key(key)

    def _handle_reward_key(self, key: int) -> None:
        if key in (pygame.K_LEFT, pygame.K_UP):
            self.index = (self.index - 1) % len(self.rewards)
            sfx.play("cursor")
        elif key in (pygame.K_RIGHT, pygame.K_DOWN):
            self.index = (self.index + 1) % len(self.rewards)
            sfx.play("cursor")
        elif _is_confirm(key):
            reward = self.rewards[self.index]
            if self.shop and self.inventory.gil < reward.price:
                sfx.play("cancel")
                self.message = ["ギルが たりない！"]
                self._done_after_message = False
                return
            sfx.play("confirm")
            self.selected = reward
            best = pick_best_target(self.party, reward)
            self.recommended = self.party.index(best)
            self.p_index = self.recommended
            self.mode = "target"
        elif _is_cancel(key):
            sfx.play("cancel")
            self.on_done()

    def _handle_target_key(self, key: int) -> None:
        if key in (pygame.K_LEFT, pygame.K_UP):
            self.p_index = (self.p_index - 1) % len(self.party)
            sfx.play("cursor")
        elif key in (pygame.K_RIGHT, pygame.K_DOWN):
            self.p_index = (self.p_index + 1) % len(self.party)
            sfx.play("cursor")
        elif _is_confirm(key):
            reward = self.selected
            if reward is None:
                return
            sfx.play("confirm")
            if self.shop:
                self.inventory.gil -= reward.price
            self.message = apply_reward(self.party[self.p_index], reward)
            self._done_after_message = True
        elif _is_cancel(key):
            sfx.play("cancel")
            self.mode = "reward"

    def _reward_rects(self) -> list[pygame.Rect]:
        count = len(self.rewards)
        card_w = 210 if count >= 4 else 250
        return ui.center_row_rects(count, card_w, 230, 18, 120)

    def _target_rects(self) -> list[pygame.Rect]:
        width = touch.safe_width(80, 400, 170, 800)
        spacing = min(185, (width - 68) // max(1, len(self.party)))
        return [pygame.Rect(80 + 10 + i * spacing, 400 + 40,
                           min(180, spacing - 4), 120)
                for i in range(len(self.party))]

    def handle_tap(self, pos: tuple[float, float]) -> None:
        if self.message:
            ui.post_key(pygame.K_z)
            return
        if self.mode == "reward":
            ui.tap_in_rects(pos, self._reward_rects(), self.index,
                            lambda v: setattr(self, "index", v))
        else:
            hit = ui.tap_in_rects(pos, self._target_rects(), self.p_index,
                                  lambda v: setattr(self, "p_index", v))
            if not hit:
                ui.post_key(pygame.K_x)  # 枠外タップで報酬選択にもどる

    def update(self, dt: float) -> None:
        self.time += dt

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((20, 18, 34))
        title = "みせ" if self.shop else "ほうしゅう"
        rect = pygame.Rect(20, 18, 920, 68)
        ui.draw_window(dst, rect)
        ui.text(dst, title, (rect.x + 24, rect.y + 14), 26,
                C.COLOR_TEXT_YELLOW)
        ui.text(dst, f"{self.inventory.gil}ギル",
                (rect.right - 160, rect.y + 18), 20, C.COLOR_TEXT_DIM)
        self._draw_rewards(dst)
        self._draw_targets(dst)
        if self.message:
            self._draw_message(dst)

    def _draw_rewards(self, dst: pygame.Surface) -> None:
        for i, (reward, rect) in enumerate(zip(self.rewards,
                                               self._reward_rects())):
            selected = self.mode == "reward" and i == self.index
            picked = self.mode == "target" and i == self.index
            if selected or picked:
                pygame.draw.rect(dst, C.COLOR_CURSOR, rect.inflate(8, 8),
                                 width=4, border_radius=8)
            ui.draw_window(dst, rect)
            ui.text_center(dst, reward.name, (rect.centerx, rect.y + 34),
                           20, C.COLOR_TEXT_YELLOW)
            ui.text_center(dst, _kind_label(reward), (rect.centerx,
                           rect.y + 72), 16, C.COLOR_TEXT_DIM)
            for row, line in enumerate(_wrap(reward.desc, 12)[:3]):
                ui.text_center(dst, line, (rect.centerx, rect.y + 116
                                           + row * 26), 17)
            if self.shop:
                color = C.COLOR_TEXT if self.inventory.gil >= reward.price \
                    else C.COLOR_TEXT_DIM
                ui.text_center(dst, f"{reward.price}ギル",
                               (rect.centerx, rect.bottom - 26), 18, color)

    def _draw_targets(self, dst: pygame.Surface) -> None:
        width = touch.safe_width(80, 400, 170, 800)
        rect = pygame.Rect(80, 400, width, 170)
        ui.draw_window(dst, rect)
        label = "だれに わたす？ (★=おすすめ)" if self.mode == "target" \
            else "げんざいの そうび"
        ui.text(dst, label, (rect.x + 22, rect.y + 12), 20,
                C.COLOR_TEXT_DIM)
        spacing = min(185, (width - 68) // max(1, len(self.party)))
        for i, ch in enumerate(self.party):
            x = rect.x + 34 + i * spacing
            if self.mode == "target" and i == self.p_index:
                ui.cursor(dst, (x - 20, rect.y + 60))
            img = sprites.chara(ch, 3)
            dst.blit(img, (x, rect.y + 52))
            name = ch.name
            if self.mode == "target" and i == self.recommended:
                name = "★" + name
            ui.text(dst, name, (x + 56, rect.y + 44), 16,
                    ui.readable_color(ch.job.color))
            ui.text(dst, ch.job.name, (x + 56, rect.y + 64), 13,
                    C.COLOR_TEXT_DIM)
            weapon = ch.weapon.name if ch.weapon else "ぶきなし"
            ui.text(dst, weapon, (x + 56, rect.y + 86), 14,
                    C.COLOR_TEXT_DIM)
            trinket = ch.trinket or "おまもりなし"
            ui.text(dst, trinket, (x + 56, rect.y + 106), 14,
                    C.COLOR_TEXT_DIM)

    def _draw_message(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(180, 248, 600, 110)
        ui.draw_window(dst, rect)
        for i, line in enumerate(self.message[:2]):
            ui.text_center(dst, line, (rect.centerx, rect.y + 34 + i * 34),
                           22)


class EventScene:
    """Show a non-combat event result, then continue the route."""

    def __init__(self, lines: list[str], on_done: ConfirmCallback) -> None:
        self.lines = lines
        self.on_done = on_done
        self.time = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and (
                _is_confirm(event.key) or _is_cancel(event.key)):
            sfx.play("confirm")
            self.on_done()

    def handle_tap(self, pos: tuple[float, float]) -> None:
        ui.post_key(pygame.K_z)

    def update(self, dt: float) -> None:
        self.time += dt

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((18, 20, 34))
        rect = pygame.Rect(90, 170, 780, 260)
        ui.draw_window(dst, rect)
        ui.text_center(dst, "イベント", (rect.centerx, rect.y + 42),
                       28, C.COLOR_TEXT_YELLOW)
        for i, line in enumerate(self.lines[:5]):
            ui.text_center(dst, line, (rect.centerx, rect.y + 96 + i * 34),
                           22)
        ui.text_center(dst, "タップ / Z: すすむ", (rect.centerx, rect.bottom - 34),
                       18, C.COLOR_TEXT_DIM)


def _kind_label(reward: Reward) -> str:
    return {"weapon": "ぶき", "trinket": "おまもり",
            "tome": "ひでんのしょ"}.get(reward.kind, reward.kind)


def _wrap(text: str, width: int) -> list[str]:
    return [text[i:i + width] for i in range(0, len(text), width)] or [""]
