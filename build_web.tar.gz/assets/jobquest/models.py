"""Characters, enemies, items (pygame非依存の純ロジック)."""

from __future__ import annotations

from dataclasses import dataclass, field

from jobquest.jobs import ABILITIES, JOBS, Ability, Job

# 戦闘に持ち込めるアクティブスキル (コマンド/魔法) のスロット数
ACTIVE_SLOTS = 4


def _collapse_families(ids: list[str]) -> list[str]:
    """スキルツリー表現: 同じ family のidが複数あれば 最高rankだけ残す.

    ファイア/ファイラ/ファイガのように、同じ系統の技は覚えるほど
    上位rankに「レベルアップ」して見える1つの技として扱いたいので、
    表示・スロット候補系のリストはすべてこれを通す。
    """
    best: dict[str, str] = {}
    for aid in ids:
        fam = ABILITIES[aid].family
        if not fam:
            continue
        cur = best.get(fam)
        if cur is None or ABILITIES[aid].rank > ABILITIES[cur].rank:
            best[fam] = aid
    result: list[str] = []
    seen_family: set[str] = set()
    for aid in ids:
        fam = ABILITIES[aid].family
        if not fam:
            result.append(aid)
            continue
        if fam in seen_family:
            continue
        seen_family.add(fam)
        result.append(best[fam])
    return result

# ---------------------------------------------------------------------------
# アイテム
# ---------------------------------------------------------------------------

ITEMS: dict[str, tuple[str, str, int]] = {
    # id: (名前, tag, power)
    "potion": ("ポーション", "heal", 60),
    "hi_potion": ("ハイポーション", "heal", 160),
    "ether": ("エーテル", "mp", 40),
}


class Inventory:
    def __init__(self, initial: dict[str, int] | None = None) -> None:
        self.counts: dict[str, int] = dict(initial or {})
        self.gil = 0

    def add(self, item_id: str, n: int = 1) -> None:
        self.counts[item_id] = self.counts.get(item_id, 0) + n

    def use(self, item_id: str) -> bool:
        if self.counts.get(item_id, 0) <= 0:
            return False
        self.counts[item_id] -= 1
        return True

    def listing(self) -> list[tuple[str, int]]:
        return [(iid, n) for iid, n in self.counts.items() if n > 0]


# ---------------------------------------------------------------------------
# 味方キャラクター
# ---------------------------------------------------------------------------

def exp_to_next(level: int) -> int:
    return level * level * 10


@dataclass
class BStats:
    hp: float
    mp: float
    atk: float
    mag: float
    spd: float
    vit: float


@dataclass
class Character:
    name: str
    base: BStats
    growth: BStats
    hair: tuple[int, int, int]
    level: int = 3
    exp: int = 0
    job_id: str = "suppin"
    abp: dict[str, int] = field(default_factory=dict)
    equipped: str | None = None       # サポート (パッシブ) アビリティ 1スロット
    # 戦闘に持ち込む技/魔法。ACTIVE_SLOTS個の固定スロット (Noneは空き)
    loadout: list[str | None] = field(default_factory=list)
    weapon: object | None = None      # ラン中の武器報酬 (そうび一式の一部)
    armor: object | None = None       # ラン中の防具報酬 (そうび一式の一部)
    trinket: str | None = None        # ラン中のおまもり報酬 (passive id)
    last_command: tuple[str, str] = ("attack", "")  # (kind, ability_id)
    last_sub: str = ""                # 直前に選んだ魔法/れんけいのid
    hp: int = 0
    mp: int = 0
    atb: float = 0.0
    flags: set[str] = field(default_factory=set)  # 戦闘中ステータス

    def __post_init__(self) -> None:
        self.hp = self.max_hp
        self.mp = self.max_mp
        if not self.loadout:
            self.loadout = [None] * ACTIVE_SLOTS
            self.autofill_loadout()

    # -- ステータス計算 ------------------------------------------------
    @property
    def job(self) -> Job:
        return JOBS[self.job_id]

    def _raw(self, key: str) -> float:
        return getattr(self.base, key) + getattr(self.growth, key) * self.level

    def _stat(self, key: str, idx: int) -> int:
        val = self._raw(key) * self.job.mods[idx]
        if self.weapon is not None:
            val += getattr(self.weapon, key, 0)
        if self.armor is not None:
            val += getattr(self.armor, key, 0)
        if key == "hp":
            if self.has_passive("p_hp30"):
                val *= 1.3
            elif self.has_passive("p_hp20"):
                val *= 1.2
        elif key == "atk" and self.has_passive("p_atk25"):
            val *= 1.25
        elif key == "spd" and self.has_passive("p_spd25"):
            val *= 1.25
        return max(1, int(val))

    @property
    def max_hp(self) -> int:
        return self._stat("hp", 0)

    @property
    def max_mp(self) -> int:
        return self._stat("mp", 1)

    @property
    def atk(self) -> int:
        return self._stat("atk", 2)

    @property
    def mag(self) -> int:
        return self._stat("mag", 3)

    @property
    def spd(self) -> int:
        return self._stat("spd", 4)

    @property
    def vit(self) -> int:
        return self._stat("vit", 5)

    @property
    def alive(self) -> bool:
        return self.hp > 0

    # -- ジョブ / アビリティ --------------------------------------------
    def job_abp(self, job_id: str) -> int:
        return self.abp.get(job_id, 0)

    def job_level(self, job_id: str) -> int:
        pts = self.job_abp(job_id)
        return 1 + sum(1 for cost, _ in JOBS[job_id].learnset if pts >= cost)

    def learned_ids(self, job_id: str) -> list[str]:
        pts = self.job_abp(job_id)
        return [aid for cost, aid in JOBS[job_id].learnset if pts >= cost]

    def all_learned(self) -> list[Ability]:
        """付替え可能な習得済みアビリティ (全ジョブぶん、重複なし)."""
        seen: list[Ability] = []
        for jid in JOBS:
            for aid in self.learned_ids(jid):
                ab = ABILITIES[aid]
                if ab not in seen:
                    seen.append(ab)
        return seen

    def has_passive(self, pid: str) -> bool:
        return (self.equipped == pid or self.trinket == pid
                or pid in self.learned_ids(self.job_id))

    # -- コマンドスロット (アクティブスキル最大 ACTIVE_SLOTS 個) ----------
    def active_pool(self) -> list[Ability]:
        """スロットにセットできる技/魔法の一覧。

        現在ジョブの固有コマンド・生得魔法に加え、全ジョブで習得済みの
        アクティブを自由にセットできる (魔法カテゴリの縛りは廃止)。
        ファイア/ファイラ/ファイガのような同系統 (family) の技は、
        習得済みの最高rankだけを残す (スキルツリーのレベルアップ表現)。
        """
        ids: list[str] = []
        if self.job.command:
            ids.append(self.job.command)
        if self.job.innate_spell:
            ids.append(self.job.innate_spell)
        for jid in JOBS:
            for aid in self.learned_ids(jid):
                if ABILITIES[aid].kind in ("action", "spell") \
                        and aid not in ids:
                    ids.append(aid)
        return [ABILITIES[a] for a in _collapse_families(ids)]

    def _family_in_loadout(self, family: str) -> bool:
        return any(aid is not None and ABILITIES[aid].family == family
                   for aid in self.loadout)

    def battle_commands(self) -> list[Ability]:
        """戦闘のコマンドカードに並ぶ、セット済みの技/魔法 (最大4)."""
        pool = {ab.id for ab in self.active_pool()}
        return [ABILITIES[aid] for aid in self.loadout
                if aid is not None and aid in pool]

    def set_slot(self, index: int, ability_id: str | None) -> None:
        """スロットへセット (None=はずす)。同じ技が他スロットにあれば外す."""
        if ability_id is not None:
            pool = {ab.id for ab in self.active_pool()}
            if ability_id not in pool:
                raise ValueError(f"cannot set unlearned ability: {ability_id}")
            for i, aid in enumerate(self.loadout):
                if aid == ability_id:
                    self.loadout[i] = None
        self.loadout[index] = ability_id

    def autofill_loadout(self) -> None:
        """空きスロットへ習得済みアクティブを前から詰める (初期化用)."""
        pool = [ab.id for ab in self.active_pool()]
        for aid in pool:
            if aid in self.loadout:
                continue
            if None not in self.loadout:
                break
            self.loadout[self.loadout.index(None)] = aid

    def _prune_loadout(self) -> None:
        """ジョブ変更などでセット不能になった技をスロットから外す."""
        pool = {ab.id for ab in self.active_pool()}
        self.loadout = [aid if aid in pool else None for aid in self.loadout]

    def change_job(self, job_id: str) -> None:
        self.job_id = job_id
        self._prune_loadout()
        # 新ジョブの固有コマンド/生得魔法は空きスロットへ自動セットする
        # (プレイヤーが「はずす」で空けた枠を勝手には埋めない方針だが、
        #  ジョブ変更直後にコマンドが無い事故を防ぐ)。同じ系統の技が
        # すでに (上位rankで) 入っていれば、そちらを優先して重複させない
        pool = {ab.id: ab for ab in self.active_pool()}
        for raw_aid in (self.job.command, self.job.innate_spell):
            if not raw_aid:
                continue
            fam = ABILITIES[raw_aid].family
            if fam and self._family_in_loadout(fam):
                continue
            if raw_aid in self.loadout:
                continue
            aid = raw_aid if raw_aid in pool else next(
                (pid for pid in pool if ABILITIES[pid].family == fam),
                raw_aid)
            if aid not in self.loadout and None in self.loadout:
                self.loadout[self.loadout.index(None)] = aid
        if not any(self.loadout):
            self.autofill_loadout()
        self.hp = min(self.hp, self.max_hp)
        self.mp = min(self.mp, self.max_mp)

    # -- 成長 ------------------------------------------------------------
    def gain_exp(self, amount: int) -> list[str]:
        lines: list[str] = []
        self.exp += amount
        while self.exp >= exp_to_next(self.level):
            self.exp -= exp_to_next(self.level)
            old_hp, old_mp = self.max_hp, self.max_mp
            self.level += 1
            self.hp = min(self.max_hp, self.hp + (self.max_hp - old_hp))
            self.mp = min(self.max_mp, self.mp + (self.max_mp - old_mp))
            lines.append(f"{self.name}は レベル{self.level}に あがった！")
        return lines

    def gain_abp(self, amount: int) -> list[str]:
        if not self.job.learnset:
            return []
        lines: list[str] = []
        before = set(self.learned_ids(self.job_id))
        old_lv = self.job_level(self.job_id)
        self.abp[self.job_id] = self.job_abp(self.job_id) + amount
        new_lv = self.job_level(self.job_id)
        if new_lv > old_lv:
            lines.append(
                f"{self.name}の {self.job.name}が ジョブレベル{new_lv}に！")
        for aid in self.learned_ids(self.job_id):
            if aid not in before:
                ab = ABILITIES[aid]
                lines.append(f"{self.name}は 『{ab.name}』を おぼえた！")
                if ab.kind not in ("action", "spell"):
                    continue
                # スキルツリー: 同じ系統の技がスロットにあれば、そのまま
                # 上位rankに置き換える (ファイア→ファイラ→ファイガ)
                upgraded = False
                if ab.family:
                    for i, cur_aid in enumerate(self.loadout):
                        if cur_aid is not None \
                                and ABILITIES[cur_aid].family == ab.family \
                                and ABILITIES[cur_aid].rank < ab.rank:
                            old_name = ABILITIES[cur_aid].name
                            self.loadout[i] = aid
                            lines.append(
                                f"『{old_name}』が 『{ab.name}』に "
                                "レベルアップした！")
                            upgraded = True
                            break
                if not upgraded and aid not in self.loadout \
                        and None in self.loadout:
                    self.loadout[self.loadout.index(None)] = aid
                    lines.append(f"『{ab.name}』を コマンドに セットした！")
        return lines


def make_chris(level: int = 1) -> Character:
    return Character("クリス",
                     BStats(40, 10, 10, 8, 10, 9),
                     BStats(9, 2, 1.8, 1.4, 0.9, 1.2),
                     hair=(240, 112, 56), job_id="knight", level=level)


def make_luna(level: int = 1) -> Character:
    return Character("ルナ",
                     BStats(34, 16, 7, 12, 10, 7),
                     BStats(7, 3, 1.2, 2.0, 1.0, 0.9),
                     hair=(248, 216, 120), job_id="black", level=level)


def make_guy(level: int = 1) -> Character:
    return Character("ガイ",
                     BStats(46, 8, 12, 5, 8, 11),
                     BStats(11, 1.5, 2.0, 0.8, 0.8, 1.4),
                     hair=(88, 64, 40), job_id="monk", level=level)


def make_party(level: int = 1) -> list[Character]:
    """1人プレイ専用: パーティはクリスのみ (仲間加入は一次廃止中)."""
    return [make_chris(level)]


# ---------------------------------------------------------------------------
# 敵
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Species:
    id: str
    name: str
    hp: int
    atk: int
    mag: int
    spd: int
    vit: int
    exp: int
    abp: int
    gil: int
    sprite: str                      # sprites.py のキー
    actions: tuple[tuple[str, int], ...]  # (action tag, weight)
    steal: str | None = None
    boss: bool = False
    desperation: str | None = None   # HP40%未満で使う大技
    machine: bool = False            # きかい: サンダー系 (bolt) が特効


SPECIES: dict[str, Species] = {s.id: s for s in [
    Species("goblin", "ゴブリン", 35, 11, 4, 9, 6, 8, 3, 15, "goblin",
            (("attack", 1),), steal="potion"),
    Species("wolf", "そうげんおおかみ", 30, 13, 4, 14, 5, 10, 4, 12, "wolf",
            (("attack", 1),), steal="potion"),
    Species("mage", "まどうし", 28, 7, 14, 9, 5, 14, 5, 30, "mage",
            (("attack", 2), ("fire", 3)), steal="ether"),
    Species("golem", "ストーンゴーレム", 95, 16, 4, 5, 15, 26, 7, 45, "golem",
            (("attack", 1),), steal="hi_potion"),
    Species("bandit", "ならずもの", 85, 16, 2, 11, 8, 25, 10, 50, "bandit",
            (("attack", 1),), steal="potion", boss=True),
    Species("maou", "まおうグラドス", 620, 21, 19, 12, 12, 300, 40, 1200,
            "boss", (("attack", 3), ("fira", 2), ("slow", 1)),
            steal="hi_potion", boss=True, desperation="meteo"),
    # --- 未来 (荒廃した世界) ---
    Species("mutant", "ミュータント", 52, 15, 6, 8, 8, 18, 6, 30, "mutant",
            (("attack", 1),), steal="potion"),
    Species("robot", "ガードボット", 45, 14, 12, 10, 10, 20, 6, 40, "robot",
            (("attack", 2), ("thunder", 1)), steal="ether", machine=True),
    Species("guardian", "ガーディアン", 360, 18, 15, 10, 14, 160, 25, 600,
            "guardian", (("attack", 3), ("thunder", 2)),
            steal="hi_potion", boss=True, desperation="fira", machine=True),
]}


@dataclass
class EnemyUnit:
    species: Species
    name: str
    scale: float = 1.0        # ローグライク: フロアに応じた強化倍率
    hp: int = 0
    mp: int = 999
    atb: float = 0.0
    flags: set[str] = field(default_factory=set)
    stolen: bool = False
    burn_left: int = 0    # やけど (fire属性) の残りダメージ回数
    burn_dmg: int = 0     # やけど1回あたりのダメージ

    def __post_init__(self) -> None:
        self.hp = self.max_hp

    @property
    def max_hp(self) -> int:
        return int(self.species.hp * self.scale)

    @property
    def atk(self) -> int:
        return int(self.species.atk * self.scale)

    @property
    def mag(self) -> int:
        return int(self.species.mag * self.scale)

    @property
    def spd(self) -> int:
        return int(self.species.spd * (1 + (self.scale - 1) * 0.3))

    @property
    def vit(self) -> int:
        return int(self.species.vit * self.scale)

    @property
    def exp(self) -> int:
        return int(self.species.exp * self.scale)

    @property
    def abp(self) -> int:
        return int(self.species.abp * (1 + (self.scale - 1) * 0.5))

    @property
    def gil(self) -> int:
        return int(self.species.gil * self.scale)

    @property
    def alive(self) -> bool:
        return self.hp > 0


def spawn_group(species_ids: list[str],
                scale: float = 1.0) -> list[EnemyUnit]:
    """同種が複数いれば A/B/C を付ける. scale はフロア強化倍率."""
    units: list[EnemyUnit] = []
    for sid in species_ids:
        sp = SPECIES[sid]
        dupes = [u for u in units if u.species.id == sid]
        suffix = ""
        if species_ids.count(sid) > 1:
            suffix = chr(ord("Ａ") + len(dupes))
        units.append(EnemyUnit(sp, sp.name + suffix, scale=scale))
    return units
