"""ATB battle scene: クロノトリガー風.

- エンカウント時のフィールド上の立ち位置がそのまま戦闘配置になる
- メッセージで止めない: 技名は上部バナーに流れ、ダメージは数字ポップアップ
- radius>0 の技は対象の周囲を巻き込む円形範囲 (CTのサイクロン式)
- ウェイト制 (メニュー中は時間停止)。config.BATTLE_ACTIVE でアクティブ制に
"""

from __future__ import annotations

import math
import random
from typing import Callable

import pygame

from jobquest import config as C
from jobquest import music, sfx, sprites, touch, ui
from jobquest.engine import ATB_MAX, BattleEngine, StepResult
from jobquest.jobs import Ability
from jobquest.models import Character, EnemyUnit

# タッチしやすい大型コマンド窓 (描画とタップ判定で共有)。
# 行の高さはスマホの推奨タップ領域 (48px以上) に合わせ、画面横幅を最大限使う。
# もどるボタンの安全領域とは touch.safe_width() で常に独立させる。
CMD_X, CMD_Y = 16, 374
CMD_MAX_W = 928
CMD_TOP = 40
CMD_ROW_H = 56
CMD_VISIBLE = 4
CMD_H = CMD_TOP + CMD_ROW_H * CMD_VISIBLE
TARGET_TAP_R = 84

# パーティ状況バー (コマンド窓のすぐ上、こちらも横幅いっぱいに使う)
STATUS_X, STATUS_Y = 16, 300
STATUS_MAX_W = 928
STATUS_H = 66

# コマンドを選んだ直後 (未確定) に技の詳細をプレビューする窓
PREVIEW_RECT = pygame.Rect(20, 16, 460, 122)

BANNER_TIME = 1.15
POPUP_TIME = 0.9
LUNGE_TIME = 0.35
END_DELAY = 1.0
PAGE_TIME = 1.4

# 立ち位置の画面内クランプ範囲 (下部はUIに重ならないように)
X_MIN, X_MAX = 70, 890
Y_MIN, Y_MAX = 95, 425

_TARGET_LABEL = {
    "enemy": "てき1たい", "enemies": "てき ぜんたい", "self": "じぶん",
    "ally": "みかた1にん", "ally_ko": "たおれた みかた",
}

# エンカウント地点からの散開オフセット (パーティ最大3人)。
# 画面上部のステータスバー (STATUS_Y〜) と重ならない高さに収める。
PARTY_SPREAD = [(0, 0), (-72, 20), (64, 26)]
ENEMY_SPREAD = [(0, 0), (-90, -40), (86, -40), (-50, 44), (56, 44)]


def _clamp_pos(x: float, y: float) -> tuple[int, int]:
    return (int(min(max(x, X_MIN), X_MAX)),
            int(min(max(y, Y_MIN), Y_MAX)))


class BattleScene:
    def __init__(self, engine: BattleEngine, background: pygame.Surface,
                 on_finish: Callable[[str], None],
                 ctx: dict | None = None) -> None:
        self.engine = engine
        self.bg = background
        self.on_finish = on_finish
        self.time = 0.0
        self.finished = False

        # 流れる演出 (ノンブロッキング)
        self.banners: list[str] = []
        self.banner_age = 0.0
        self.popups: list[list] = []      # [Popup, age]
        self.lunges: dict[int, float] = {}  # id(actor) -> age
        self.effects: list[list] = []     # [kind, x, y, age]
        self.shake = 0.0
        self._shake_rng = random.Random(3)
        self.end_delay = 0.0

        # 決着後のリザルト表示のみブロッキング
        self.state = "flow"               # flow / result
        self.pages: list[list[str]] = []
        self.page_timer = 0.0

        # コマンドメニュー (開いていてもATBは進む)
        self.hero: Character | None = None
        self.mode = "command"             # command / sub / target
        self.menu: list[tuple] = []
        self.index = 0
        self.sub: list[tuple] = []
        self.sub_index = 0
        # armed: タップで選択したコマンド/サブコマンドが「もう一度タップ/
        # 決定キーで発動できる」状態かどうか (誤操作防止の2ステップ確認)
        self.armed = False
        self.pending = None
        self.targets: list = []
        self.target_index = 0

        self.pos: dict[int, tuple[int, int]] = {}
        self.lunge_dir: dict[int, tuple[float, float]] = {}
        self.hp_gauge: dict[int, pygame.Rect] = {}  # 敵id -> HPゲージ矩形
        self._layout(ctx)

    # ------------------------------------------------------------------
    # 配置: エンカウント地点にそのまま散開する (CT風)
    # ------------------------------------------------------------------

    def _layout(self, ctx: dict | None) -> None:
        enemies = self.engine.enemies
        party = self.engine.party
        if ctx is not None:
            ppx, ppy = ctx["player"]
            epx, epy = ctx["enemy"]
        else:  # フォールバック (旧来の対面配置)
            ppx, ppy = 780, 240
            epx, epy = 200, 200
        # 接触エンカウントだと両者が重なるので最低距離まで押し離す
        dx, dy = epx - ppx, epy - ppy
        dist = math.hypot(dx, dy)
        if dist < 1:
            dx, dy, dist = -1.0, 0.0, 1.0
        min_sep = 200.0
        if dist < min_sep:
            epx = ppx + dx / dist * min_sep
            epy = ppy + dy / dist * min_sep
        for i, en in enumerate(enemies):
            ox, oy = ENEMY_SPREAD[i % len(ENEMY_SPREAD)]
            self.pos[id(en)] = _clamp_pos(epx + ox, epy + oy)
        for i, ch in enumerate(party):
            ox, oy = PARTY_SPREAD[i % len(PARTY_SPREAD)]
            self.pos[id(ch)] = _clamp_pos(ppx + ox, ppy + oy)

        def centroid(objs) -> tuple[float, float]:
            xs = [self.pos[id(o)][0] for o in objs]
            ys = [self.pos[id(o)][1] for o in objs]
            return sum(xs) / len(xs), sum(ys) / len(ys)

        e_cx, e_cy = centroid(enemies)
        p_cx, p_cy = centroid(party)
        for obj, tx, ty in ([(ch, e_cx, e_cy) for ch in party]
                            + [(en, p_cx, p_cy) for en in enemies]):
            x, y = self.pos[id(obj)]
            dist = math.hypot(tx - x, ty - y) or 1.0
            self.lunge_dir[id(obj)] = ((tx - x) / dist * 36,
                                       (ty - y) / dist * 36)

    # ------------------------------------------------------------------
    # 入力
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN or self.finished:
            return
        key = event.key
        confirm = key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE)
        cancel = key in (pygame.K_x, pygame.K_ESCAPE)

        if self.state == "result":
            if confirm:
                self._advance_page()
            return
        if self.hero is None:
            return
        if key in (pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT,
                   pygame.K_RIGHT):
            sfx.play("cursor")
        if self.mode == "command":
            if key == pygame.K_UP:
                self.index = (self.index - 1) % len(self.menu)
                self.armed = False
            elif key == pygame.K_DOWN:
                self.index = (self.index + 1) % len(self.menu)
                self.armed = False
            elif confirm:
                self._pick_command()
            elif cancel and self.armed:
                sfx.play("cancel")
                self.armed = False
        elif self.mode == "sub":
            if key == pygame.K_UP:
                self.sub_index = (self.sub_index - 1) % len(self.sub)
                self.armed = False
            elif key == pygame.K_DOWN:
                self.sub_index = (self.sub_index + 1) % len(self.sub)
                self.armed = False
            elif confirm:
                self._pick_sub()
            elif cancel:
                sfx.play("cancel")
                self._set_mode("command")
        elif self.mode == "target":
            if key in (pygame.K_UP, pygame.K_LEFT):
                self.target_index = (self.target_index - 1) % len(self.targets)
            elif key in (pygame.K_DOWN, pygame.K_RIGHT):
                self.target_index = (self.target_index + 1) % len(self.targets)
            elif confirm:
                sfx.play("confirm")
                self._execute(self.targets[self.target_index])
            elif cancel:
                sfx.play("cancel")
                self._set_mode("command")

    def _cmd_rect(self) -> pygame.Rect:
        width = touch.safe_width(CMD_X, CMD_Y, CMD_H, CMD_MAX_W)
        return pygame.Rect(CMD_X, CMD_Y, width, CMD_H)

    def handle_tap(self, pos: tuple[float, float]) -> None:
        """スマホ用: リザルト送り / コマンド行 / ターゲットの直接タップ。

        コマンド/サブコマンドの選択は「1タップ目で選択(プレビュー) ->
        同じ行をもう1タップで実行」の2ステップにして誤操作を防ぐ。
        """
        if self.finished:
            return
        if self.state == "result":
            ui.post_key(pygame.K_z)
            return
        if self.hero is None:
            return
        cmd_rect = self._cmd_rect()
        outside_cmd = not cmd_rect.collidepoint(pos)
        if self.mode == "target":
            for i, target in enumerate(self.targets):
                tx, ty = self.pos[id(target)]
                if math.hypot(pos[0] - tx, pos[1] - ty) <= TARGET_TAP_R:
                    ui.tap_select(self.target_index, i,
                                  lambda v: setattr(self, "target_index", v))
                    return
            if outside_cmd:
                ui.post_key(pygame.K_x)  # 枠外タップでキャンセル
            return
        entries = self.menu if self.mode == "command" else self.sub
        if outside_cmd or not entries:
            if outside_cmd and self.armed:
                ui.post_key(pygame.K_x)  # 選択中なら枠外タップでキャンセル
            elif self.mode == "sub" and outside_cmd:
                ui.post_key(pygame.K_x)  # サブメニューは枠外でメニューへ戻る
            return
        idx_attr = "index" if self.mode == "command" else "sub_index"
        cur = getattr(self, idx_attr)
        top = ui.visible_window(cur, len(entries), CMD_VISIBLE)
        row = int((pos[1] - (cmd_rect.y + CMD_TOP)) // CMD_ROW_H)
        if not 0 <= row < min(CMD_VISIBLE, len(entries) - top):
            return
        tapped = top + row
        if tapped == cur and self.armed:
            ui.post_key(pygame.K_z)  # 2回目のタップ: そのまま決定する
            return
        setattr(self, idx_attr, tapped)
        self.armed = True
        sfx.play("cursor")

    # ------------------------------------------------------------------
    # コマンドメニュー
    # ------------------------------------------------------------------

    @staticmethod
    def _has_basic_attack(hero: Character) -> bool:
        """たたかう と実質おなじ働き (無条件・MP0の物理技) を

        すでに持っているか。持っていれば「たたかう」は出さず統合する。
        """
        return any(ab.tag in ("phys", "phys_all", "mug") and ab.mp == 0
                  for ab in hero.battle_commands())

    def _set_mode(self, mode: str) -> None:
        self.mode = mode
        self.armed = False

    def _open_command(self, hero: Character) -> None:
        self.hero = hero
        self.menu = []
        if not self._has_basic_attack(hero):
            self.menu.append(("attack", None, "たたかう", True))
        for ab in hero.battle_commands():
            if ab.kind == "cmd_menu":
                enabled = bool(hero.known_spells(ab.school))
            else:
                enabled = hero.mp >= ab.mp
            self.menu.append(("ability", ab, ab.name, enabled))
        if self.engine.available_combos(hero):
            self.menu.append(("combo", None, "れんけい", True))
        self.menu.append(("defend", None, "ぼうぎょ", True))
        if self.engine.can_escape:  # ボス戦では行ごと出さない
            self.menu.append(("escape", None, "にげる", True))
        # 前ターンに選んだコマンドがまだあれば、そこにカーソルを合わせておく
        want_kind, want_id = hero.last_command
        self.index = self._find_entry(
            self.menu, lambda kind, payload: kind == want_kind
            and (payload.id if payload is not None else "") == want_id)
        self._set_mode("command")

    @staticmethod
    def _find_entry(entries: list[tuple], matches) -> int:
        """matches(kind, payload) が真になる最初のindex (無ければ0)."""
        for i, (kind, payload, _, _) in enumerate(entries):
            if matches(kind, payload):
                return i
        return 0

    def _close_menu(self) -> None:
        self.hero = None
        self._set_mode("command")

    def _pick_command(self) -> None:
        kind, payload, _, enabled = self.menu[self.index]
        if not enabled:
            sfx.play("cancel")
            return
        sfx.play("confirm")
        hero = self.hero
        hero.last_command = (kind, payload.id if payload is not None else "")
        if kind == "attack":
            self.pending = ("attack", None)
            self._open_target(self.engine.enemies)
        elif kind == "ability":
            ab: Ability = payload
            if ab.kind == "cmd_menu":
                self.sub = [
                    ("spell", sp, f"{sp.name}", hero.mp >= sp.mp)
                    for sp in hero.known_spells(ab.school)]
                self.sub_index = self._find_entry(
                    self.sub, lambda k, p: p.id == hero.last_sub)
                self._set_mode("sub")
            else:
                self._route_ability(ab)
        elif kind == "combo":
            self.sub = [("combo", cb, cb.name, True)
                        for cb in self.engine.available_combos(hero)]
            self.sub_index = self._find_entry(
                self.sub, lambda k, p: p.id == hero.last_sub)
            self._set_mode("sub")
        elif kind == "defend":
            self._present(self.engine.do_defend(hero))
            self._close_menu()
        elif kind == "escape":
            self._present(self.engine.do_escape(hero))
            self._close_menu()

    def _pick_sub(self) -> None:
        kind, payload, _, enabled = self.sub[self.sub_index]
        if not enabled:
            sfx.play("cancel")
            return
        sfx.play("confirm")
        self.hero.last_sub = payload.id
        if kind == "spell":
            self._route_ability(payload)
        elif kind == "combo":
            cb = payload
            self.pending = ("combo", cb)
            if cb.target == "enemies":
                self._execute(None)
            else:
                self._open_target(self.engine.enemies)

    def _route_ability(self, ab: Ability) -> None:
        self.pending = ("ability", ab)
        if ab.target == "self":
            self._execute(self.hero)
        elif ab.target == "enemies":
            self._execute(None)
        elif ab.target == "enemy":
            self._open_target(self.engine.enemies)
        elif ab.target == "ally":
            self._open_target(self.engine.party)
        elif ab.target == "ally_ko":
            ko = [c for c in self.engine.party if not c.alive]
            self._open_target(ko or self.engine.party, allow_ko=True)

    def _open_target(self, pool: list, allow_ko: bool = False) -> None:
        self.targets = [t for t in pool if allow_ko or t.alive]
        if not self.targets:
            self._set_mode("command")
            return
        self.target_index = 0
        self._set_mode("target")

    def _pending_radius(self) -> int:
        if self.pending is None:
            return 0
        kind, payload = self.pending
        if kind in ("ability", "combo"):
            return getattr(payload, "radius", 0)
        return 0

    def _area_group(self, target: EnemyUnit) -> list[EnemyUnit]:
        radius = self._pending_radius()
        tx, ty = self.pos[id(target)]
        return [e for e in self.engine.enemies if e.alive
                and math.hypot(self.pos[id(e)][0] - tx,
                               self.pos[id(e)][1] - ty) <= radius]

    def _execute(self, target) -> None:
        kind, payload = self.pending
        eng = self.engine
        # アクティブ制: 選択中に対象が倒れていたら生存者へ振り替える
        if isinstance(target, EnemyUnit) and not target.alive:
            alive = [e for e in eng.enemies if e.alive]
            if not alive:
                self._close_menu()
                return
            target = alive[0]
        group = None
        if isinstance(target, EnemyUnit) and self._pending_radius() > 0:
            group = self._area_group(target)
        if kind == "attack":
            res = eng.do_attack(self.hero, target)
        elif kind == "ability":
            res = eng.do_ability(self.hero, payload, target, group=group)
        elif kind == "combo":
            res = eng.do_combo(payload, target, group=group)
        self._present(res)
        self._close_menu()

    # ------------------------------------------------------------------
    # ノンブロッキング演出
    # ------------------------------------------------------------------

    def _present(self, res: StepResult) -> None:
        self.banners.extend(res.lines)
        for pop in res.popups:
            self.popups.append([pop, 0.0])
            if pop.kind in ("dmg", "heal", "miss"):
                x, y = self.pos.get(id(pop.target), (480, 300))
                kind = res.effect or ("heal" if pop.kind == "heal"
                                      else "slash")
                self.effects.append([kind, x, y, 0.0])
            if pop.kind == "dmg" and pop.text.isdigit() \
                    and int(pop.text) >= 60:
                self.shake = max(self.shake, 0.3)
        if res.effect == "burst":
            self.shake = max(self.shake, 0.45)
        if res.actor is not None:
            self.lunges[id(res.actor)] = 0.0
        kinds = {p.kind for p in res.popups}
        if any("となえた" in ln or "れんけい" in ln for ln in res.lines):
            sfx.play("magic")
        if "dmg" in kinds:
            sfx.play("hit")
        elif "heal" in kinds or "mp" in kinds:
            sfx.play("heal")
        elif "miss" in kinds:
            sfx.play("miss")

    # ------------------------------------------------------------------
    # 更新
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        self.time += dt
        if self.finished:
            return
        # 演出の経過
        if self.banners:
            self.banner_age += dt
            limit = BANNER_TIME if len(self.banners) <= 3 else 0.55
            if self.banner_age >= limit:
                self.banners.pop(0)
                self.banner_age = 0.0
        for entry in self.popups:
            entry[1] += dt
        self.popups = [e for e in self.popups if e[1] < POPUP_TIME]
        for eff in self.effects:
            eff[3] += dt
        self.effects = [e for e in self.effects if e[3] < 0.5]
        self.shake = max(0.0, self.shake - dt)
        for key in list(self.lunges):
            self.lunges[key] += dt
            if self.lunges[key] > LUNGE_TIME:
                del self.lunges[key]

        if self.state == "result":
            self.page_timer += dt
            if self.page_timer >= PAGE_TIME:
                self._advance_page()
            return

        outcome = self.engine.outcome
        if outcome:
            self._close_menu()
            self.end_delay += dt
            if self.end_delay >= END_DELAY:
                self._enter_result(outcome)
            return

        # ウェイト制: メニューを開いている間は時間が止まる
        # (BATTLE_ACTIVE=True ならCT準拠のアクティブ制)
        if C.BATTLE_ACTIVE or self.hero is None:
            for res in self.engine.tick(dt):
                self._present(res)

        if self.hero is not None and not self.hero.alive:
            self._close_menu()
        if self.hero is not None and self.mode == "target":
            self.targets = [t for t in self.targets
                            if not isinstance(t, EnemyUnit) or t.alive]
            if not self.targets:
                self._set_mode("command")
            else:
                self.target_index %= len(self.targets)
        if self.hero is None and self.engine.ready:
            self._open_command(self.engine.ready[0])

    def _enter_result(self, outcome: str) -> None:
        self.state = "result"
        self.page_timer = 0.0
        music.stop(300)  # ジングルを聞かせるためBGMを止める
        if outcome == "victory":
            sfx.play("victory")
            lines = self.engine.victory_lines()
        elif outcome == "defeat":
            sfx.play("gameover")
            lines = ["ぜんめつしてしまった…"]
        else:
            lines = ["うまく にげきれた！"]
        self.pages = [lines[i:i + 2] for i in range(0, len(lines), 2)]

    def _advance_page(self) -> None:
        self.page_timer = 0.0
        if self.pages:
            self.pages.pop(0)
        if not self.pages:
            self.finished = True
            self.on_finish(self.engine.outcome)

    # ------------------------------------------------------------------
    # 描画
    # ------------------------------------------------------------------

    def _lunge_offset(self, obj: object) -> tuple[int, int]:
        age = self.lunges.get(id(obj))
        if age is None:
            return 0, 0
        k = math.sin(math.pi * age / LUNGE_TIME)
        dx, dy = self.lunge_dir.get(id(obj), (0, 0))
        return int(dx * k), int(dy * k)

    def draw(self, dst: pygame.Surface) -> None:
        ox = oy = 0
        if self.shake > 0:
            amp = int(self.shake * 14)
            ox = self._shake_rng.randint(-amp, amp)
            oy = self._shake_rng.randint(-amp, amp)
        dst.fill((10, 10, 20))
        dst.blit(self.bg, (ox, oy))

        for en in self.engine.enemies:
            if not en.alive:
                continue
            scale = 6 if en.species.boss else 4
            img = sprites.enemy(en.species.sprite, scale)
            x, y = self.pos[id(en)]
            lx, ly = self._lunge_offset(en)
            bob = int(math.sin(self.time * 2.4 + (id(en) % 7)) * 3)
            rect = img.get_rect(center=(x + lx, y + ly + bob))
            dst.blit(img, rect)
            ratio = en.hp / en.max_hp
            gauge_rect = pygame.Rect(rect.centerx - 32, rect.bottom + 4,
                                     64, 8)
            self.hp_gauge[id(en)] = gauge_rect
            ui.gauge(dst, gauge_rect, ratio, ui.hp_color(ratio))
            ui.text_center(dst, f"{en.hp}/{en.max_hp}",
                           (gauge_rect.centerx, gauge_rect.bottom + 10), 13)
        for ch in self.engine.party:
            img = sprites.chara(ch, 4)
            x, y = self.pos[id(ch)]
            lx, ly = self._lunge_offset(ch)
            if not ch.alive:
                img = pygame.transform.rotate(img, 90)
                img.set_alpha(120)
            elif self.hero is ch:
                y -= int(abs(math.sin(self.time * 6)) * 6) + 4
            dst.blit(img, img.get_rect(center=(x + lx, y + ly)))

        self._draw_effects(dst)
        self._draw_popups(dst)
        self._draw_status(dst)
        if self.state == "result":
            self._draw_result(dst)
            return
        if self.hero is not None:
            if self.mode == "command":
                self._draw_menu(dst, self.menu, self.index)
                self._draw_preview(dst, self.menu, self.index)
            elif self.mode == "sub":
                self._draw_menu(dst, self.sub, self.sub_index, mp_hint=True)
                self._draw_preview(dst, self.sub, self.sub_index)
            elif self.mode == "target":
                self._draw_menu(dst, self.menu, self.index)
                self._draw_target_cursor(dst)
        if self.banners:
            self._draw_banner(dst)

    def _draw_effects(self, dst: pygame.Surface) -> None:
        for kind, x, y, age in self.effects:
            t = min(1.0, age / 0.45)
            if kind == "slash":
                arm = int(52 * math.sin(math.pi * t))
                for sx, sy in ((1, 1), (1, -1)):
                    pygame.draw.line(dst, (255, 255, 255),
                                     (x - arm * sx, y - arm * sy),
                                     (x + arm * sx, y + arm * sy), 3)
            elif kind == "fire":
                for i in range(6):
                    ang = i * math.tau / 6 + t * 2.5
                    r = 10 + 34 * t
                    col = (255, 120, 40) if i % 2 else (255, 210, 80)
                    size = max(2, int(9 * (1 - t)))
                    pygame.draw.circle(
                        dst, col, (int(x + math.cos(ang) * r),
                                   int(y + math.sin(ang) * r)), size)
            elif kind == "ice":
                for i in range(5):
                    sx = x - 26 + i * 13
                    sy = y + 24 - int(58 * t) + (i % 2) * 8
                    pygame.draw.rect(dst, (170, 225, 255),
                                     (sx, sy, 4, 12))
                    pygame.draw.rect(dst, (255, 255, 255), (sx + 1, sy, 1, 12))
            elif kind == "bolt":
                if t < 0.6 and int(age * 30) % 2 == 0:
                    pts = []
                    for i in range(7):
                        yy = y - 100 + i * 17
                        xx = x + (-9 if i % 2 else 9)
                        pts.append((xx, yy))
                    pts.append((x, y))
                    pygame.draw.lines(dst, (255, 240, 120), False, pts, 4)
                    pygame.draw.lines(dst, (255, 255, 255), False, pts, 1)
            elif kind == "heal":
                for i in range(6):
                    sx = x - 26 + i * 11
                    sy = y + 14 - int(46 * t) - (i % 3) * 7
                    pygame.draw.line(dst, (150, 255, 170),
                                     (sx - 3, sy), (sx + 3, sy), 2)
                    pygame.draw.line(dst, (150, 255, 170),
                                     (sx, sy - 3), (sx, sy + 3), 2)
            elif kind == "burst":
                for rr in (int(70 * t), max(0, int(70 * t) - 16)):
                    if rr > 2:
                        pygame.draw.circle(dst, (255, 140, 60), (x, y),
                                           rr, 3)
                        pygame.draw.circle(dst, (255, 230, 120), (x, y),
                                           max(2, rr - 6), 2)
            elif kind == "wind":
                for i in range(3):
                    sx = int(x - 50 + 120 * t)
                    sy = y - 14 + i * 14
                    pygame.draw.arc(dst, (170, 255, 230),
                                    (sx - 20, sy - 8, 40, 16),
                                    0.4, 2.7, 2)
            elif kind == "status":
                r = 20 + int(14 * math.sin(math.pi * t))
                pygame.draw.circle(dst, (150, 190, 255), (x, y), r, 2)

    def _draw_popups(self, dst: pygame.Surface) -> None:
        for pop, age in self.popups:
            x, y = self.pos.get(id(pop.target), (480, 300))
            rise = int(age * 44)
            color = {"dmg": C.COLOR_DMG, "heal": C.COLOR_HEAL,
                     "mp": C.COLOR_MPNUM, "miss": C.COLOR_MISS}[pop.kind]
            ui.text_center(dst, pop.text, (x, y - 46 - rise), 28, color)

    def _draw_banner(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(230, 14, 500, 46)
        ui.draw_window(dst, rect)
        ui.text_center(dst, self.banners[0],
                       (rect.centerx, rect.centery), 22)

    def _draw_result(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(20, 16, 920, 84)
        ui.draw_window(dst, rect)
        if self.pages:
            for i, line in enumerate(self.pages[0]):
                ui.text(dst, line, (rect.x + 24, rect.y + 12 + i * 30), 22)

    def _status_rect(self) -> pygame.Rect:
        # 幅を touch.SAFE_ZONE (もどるボタン) の手前で止め、重ならないようにする
        width = touch.safe_width(STATUS_X, STATUS_Y, STATUS_H, STATUS_MAX_W)
        return pygame.Rect(STATUS_X, STATUS_Y, width, STATUS_H)

    def _draw_status(self, dst: pygame.Surface) -> None:
        rect = self._status_rect()
        ui.draw_window(dst, rect)
        party = self.engine.party
        col_w = min(300, rect.width // max(1, len(party)))
        gauge_w = 110
        for i, ch in enumerate(party):
            x = rect.x + i * col_w + 16
            y = rect.y + 8
            color = ui.readable_color(ch.job.color) \
                if ch.alive else C.COLOR_TEXT_DIM
            if ch in self.engine.ready:
                ui.cursor(dst, (rect.x + i * col_w + 2, y + 2))
            ui.text(dst, ch.name, (x, y), 19, color)
            ui.text(dst, ch.job.name, (x + 92, y + 3), 13, C.COLOR_TEXT_DIM)
            hp_ratio = ch.hp / ch.max_hp
            ui.text(dst, f"HP{ch.hp:4d}", (x, y + 24), 14,
                    ui.hp_color(hp_ratio) if ch.alive else C.COLOR_HP_LOW)
            ui.gauge(dst, pygame.Rect(x + 74, y + 27, gauge_w, 7),
                     hp_ratio, ui.hp_color(hp_ratio))
            ui.text(dst, f"MP{ch.mp:3d}", (x, y + 42), 13, C.COLOR_MPNUM)
            full = ch.atb >= ATB_MAX
            ui.gauge(dst, pygame.Rect(x + 74, y + 43, gauge_w, 9),
                     ch.atb / ATB_MAX, C.COLOR_ATB_FULL if full else C.COLOR_ATB)

    def _draw_menu(self, dst: pygame.Surface, entries: list,
                   index: int, mp_hint: bool = False) -> None:
        rect = self._cmd_rect()
        ui.draw_window(dst, rect)
        if self.hero:
            ui.text(dst, f"{self.hero.name} [{self.hero.job.name}]",
                    (rect.x + 18, rect.y + 10), 19,
                    ui.readable_color(self.hero.job.color))
        top = ui.visible_window(index, len(entries), CMD_VISIBLE)
        for row, entry in enumerate(entries[top:top + CMD_VISIBLE]):
            kind, payload, label, enabled = entry
            y = rect.y + CMD_TOP + row * CMD_ROW_H
            if top + row == index:
                ui.cursor(dst, (rect.x + 16, y + 16))
            color = C.COLOR_TEXT if enabled else C.COLOR_TEXT_DIM
            ui.text(dst, label, (rect.x + 46, y + 12), 27, color)
            if mp_hint and kind == "spell":
                ui.text(dst, f"MP{payload.mp:2d}", (rect.right - 90, y + 16),
                        20, C.COLOR_MPNUM)

    def _draw_target_cursor(self, dst: pygame.Surface) -> None:
        target = self.targets[self.target_index]
        affected = [target]
        if isinstance(target, EnemyUnit) and self._pending_radius() > 0:
            affected = self._area_group(target)
        bounce = int(abs(math.sin(self.time * 8)) * 6)
        for obj in affected:
            x, y = self.pos[id(obj)]
            main = obj is target
            px = x - (56 if isinstance(obj, EnemyUnit) else -48)
            off = bounce if main else 2
            size = 14 if main else 10
            pygame.draw.polygon(
                dst, C.COLOR_CURSOR,
                [(px - off, y - size * 0.7), (px - off, y + size * 0.7),
                 (px + size - off, y)])
        if self.pending is not None:
            kind, payload = self.pending
            for obj in affected:
                preview = self.engine.preview_damage(self.hero, kind,
                                                     payload, obj)
                if preview is not None:
                    self._draw_damage_preview(dst, obj, *preview)
        box = pygame.Rect(20, 16, 300, 46)
        ui.draw_window(dst, box)
        suffix = "たち" if len(affected) > 1 else ""
        name_color = ui.readable_color(target.job.color) \
            if isinstance(target, Character) else C.COLOR_TEXT_YELLOW
        ui.text(dst, target.name + suffix, (box.x + 20, box.y + 9), 22,
                name_color)

    def _draw_damage_preview(self, dst: pygame.Surface, target: EnemyUnit,
                             lo: int, hi: int) -> None:
        """ねらったダメージ量ぶん、HPゲージの右側を赤くハイライトする."""
        gauge = self.hp_gauge.get(id(target))
        if gauge is None:
            return
        avg = (lo + hi) / 2
        cur_ratio = target.hp / target.max_hp
        after_ratio = max(0.0, target.hp - avg) / target.max_hp
        x0 = gauge.x + int(after_ratio * gauge.width)
        x1 = gauge.x + int(cur_ratio * gauge.width)
        if x1 > x0:
            flash = int(abs(math.sin(self.time * 6)) * 70) + 150
            pygame.draw.rect(dst, (255, flash, flash),
                             (x0, gauge.y, x1 - x0, gauge.height))
            pygame.draw.rect(dst, (16, 16, 32), gauge, width=1)
        ui.text_center(dst, f"-{lo}~{hi}", (gauge.centerx, gauge.y - 16),
                       16, (255, 140, 140))

    # ------------------------------------------------------------------
    # コマンドの詳細プレビュー (1タップ目で選択したときの説明表示)
    # ------------------------------------------------------------------

    @staticmethod
    def _describe_entry(kind: str, payload) -> tuple[str, str]:
        """(せつめい文, たいしょう/コスト等の補足) を返す."""
        if kind == "attack":
            return "つうじょうの ぶつりこうげき", \
                f"たいしょう: {_TARGET_LABEL['enemy']}"
        if kind in ("ability", "spell"):
            ab: Ability = payload
            extra = f"たいしょう: {_TARGET_LABEL.get(ab.target, ab.target)}"
            if ab.mp:
                extra += f"  MP{ab.mp}"
            if ab.radius:
                extra += "  はんい こうげき"
            return ab.desc, extra
        if kind == "combo":
            cb = payload
            return "なかまと きょうどうする とくぎ", \
                f"たいしょう: {_TARGET_LABEL.get(cb.target, cb.target)}"
        if kind == "defend":
            return "うける ダメージを はんげんする", ""
        if kind == "escape":
            return "せんとうから にげだす", ""
        return "", ""

    def _armed_damage_preview(self):
        """armed中のコマンドについて (target, (lo, hi)) を返す (対象外はNone)."""
        entries = self.menu if self.mode == "command" else self.sub
        idx = self.index if self.mode == "command" else self.sub_index
        if not 0 <= idx < len(entries):
            return None
        kind, payload, _, _ = entries[idx]
        engine_kind = "ability" if kind == "spell" else kind
        if engine_kind not in ("attack", "ability", "combo"):
            return None
        target = next((e for e in self.engine.enemies if e.alive), None)
        if target is None:
            return None
        preview = self.engine.preview_damage(self.hero, engine_kind, payload,
                                             target)
        if preview is None:
            return None
        return target, preview

    def _draw_preview(self, dst: pygame.Surface, entries: list,
                      index: int) -> None:
        """いま選んでいるコマンドの説明とダメージ予測を表示する。

        armed (タップで選択済み・再タップで発動できる状態) かどうかで
        ヒント文言だけ切り替える。
        """
        if not 0 <= index < len(entries):
            return
        kind, payload, label, _ = entries[index]
        desc, extra = self._describe_entry(kind, payload)
        box = PREVIEW_RECT
        ui.draw_window(dst, box)
        ui.text(dst, label, (box.x + 18, box.y + 10), 22,
                C.COLOR_TEXT_YELLOW)
        if desc:
            ui.text(dst, desc, (box.x + 18, box.y + 42), 16, C.COLOR_TEXT)
        if extra:
            ui.text(dst, extra, (box.x + 18, box.y + 68), 14,
                    C.COLOR_TEXT_DIM)
        hint = "もういちどタップ/Zで けってい・もどるで キャンセル" \
            if self.armed else "タップ/Zで けってい"
        ui.text(dst, hint, (box.x + 18, box.y + 96), 13,
                C.COLOR_TEXT_DIM)
        result = self._armed_damage_preview()
        if result is not None:
            target, (lo, hi) = result
            self._draw_damage_preview(dst, target, lo, hi)
