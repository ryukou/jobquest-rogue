"""ATB battle scene: クロノトリガー風.

- エンカウント時のフィールド上の立ち位置がそのまま戦闘配置になる
- メッセージで止めない: 技名は上部バナーに流れ、ダメージは数字ポップアップ
- radius>0 の技は対象の周囲を巻き込む円形範囲 (CTのサイクロン式)
- ウェイト制 (メニュー中は時間停止)。config.BATTLE_ACTIVE でアクティブ制に
"""

from __future__ import annotations

import math
import random
from typing import Callable

import pygame

from jobquest import config as C
from jobquest import music, sfx, sprites, ui
from jobquest.engine import ATB_MAX, BattleEngine, StepResult
from jobquest.jobs import Ability
from jobquest.models import ITEMS, Character, EnemyUnit

BANNER_TIME = 1.15
POPUP_TIME = 0.9
LUNGE_TIME = 0.35
END_DELAY = 1.0
PAGE_TIME = 1.4

# 立ち位置の画面内クランプ範囲 (下部はUIに重ならないように)
X_MIN, X_MAX = 70, 890
Y_MIN, Y_MAX = 95, 425

# エンカウント地点からの散開オフセット
PARTY_SPREAD = [(0, 0), (-72, 62), (64, 70), (-8, 132)]
ENEMY_SPREAD = [(0, 0), (-84, -54), (76, -62), (-64, 72), (84, 62)]


def _clamp_pos(x: float, y: float) -> tuple[int, int]:
    return (int(min(max(x, X_MIN), X_MAX)),
            int(min(max(y, Y_MIN), Y_MAX)))


class BattleScene:
    def __init__(self, engine: BattleEngine, background: pygame.Surface,
                 on_finish: Callable[[str], None],
                 ctx: dict | None = None) -> None:
        self.engine = engine
        self.bg = background
        self.on_finish = on_finish
        self.time = 0.0
        self.finished = False

        # 流れる演出 (ノンブロッキング)
        self.banners: list[str] = []
        self.banner_age = 0.0
        self.popups: list[list] = []      # [Popup, age]
        self.lunges: dict[int, float] = {}  # id(actor) -> age
        self.effects: list[list] = []     # [kind, x, y, age]
        self.shake = 0.0
        self._shake_rng = random.Random(3)
        self.end_delay = 0.0

        # 決着後のリザルト表示のみブロッキング
        self.state = "flow"               # flow / result
        self.pages: list[list[str]] = []
        self.page_timer = 0.0

        # コマンドメニュー (開いていてもATBは進む)
        self.hero: Character | None = None
        self.mode = "command"             # command / sub / target
        self.menu: list[tuple] = []
        self.index = 0
        self.sub: list[tuple] = []
        self.sub_index = 0
        self.pending = None
        self.targets: list = []
        self.target_index = 0

        self.pos: dict[int, tuple[int, int]] = {}
        self.lunge_dir: dict[int, tuple[float, float]] = {}
        self._layout(ctx)

    # ------------------------------------------------------------------
    # 配置: エンカウント地点にそのまま散開する (CT風)
    # ------------------------------------------------------------------

    def _layout(self, ctx: dict | None) -> None:
        enemies = self.engine.enemies
        party = self.engine.party
        if ctx is not None:
            ppx, ppy = ctx["player"]
            epx, epy = ctx["enemy"]
        else:  # フォールバック (旧来の対面配置)
            ppx, ppy = 780, 260
            epx, epy = 200, 240
        # 接触エンカウントだと両者が重なるので最低距離まで押し離す
        dx, dy = epx - ppx, epy - ppy
        dist = math.hypot(dx, dy)
        if dist < 1:
            dx, dy, dist = -1.0, 0.0, 1.0
        min_sep = 200.0
        if dist < min_sep:
            epx = ppx + dx / dist * min_sep
            epy = ppy + dy / dist * min_sep
        for i, en in enumerate(enemies):
            ox, oy = ENEMY_SPREAD[i % len(ENEMY_SPREAD)]
            self.pos[id(en)] = _clamp_pos(epx + ox, epy + oy)
        for i, ch in enumerate(party):
            ox, oy = PARTY_SPREAD[i % len(PARTY_SPREAD)]
            self.pos[id(ch)] = _clamp_pos(ppx + ox, ppy + oy)

        def centroid(objs) -> tuple[float, float]:
            xs = [self.pos[id(o)][0] for o in objs]
            ys = [self.pos[id(o)][1] for o in objs]
            return sum(xs) / len(xs), sum(ys) / len(ys)

        e_cx, e_cy = centroid(enemies)
        p_cx, p_cy = centroid(party)
        for obj, tx, ty in ([(ch, e_cx, e_cy) for ch in party]
                            + [(en, p_cx, p_cy) for en in enemies]):
            x, y = self.pos[id(obj)]
            dist = math.hypot(tx - x, ty - y) or 1.0
            self.lunge_dir[id(obj)] = ((tx - x) / dist * 36,
                                       (ty - y) / dist * 36)

    # ------------------------------------------------------------------
    # 入力
    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN or self.finished:
            return
        key = event.key
        confirm = key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE)
        cancel = key in (pygame.K_x, pygame.K_ESCAPE)

        if self.state == "result":
            if confirm:
                self._advance_page()
            return
        if self.hero is None:
            return
        if key in (pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT,
                   pygame.K_RIGHT):
            sfx.play("cursor")
        if self.mode == "command":
            if key == pygame.K_UP:
                self.index = (self.index - 1) % len(self.menu)
            elif key == pygame.K_DOWN:
                self.index = (self.index + 1) % len(self.menu)
            elif confirm:
                self._pick_command()
        elif self.mode == "sub":
            if key == pygame.K_UP:
                self.sub_index = (self.sub_index - 1) % len(self.sub)
            elif key == pygame.K_DOWN:
                self.sub_index = (self.sub_index + 1) % len(self.sub)
            elif confirm:
                self._pick_sub()
            elif cancel:
                sfx.play("cancel")
                self.mode = "command"
        elif self.mode == "target":
            if key in (pygame.K_UP, pygame.K_LEFT):
                self.target_index = (self.target_index - 1) % len(self.targets)
            elif key in (pygame.K_DOWN, pygame.K_RIGHT):
                self.target_index = (self.target_index + 1) % len(self.targets)
            elif confirm:
                sfx.play("confirm")
                self._execute(self.targets[self.target_index])
            elif cancel:
                sfx.play("cancel")
                self.mode = "command"

    # ------------------------------------------------------------------
    # コマンドメニュー
    # ------------------------------------------------------------------

    def _open_command(self, hero: Character) -> None:
        self.hero = hero
        self.menu = [("attack", None, "たたかう", True)]
        for ab in hero.battle_commands():
            if ab.kind == "cmd_menu":
                enabled = bool(hero.known_spells(ab.school))
            else:
                enabled = hero.mp >= ab.mp
            self.menu.append(("ability", ab, ab.name, enabled))
        if self.engine.available_combos(hero):
            self.menu.append(("combo", None, "れんけい", True))
        self.menu.append(("item", None, "アイテム",
                          bool(self.engine.inventory.listing())))
        self.menu.append(("defend", None, "ぼうぎょ", True))
        self.menu.append(("escape", None, "にげる", self.engine.can_escape))
        self.index = 0
        self.mode = "command"

    def _close_menu(self) -> None:
        self.hero = None
        self.mode = "command"

    def _pick_command(self) -> None:
        kind, payload, _, enabled = self.menu[self.index]
        if not enabled:
            sfx.play("cancel")
            return
        sfx.play("confirm")
        hero = self.hero
        if kind == "attack":
            self.pending = ("attack", None)
            self._open_target(self.engine.enemies)
        elif kind == "ability":
            ab: Ability = payload
            if ab.kind == "cmd_menu":
                self.sub = [
                    ("spell", sp, f"{sp.name}", hero.mp >= sp.mp)
                    for sp in hero.known_spells(ab.school)]
                self.sub_index = 0
                self.mode = "sub"
            else:
                self._route_ability(ab)
        elif kind == "combo":
            self.sub = [("combo", cb, cb.name, True)
                        for cb in self.engine.available_combos(hero)]
            self.sub_index = 0
            self.mode = "sub"
        elif kind == "item":
            self.sub = [
                ("item", iid, f"{ITEMS[iid][0]} ×{n}", True)
                for iid, n in self.engine.inventory.listing()]
            self.sub_index = 0
            self.mode = "sub"
        elif kind == "defend":
            self._present(self.engine.do_defend(hero))
            self._close_menu()
        elif kind == "escape":
            self._present(self.engine.do_escape(hero))
            self._close_menu()

    def _pick_sub(self) -> None:
        kind, payload, _, enabled = self.sub[self.sub_index]
        if not enabled:
            sfx.play("cancel")
            return
        sfx.play("confirm")
        if kind == "spell":
            self._route_ability(payload)
        elif kind == "item":
            self.pending = ("item", payload)
            self._open_target(self.engine.party, allow_ko=True)
        elif kind == "combo":
            cb = payload
            self.pending = ("combo", cb)
            if cb.target == "enemies":
                self._execute(None)
            else:
                self._open_target(self.engine.enemies)

    def _route_ability(self, ab: Ability) -> None:
        self.pending = ("ability", ab)
        if ab.target == "self":
            self._execute(self.hero)
        elif ab.target == "enemies":
            self._execute(None)
        elif ab.target == "enemy":
            self._open_target(self.engine.enemies)
        elif ab.target == "ally":
            self._open_target(self.engine.party)
        elif ab.target == "ally_ko":
            ko = [c for c in self.engine.party if not c.alive]
            self._open_target(ko or self.engine.party, allow_ko=True)

    def _open_target(self, pool: list, allow_ko: bool = False) -> None:
        self.targets = [t for t in pool if allow_ko or t.alive]
        if not self.targets:
            self.mode = "command"
            return
        self.target_index = 0
        self.mode = "target"

    def _pending_radius(self) -> int:
        if self.pending is None:
            return 0
        kind, payload = self.pending
        if kind in ("ability", "combo"):
            return getattr(payload, "radius", 0)
        return 0

    def _area_group(self, target: EnemyUnit) -> list[EnemyUnit]:
        radius = self._pending_radius()
        tx, ty = self.pos[id(target)]
        return [e for e in self.engine.enemies if e.alive
                and math.hypot(self.pos[id(e)][0] - tx,
                               self.pos[id(e)][1] - ty) <= radius]

    def _execute(self, target) -> None:
        kind, payload = self.pending
        eng = self.engine
        # アクティブ制: 選択中に対象が倒れていたら生存者へ振り替える
        if isinstance(target, EnemyUnit) and not target.alive:
            alive = [e for e in eng.enemies if e.alive]
            if not alive:
                self._close_menu()
                return
            target = alive[0]
        group = None
        if isinstance(target, EnemyUnit) and self._pending_radius() > 0:
            group = self._area_group(target)
        if kind == "attack":
            res = eng.do_attack(self.hero, target)
        elif kind == "ability":
            res = eng.do_ability(self.hero, payload, target, group=group)
        elif kind == "item":
            res = eng.do_item(self.hero, payload, target)
        elif kind == "combo":
            res = eng.do_combo(payload, target, group=group)
        self._present(res)
        self._close_menu()

    # ------------------------------------------------------------------
    # ノンブロッキング演出
    # ------------------------------------------------------------------

    def _present(self, res: StepResult) -> None:
        self.banners.extend(res.lines)
        for pop in res.popups:
            self.popups.append([pop, 0.0])
            if pop.kind in ("dmg", "heal", "miss"):
                x, y = self.pos.get(id(pop.target), (480, 300))
                kind = res.effect or ("heal" if pop.kind == "heal"
                                      else "slash")
                self.effects.append([kind, x, y, 0.0])
            if pop.kind == "dmg" and pop.text.isdigit() \
                    and int(pop.text) >= 60:
                self.shake = max(self.shake, 0.3)
        if res.effect == "burst":
            self.shake = max(self.shake, 0.45)
        if res.actor is not None:
            self.lunges[id(res.actor)] = 0.0
        kinds = {p.kind for p in res.popups}
        if any("となえた" in ln or "れんけい" in ln for ln in res.lines):
            sfx.play("magic")
        if "dmg" in kinds:
            sfx.play("hit")
        elif "heal" in kinds or "mp" in kinds:
            sfx.play("heal")
        elif "miss" in kinds:
            sfx.play("miss")

    # ------------------------------------------------------------------
    # 更新
    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        self.time += dt
        if self.finished:
            return
        # 演出の経過
        if self.banners:
            self.banner_age += dt
            limit = BANNER_TIME if len(self.banners) <= 3 else 0.55
            if self.banner_age >= limit:
                self.banners.pop(0)
                self.banner_age = 0.0
        for entry in self.popups:
            entry[1] += dt
        self.popups = [e for e in self.popups if e[1] < POPUP_TIME]
        for eff in self.effects:
            eff[3] += dt
        self.effects = [e for e in self.effects if e[3] < 0.5]
        self.shake = max(0.0, self.shake - dt)
        for key in list(self.lunges):
            self.lunges[key] += dt
            if self.lunges[key] > LUNGE_TIME:
                del self.lunges[key]

        if self.state == "result":
            self.page_timer += dt
            if self.page_timer >= PAGE_TIME:
                self._advance_page()
            return

        outcome = self.engine.outcome
        if outcome:
            self._close_menu()
            self.end_delay += dt
            if self.end_delay >= END_DELAY:
                self._enter_result(outcome)
            return

        # ウェイト制: メニューを開いている間は時間が止まる
        # (BATTLE_ACTIVE=True ならCT準拠のアクティブ制)
        if C.BATTLE_ACTIVE or self.hero is None:
            for res in self.engine.tick(dt):
                self._present(res)

        if self.hero is not None and not self.hero.alive:
            self._close_menu()
        if self.hero is not None and self.mode == "target":
            self.targets = [t for t in self.targets
                            if not isinstance(t, EnemyUnit) or t.alive]
            if not self.targets:
                self.mode = "command"
            else:
                self.target_index %= len(self.targets)
        if self.hero is None and self.engine.ready:
            self._open_command(self.engine.ready[0])

    def _enter_result(self, outcome: str) -> None:
        self.state = "result"
        self.page_timer = 0.0
        music.stop(300)  # ジングルを聞かせるためBGMを止める
        if outcome == "victory":
            sfx.play("victory")
            lines = self.engine.victory_lines()
        elif outcome == "defeat":
            sfx.play("gameover")
            lines = ["ぜんめつしてしまった…"]
        else:
            lines = ["うまく にげきれた！"]
        self.pages = [lines[i:i + 2] for i in range(0, len(lines), 2)]

    def _advance_page(self) -> None:
        self.page_timer = 0.0
        if self.pages:
            self.pages.pop(0)
        if not self.pages:
            self.finished = True
            self.on_finish(self.engine.outcome)

    # ------------------------------------------------------------------
    # 描画
    # ------------------------------------------------------------------

    def _lunge_offset(self, obj: object) -> tuple[int, int]:
        age = self.lunges.get(id(obj))
        if age is None:
            return 0, 0
        k = math.sin(math.pi * age / LUNGE_TIME)
        dx, dy = self.lunge_dir.get(id(obj), (0, 0))
        return int(dx * k), int(dy * k)

    def draw(self, dst: pygame.Surface) -> None:
        ox = oy = 0
        if self.shake > 0:
            amp = int(self.shake * 14)
            ox = self._shake_rng.randint(-amp, amp)
            oy = self._shake_rng.randint(-amp, amp)
        dst.fill((10, 10, 20))
        dst.blit(self.bg, (ox, oy))

        for en in self.engine.enemies:
            if not en.alive:
                continue
            scale = 6 if en.species.boss else 4
            img = sprites.enemy(en.species.sprite, scale)
            x, y = self.pos[id(en)]
            lx, ly = self._lunge_offset(en)
            bob = int(math.sin(self.time * 2.4 + (id(en) % 7)) * 3)
            rect = img.get_rect(center=(x + lx, y + ly + bob))
            dst.blit(img, rect)
            ratio = en.hp / en.max_hp
            ui.gauge(dst, pygame.Rect(rect.centerx - 28, rect.bottom + 4,
                                      56, 6), ratio, ui.hp_color(ratio))
        for ch in self.engine.party:
            img = sprites.chara(ch, 4)
            x, y = self.pos[id(ch)]
            lx, ly = self._lunge_offset(ch)
            if not ch.alive:
                img = pygame.transform.rotate(img, 90)
                img.set_alpha(120)
            elif self.hero is ch:
                y -= int(abs(math.sin(self.time * 6)) * 6) + 4
            dst.blit(img, img.get_rect(center=(x + lx, y + ly)))

        self._draw_effects(dst)
        self._draw_popups(dst)
        self._draw_status(dst)
        if self.state == "result":
            self._draw_result(dst)
            return
        if self.hero is not None:
            if self.mode == "command":
                self._draw_menu(dst, self.menu, self.index)
            elif self.mode == "sub":
                self._draw_menu(dst, self.sub, self.sub_index, mp_hint=True)
            elif self.mode == "target":
                self._draw_menu(dst, self.menu, self.index)
                self._draw_target_cursor(dst)
        if self.banners:
            self._draw_banner(dst)

    def _draw_effects(self, dst: pygame.Surface) -> None:
        for kind, x, y, age in self.effects:
            t = min(1.0, age / 0.45)
            if kind == "slash":
                arm = int(52 * math.sin(math.pi * t))
                for sx, sy in ((1, 1), (1, -1)):
                    pygame.draw.line(dst, (255, 255, 255),
                                     (x - arm * sx, y - arm * sy),
                                     (x + arm * sx, y + arm * sy), 3)
            elif kind == "fire":
                for i in range(6):
                    ang = i * math.tau / 6 + t * 2.5
                    r = 10 + 34 * t
                    col = (255, 120, 40) if i % 2 else (255, 210, 80)
                    size = max(2, int(9 * (1 - t)))
                    pygame.draw.circle(
                        dst, col, (int(x + math.cos(ang) * r),
                                   int(y + math.sin(ang) * r)), size)
            elif kind == "ice":
                for i in range(5):
                    sx = x - 26 + i * 13
                    sy = y + 24 - int(58 * t) + (i % 2) * 8
                    pygame.draw.rect(dst, (170, 225, 255),
                                     (sx, sy, 4, 12))
                    pygame.draw.rect(dst, (255, 255, 255), (sx + 1, sy, 1, 12))
            elif kind == "bolt":
                if t < 0.6 and int(age * 30) % 2 == 0:
                    pts = []
                    for i in range(7):
                        yy = y - 100 + i * 17
                        xx = x + (-9 if i % 2 else 9)
                        pts.append((xx, yy))
                    pts.append((x, y))
                    pygame.draw.lines(dst, (255, 240, 120), False, pts, 4)
                    pygame.draw.lines(dst, (255, 255, 255), False, pts, 1)
            elif kind == "heal":
                for i in range(6):
                    sx = x - 26 + i * 11
                    sy = y + 14 - int(46 * t) - (i % 3) * 7
                    pygame.draw.line(dst, (150, 255, 170),
                                     (sx - 3, sy), (sx + 3, sy), 2)
                    pygame.draw.line(dst, (150, 255, 170),
                                     (sx, sy - 3), (sx, sy + 3), 2)
            elif kind == "burst":
                for rr in (int(70 * t), max(0, int(70 * t) - 16)):
                    if rr > 2:
                        pygame.draw.circle(dst, (255, 140, 60), (x, y),
                                           rr, 3)
                        pygame.draw.circle(dst, (255, 230, 120), (x, y),
                                           max(2, rr - 6), 2)
            elif kind == "wind":
                for i in range(3):
                    sx = int(x - 50 + 120 * t)
                    sy = y - 14 + i * 14
                    pygame.draw.arc(dst, (170, 255, 230),
                                    (sx - 20, sy - 8, 40, 16),
                                    0.4, 2.7, 2)
            elif kind == "status":
                r = 20 + int(14 * math.sin(math.pi * t))
                pygame.draw.circle(dst, (150, 190, 255), (x, y), r, 2)

    def _draw_popups(self, dst: pygame.Surface) -> None:
        for pop, age in self.popups:
            x, y = self.pos.get(id(pop.target), (480, 300))
            rise = int(age * 44)
            color = {"dmg": C.COLOR_DMG, "heal": C.COLOR_HEAL,
                     "mp": C.COLOR_MPNUM, "miss": C.COLOR_MISS}[pop.kind]
            ui.text_center(dst, pop.text, (x, y - 46 - rise), 28, color)

    def _draw_banner(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(230, 14, 500, 46)
        ui.draw_window(dst, rect)
        ui.text_center(dst, self.banners[0],
                       (rect.centerx, rect.centery), 22)

    def _draw_result(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(20, 16, 920, 84)
        ui.draw_window(dst, rect)
        if self.pages:
            for i, line in enumerate(self.pages[0]):
                ui.text(dst, line, (rect.x + 24, rect.y + 12 + i * 30), 22)

    def _draw_status(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(330, 476, 610, 152)
        ui.draw_window(dst, rect)
        party = self.engine.party
        row_h = 44 if len(party) <= 3 else 33
        name_size = 22 if len(party) <= 3 else 20
        for i, ch in enumerate(party):
            y = rect.y + 12 + i * row_h
            color = C.COLOR_TEXT if ch.alive else C.COLOR_TEXT_DIM
            if ch in self.engine.ready:
                ui.cursor(dst, (rect.x + 8, y + 4))
            ui.text(dst, ch.name, (rect.x + 30, y), name_size, color)
            ui.text(dst, ch.job.name, (rect.x + 128, y + 4), 16,
                    C.COLOR_TEXT_DIM)
            hp_ratio = ch.hp / ch.max_hp
            ui.text(dst, f"{ch.hp:4d}", (rect.x + 250, y), name_size,
                    ui.hp_color(hp_ratio) if ch.alive else C.COLOR_HP_LOW)
            ui.gauge(dst, pygame.Rect(rect.x + 310, y + 10, 80, 8),
                     hp_ratio, ui.hp_color(hp_ratio))
            ui.text(dst, f"MP{ch.mp:3d}", (rect.x + 400, y + 4), 16,
                    C.COLOR_MPNUM)
            full = ch.atb >= ATB_MAX
            ui.gauge(dst, pygame.Rect(rect.x + 480, y + 10, 100, 10),
                     ch.atb / ATB_MAX,
                     C.COLOR_ATB_FULL if full else C.COLOR_ATB)

    def _draw_menu(self, dst: pygame.Surface, entries: list,
                   index: int, mp_hint: bool = False) -> None:
        rect = pygame.Rect(20, 420, 300, 208)
        ui.draw_window(dst, rect)
        if self.hero:
            ui.text(dst, self.hero.name, (rect.x + 18, rect.y + 8), 18,
                    C.COLOR_TEXT_YELLOW)
        visible = 6
        top = max(0, min(index - visible + 1, len(entries) - visible))
        for row, entry in enumerate(entries[top:top + visible]):
            kind, payload, label, enabled = entry
            y = rect.y + 34 + row * 28
            if top + row == index:
                ui.cursor(dst, (rect.x + 12, y + 2))
            color = C.COLOR_TEXT if enabled else C.COLOR_TEXT_DIM
            ui.text(dst, label, (rect.x + 36, y), 22, color)
            if mp_hint and kind == "spell":
                ui.text(dst, f"{payload.mp:2d}", (rect.x + 240, y), 20,
                        C.COLOR_MPNUM)

    def _draw_target_cursor(self, dst: pygame.Surface) -> None:
        target = self.targets[self.target_index]
        affected = [target]
        if isinstance(target, EnemyUnit) and self._pending_radius() > 0:
            affected = self._area_group(target)
        bounce = int(abs(math.sin(self.time * 8)) * 6)
        for obj in affected:
            x, y = self.pos[id(obj)]
            main = obj is target
            px = x - (56 if isinstance(obj, EnemyUnit) else -48)
            off = bounce if main else 2
            size = 14 if main else 10
            pygame.draw.polygon(
                dst, C.COLOR_CURSOR,
                [(px - off, y - size * 0.7), (px - off, y + size * 0.7),
                 (px + size - off, y)])
        box = pygame.Rect(20, 16, 300, 46)
        ui.draw_window(dst, box)
        suffix = "たち" if len(affected) > 1 else ""
        ui.text(dst, target.name + suffix, (box.x + 20, box.y + 9), 22,
                C.COLOR_TEXT_YELLOW)
