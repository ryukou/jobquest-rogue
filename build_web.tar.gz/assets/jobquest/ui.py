"""SNES FF-style window / text / gauge helpers."""

from __future__ import annotations

import pygame

from jobquest import config as C
from jobquest.fonts import get_font


def draw_window(dst: pygame.Surface, rect: pygame.Rect) -> None:
    """紺グラデーション + 白二重枠のFF風ウィンドウ."""
    shadow = rect.move(4, 4)
    pygame.draw.rect(dst, C.WINDOW_SHADOW, shadow, border_radius=6)
    inner = pygame.Surface(rect.size)
    h = max(1, rect.height)
    for y in range(h):
        t = y / h
        color = tuple(int(a + (b - a) * t)
                      for a, b in zip(C.WINDOW_TOP, C.WINDOW_BOTTOM))
        inner.fill(color, (0, y, rect.width, 1))
    dst.blit(inner, rect.topleft)
    pygame.draw.rect(dst, C.WINDOW_BORDER, rect, width=3, border_radius=6)
    pygame.draw.rect(dst, C.WINDOW_INNER, rect.inflate(-6, -6),
                     width=1, border_radius=4)


def text(dst: pygame.Surface, s: str, pos: tuple[int, int],
         size: int = 22, color=C.COLOR_TEXT, shadow: bool = True) -> int:
    font = get_font(size)
    if shadow:
        dst.blit(font.render(s, True, (16, 16, 32)),
                 (pos[0] + 2, pos[1] + 2))
    surf = font.render(s, True, color)
    dst.blit(surf, pos)
    return surf.get_width()


def text_center(dst: pygame.Surface, s: str, center: tuple[int, int],
                size: int = 22, color=C.COLOR_TEXT) -> None:
    font = get_font(size)
    surf = font.render(s, True, color)
    rect = surf.get_rect(center=(center[0] + 1, center[1] + 1))
    dst.blit(font.render(s, True, (16, 16, 32)), rect)
    rect = surf.get_rect(center=center)
    dst.blit(surf, rect)


def gauge(dst: pygame.Surface, rect: pygame.Rect, ratio: float,
          color: tuple[int, int, int]) -> None:
    ratio = max(0.0, min(1.0, ratio))
    pygame.draw.rect(dst, C.COLOR_GAUGE_BG, rect)
    if ratio > 0:
        fill = rect.copy()
        fill.width = max(1, int(rect.width * ratio))
        pygame.draw.rect(dst, color, fill)
    pygame.draw.rect(dst, (16, 16, 32), rect, width=1)


def hp_color(ratio: float) -> tuple[int, int, int]:
    if ratio > 0.5:
        return C.COLOR_HP_HIGH
    if ratio > 0.25:
        return C.COLOR_HP_MID
    return C.COLOR_HP_LOW


def readable_color(color: tuple[int, int, int]) -> tuple[int, int, int]:
    """紺色のウィンドウ背景で暗すぎる色 (にんじゃ等) を底上げして

    文字色として読める明るさにする。ドット絵の服の色そのものには使わない。
    """
    r, g, b = color
    luma = 0.3 * r + 0.59 * g + 0.11 * b
    if luma >= 130:
        return color
    boost = (130 - luma) / max(1, 255 - luma)
    return tuple(int(c + (255 - c) * boost) for c in (r, g, b))


def post_key(key: int) -> None:
    """タップをキー入力に変換してシーンの既存ロジックを再利用する."""
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=key))


def tap_select(current: int, tapped: int, on_move) -> None:
    """タップ選択の共通規則: シングルタップで即決定 (ストレスフリー).

    タップした項目にカーソルを合わせてから決定キーを注入する。
    """
    if tapped != current:
        on_move(tapped)
    post_key(pygame.K_z)


def tap_in_rects(pos: tuple[float, float], rects: list[pygame.Rect],
                 current: int, on_move) -> bool:
    """rects内でposに当たった最初の項目にtap_selectを適用する。

    当たった場合 True を返す (呼び出し側は「外れたらキャンセル」等を判断できる)。
    """
    for i, rect in enumerate(rects):
        if rect.collidepoint(pos):
            tap_select(current, i, on_move)
            return True
    return False


def center_row_rects(count: int, item_w: int, item_h: int, gap: int,
                     y: int) -> list[pygame.Rect]:
    """count個の矩形を画面幅の中央に横一列に並べる (カード/報酬選択などで共用)."""
    start_x = (C.SCREEN_W - (item_w * count + gap * (count - 1))) // 2
    return [pygame.Rect(start_x + i * (item_w + gap), y, item_w, item_h)
            for i in range(count)]


def visible_window(cur: int, total: int, visible: int) -> int:
    """縦スクロールする一覧で、先頭に表示する項目のindex (描画とタップ判定で共用)."""
    return max(0, min(cur - visible + 1, total - visible))


def cursor(dst: pygame.Surface, pos: tuple[int, int]) -> None:
    """FF風の指カーソル代わりの三角."""
    x, y = pos
    pygame.draw.polygon(dst, (16, 16, 32),
                        [(x + 2, y + 2), (x + 2, y + 18), (x + 14, y + 10)])
    pygame.draw.polygon(dst, C.COLOR_CURSOR,
                        [(x, y), (x, y + 16), (x + 12, y + 8)])
