"""SNES FF-style window / text / gauge helpers."""

from __future__ import annotations

import pygame

from jobquest import config as C
from jobquest.fonts import get_font


def draw_window(dst: pygame.Surface, rect: pygame.Rect) -> None:
    """紺グラデーション + 白二重枠のFF風ウィンドウ."""
    shadow = rect.move(4, 4)
    pygame.draw.rect(dst, C.WINDOW_SHADOW, shadow, border_radius=6)
    inner = pygame.Surface(rect.size)
    h = max(1, rect.height)
    for y in range(h):
        t = y / h
        color = tuple(int(a + (b - a) * t)
                      for a, b in zip(C.WINDOW_TOP, C.WINDOW_BOTTOM))
        inner.fill(color, (0, y, rect.width, 1))
    dst.blit(inner, rect.topleft)
    pygame.draw.rect(dst, C.WINDOW_BORDER, rect, width=3, border_radius=6)
    pygame.draw.rect(dst, C.WINDOW_INNER, rect.inflate(-6, -6),
                     width=1, border_radius=4)


def text(dst: pygame.Surface, s: str, pos: tuple[int, int],
         size: int = 22, color=C.COLOR_TEXT, shadow: bool = True) -> int:
    font = get_font(size)
    if shadow:
        dst.blit(font.render(s, True, (16, 16, 32)),
                 (pos[0] + 2, pos[1] + 2))
    surf = font.render(s, True, color)
    dst.blit(surf, pos)
    return surf.get_width()


def text_center(dst: pygame.Surface, s: str, center: tuple[int, int],
                size: int = 22, color=C.COLOR_TEXT) -> None:
    font = get_font(size)
    surf = font.render(s, True, color)
    rect = surf.get_rect(center=(center[0] + 1, center[1] + 1))
    dst.blit(font.render(s, True, (16, 16, 32)), rect)
    rect = surf.get_rect(center=center)
    dst.blit(surf, rect)


def gauge(dst: pygame.Surface, rect: pygame.Rect, ratio: float,
          color: tuple[int, int, int]) -> None:
    ratio = max(0.0, min(1.0, ratio))
    pygame.draw.rect(dst, C.COLOR_GAUGE_BG, rect)
    if ratio > 0:
        fill = rect.copy()
        fill.width = max(1, int(rect.width * ratio))
        pygame.draw.rect(dst, color, fill)
    pygame.draw.rect(dst, (16, 16, 32), rect, width=1)


def hp_color(ratio: float) -> tuple[int, int, int]:
    if ratio > 0.5:
        return C.COLOR_HP_HIGH
    if ratio > 0.25:
        return C.COLOR_HP_MID
    return C.COLOR_HP_LOW


def cursor(dst: pygame.Surface, pos: tuple[int, int]) -> None:
    """FF風の指カーソル代わりの三角."""
    x, y = pos
    pygame.draw.polygon(dst, (16, 16, 32),
                        [(x + 2, y + 2), (x + 2, y + 18), (x + 14, y + 10)])
    pygame.draw.polygon(dst, C.COLOR_CURSOR,
                        [(x, y), (x, y + 16), (x + 12, y + 8)])
