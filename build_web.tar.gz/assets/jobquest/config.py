"""Display constants and SNES-style palette."""

from __future__ import annotations

SCREEN_W = 960
SCREEN_H = 640
FPS = 60

# True にするとアクティブ制 (コマンド選択中もATBが進む)。
# False はウェイト制: メニューを開いている間は時間が止まる
BATTLE_ACTIVE = False

TILE = 16          # ドット絵の論理サイズ
SCALE = 3          # フィールド表示倍率
TILE_PX = TILE * SCALE  # 48px

# FF風ウィンドウ (紺グラデーション + 白枠)
WINDOW_TOP = (16, 24, 88)
WINDOW_BOTTOM = (56, 72, 168)
WINDOW_BORDER = (236, 240, 248)
WINDOW_INNER = (96, 104, 160)
WINDOW_SHADOW = (8, 8, 24)

COLOR_TEXT = (248, 248, 248)
COLOR_TEXT_DIM = (152, 160, 192)
COLOR_TEXT_YELLOW = (248, 224, 96)
COLOR_CURSOR = (248, 224, 96)

COLOR_HP_HIGH = (96, 216, 112)
COLOR_HP_MID = (240, 200, 64)
COLOR_HP_LOW = (232, 80, 64)
COLOR_MP = (104, 160, 248)
COLOR_ATB = (240, 176, 64)
COLOR_ATB_FULL = (255, 240, 128)
COLOR_GAUGE_BG = (40, 44, 72)

COLOR_DMG = (255, 255, 255)
COLOR_HEAL = (128, 255, 144)
COLOR_MPNUM = (144, 192, 255)
COLOR_MISS = (192, 192, 208)
