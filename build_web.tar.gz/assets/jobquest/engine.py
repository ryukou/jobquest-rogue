"""ATB battle engine (pygame非依存の純ロジック).

クロノトリガー/FF5風: ATBゲージが溜まったユニットから行動する。
ウェイト式 (メニューやメッセージ表示中はゲージ停止) を採用し、
シーン側は tick() の戻り値 StepResult を順に演出表示する。
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from jobquest.jobs import ABILITIES, COMBOS, Ability, Combo
from jobquest.models import Character, EnemyUnit, Inventory

ATB_MAX = 100.0

# --- 属性 (element) の追加効果 -------------------------------------------
# fire: やけど (継続ダメージ) / ice: ATB遅延 / bolt: きかい特効
BURN_TICKS = 3          # やけどのダメージ回数 (対象の行動タイミングごと)
BURN_RATIO = 0.25       # やけど1回のダメージ = 命中ダメージの25%
ICE_ATB_DELAY = 45.0    # ブリザド系が奪うATBゲージ量
BOLT_MACHINE_MULT = 1.5  # サンダー系の きかい特効倍率


def element_multiplier(element: str, target: object) -> float:
    """属性によるダメージ倍率 (現状は bolt の きかい特効のみ)."""
    species = getattr(target, "species", None)
    if element == "bolt" and species is not None and species.machine:
        return BOLT_MACHINE_MULT
    return 1.0


def atb_rate(spd: int, flags: set[str]) -> float:
    rate = 14.0 + spd * 1.7
    if "haste" in flags:
        rate *= 1.5
    if "slow" in flags:
        rate *= 0.6
    return rate


def phys_damage(atk: int, vit: int, rng: random.Random,
                mult: float = 1.0) -> tuple[int, bool]:
    """(ダメージ, クリティカルか)."""
    crit = rng.random() < 1 / 16
    base = atk * 2.2 * mult - vit * 1.1
    dmg = base * rng.uniform(0.9, 1.1) * (2.0 if crit else 1.0)
    return max(1, int(dmg)), crit


def magic_damage(power: float, mag: int, vit: int,
                 rng: random.Random) -> int:
    base = power + mag * 1.7 - vit * 0.8
    return max(1, int(base * rng.uniform(0.9, 1.1)))


def heal_amount(power: float, mag: int, rng: random.Random) -> int:
    return max(1, int((power + mag * 1.6) * rng.uniform(0.95, 1.05)))


# ---------------------------------------------------------------------------
# ダメージ予測 (表示専用: rngを消費せず、実際の乱数幅の下限/上限だけ返す)
# ---------------------------------------------------------------------------

def preview_phys_damage(atk: int, vit: int,
                        mult: float = 1.0) -> tuple[int, int]:
    base = atk * 2.2 * mult - vit * 1.1
    return max(1, int(base * 0.9)), max(1, int(base * 1.1))


def preview_magic_damage(power: float, mag: int,
                         vit: int) -> tuple[int, int]:
    base = power + mag * 1.7 - vit * 0.8
    return max(1, int(base * 0.9)), max(1, int(base * 1.1))


@dataclass
class Popup:
    target: object          # Character | EnemyUnit
    text: str
    kind: str = "dmg"       # dmg / heal / mp / miss


@dataclass
class StepResult:
    lines: list[str] = field(default_factory=list)
    popups: list[Popup] = field(default_factory=list)
    actor: object | None = None      # 演出 (踏み込みアニメ) 用
    effect: str = ""                 # 戦闘エフェクト種別 (slash/fire/...)


class BattleEngine:
    def __init__(self, party: list[Character], enemies: list[EnemyUnit],
                 inventory: Inventory, rng: random.Random,
                 can_escape: bool = True) -> None:
        self.party = party
        self.enemies = enemies
        self.inventory = inventory
        self.rng = rng
        self.can_escape = can_escape
        self.outcome: str | None = None   # victory / defeat / escape
        self.ready: list[Character] = []
        self._enemy_delay = 0.6           # 敵の行動間隔 (CT風のテンポ)
        for ch in party:
            ch.flags.clear()
            ch.atb = ATB_MAX if ch.has_passive("p_sakigake") \
                else rng.uniform(0, 45)
        for en in enemies:
            en.atb = rng.uniform(0, 30)

    # ------------------------------------------------------------------
    # 時間経過
    # ------------------------------------------------------------------

    def tick(self, dt: float) -> list[StepResult]:
        """ATBを進め、行動した敵の結果を返す。

        アクティブ制: メニュー中も呼ばれ続ける。敵は _enemy_delay の
        間隔をあけて1体ずつ行動する (CT風のテンポ)。
        """
        if self.outcome:
            return []
        self._enemy_delay = max(0.0, self._enemy_delay - dt)
        for ch in self.party:
            if ch.alive and ch not in self.ready:
                ch.atb = min(ATB_MAX, ch.atb + atb_rate(ch.spd, ch.flags) * dt)
                if ch.atb >= ATB_MAX:
                    ch.flags.discard("defend")
                    self.ready.append(ch)
        for en in self.enemies:
            if en.alive:
                en.atb = min(ATB_MAX, en.atb + atb_rate(en.spd, en.flags) * dt)
        if self._enemy_delay <= 0:
            for en in self.enemies:
                if en.alive and en.atb >= ATB_MAX:
                    # やけど中は「DoT→行動」を交互に (連続でDoTだけ入らない)
                    if "burn" in en.flags and "burn_ticked" not in en.flags:
                        en.flags.add("burn_ticked")
                        result = self._burn_tick(en)
                        self._enemy_delay = 0.6
                    else:
                        en.flags.discard("burn_ticked")
                        result = self._enemy_act(en)
                        self._enemy_delay = 0.8
                    self._check_outcome()
                    return [result]
        return []

    # ------------------------------------------------------------------
    # 味方コマンド (シーンから呼ばれる)
    # ------------------------------------------------------------------

    def _spend_turn(self, actor: Character) -> None:
        actor.atb = 0.0
        if actor in self.ready:
            self.ready.remove(actor)

    def _hit_enemy(self, res: StepResult, target: EnemyUnit,
                   dmg: int, crit: bool = False) -> None:
        if crit:
            res.lines.append("クリティカル！")
        target.hp = max(0, target.hp - dmg)
        res.popups.append(Popup(target, str(dmg)))
        if not target.alive:
            res.lines.append(f"{target.name}を たおした！")

    def do_attack(self, actor: Character, target: EnemyUnit,
                  mult: float = 1.0, label: str | None = None,
                  effect: str = "slash") -> StepResult:
        res = StepResult(actor=actor, effect=effect)
        res.lines.append(label or f"{actor.name}の こうげき！")
        if "charge" in actor.flags:
            actor.flags.discard("charge")
            mult *= 2.0
        dmg, crit = phys_damage(actor.atk, target.vit, self.rng, mult)
        self._hit_enemy(res, target, dmg, crit)
        self._spend_turn(actor)
        self._check_outcome()
        return res

    def do_ability(self, actor: Character, ab: Ability,
                   target: object | None,
                   group: list[EnemyUnit] | None = None) -> StepResult:
        """group: 範囲技 (radius>0) でシーンが算出した巻き込み対象."""
        res = StepResult(actor=actor, effect=ab.effect)
        actor.mp -= ab.mp
        tag = ab.tag
        if tag == "phys":
            return self.do_attack(actor, target, ab.power,
                                  f"{actor.name}の {ab.name}！",
                                  effect=ab.effect or "slash")
        if tag == "phys_all":
            res.lines.append(f"{actor.name}の {ab.name}！")
            mult = ab.power
            if "charge" in actor.flags:
                actor.flags.discard("charge")
                mult *= 2.0
            pool = group if group is not None \
                else [e for e in self.enemies if e.alive]
            for en in [e for e in pool if e.alive]:
                dmg, _ = phys_damage(actor.atk, en.vit, self.rng, mult)
                self._hit_enemy(res, en, dmg)
        elif tag in ("magic", "magic_all"):
            res.lines.append(f"{actor.name}は {ab.name}を となえた！")
            if tag == "magic_all":
                targets = group if group is not None \
                    else [e for e in self.enemies if e.alive]
                targets = [e for e in targets if e.alive]
            else:
                targets = [target]
            for en in targets:
                dmg = magic_damage(ab.power, actor.mag, en.vit, self.rng)
                mult = element_multiplier(ab.element, en)
                if mult > 1.0:
                    dmg = int(dmg * mult)
                    res.lines.append("きかいに とくこうだ！")
                if "protect" in en.flags:
                    dmg = int(dmg * 0.7)
                self._hit_enemy(res, en, dmg)
                self._apply_element(res, ab.element, en, dmg)
        elif tag == "heal":
            amt = heal_amount(ab.power, actor.mag, self.rng)
            target.hp = min(target.max_hp, target.hp + amt)
            res.lines.append(f"{actor.name}の {ab.name}！")
            res.popups.append(Popup(target, str(amt), "heal"))
        elif tag == "raise":
            res.lines.append(f"{actor.name}の {ab.name}！")
            if target.alive:
                res.lines.append("しかし なにもおこらなかった…")
            else:
                target.hp = max(1, target.max_hp * 2 // 5)
                res.lines.append(f"{target.name}は いきかえった！")
                res.popups.append(Popup(target, str(target.hp), "heal"))
        elif tag == "protect":
            target.flags.add("protect")
            res.lines.append(f"{actor.name}の {ab.name}！ "
                             f"{target.name}の ぼうぎょが あがった！")
        elif tag == "haste":
            target.flags.discard("slow")
            target.flags.add("haste")
            res.lines.append(f"{actor.name}の {ab.name}！ "
                             f"{target.name}は はやくなった！")
        elif tag == "slow":
            target.flags.discard("haste")
            target.flags.add("slow")
            res.lines.append(f"{actor.name}の {ab.name}！ "
                             f"{target.name}は おそくなった！")
        elif tag == "charge":
            actor.flags.add("charge")
            res.lines.append(f"{actor.name}は ちからを ためている！")
        elif tag == "bunshin":
            actor.flags.add("bunshin")
            res.lines.append(f"{actor.name}は ぶんしんを つくりだした！")
        elif tag in ("steal", "mug"):
            res.lines.append(f"{actor.name}の {ab.name}！")
            if tag == "mug":
                dmg, crit = phys_damage(actor.atk, target.vit, self.rng)
                self._hit_enemy(res, target, dmg, crit)
            if target.alive or tag == "steal":
                self._try_steal(res, target)
        self._spend_turn(actor)
        self._check_outcome()
        return res

    def _apply_element(self, res: StepResult, element: str,
                       target: EnemyUnit, dmg: int) -> None:
        """属性の追加効果を命中後に適用する (倒した相手には付かない)."""
        if not target.alive or not element:
            return
        if element == "fire":
            target.flags.add("burn")
            target.burn_left = BURN_TICKS
            target.burn_dmg = max(1, int(dmg * BURN_RATIO))
            res.lines.append(f"{target.name}は やけどを おった！")
        elif element == "ice":
            target.atb = max(0.0, target.atb - ICE_ATB_DELAY)
            res.lines.append(f"{target.name}の うごきが おくれた！")

    def _burn_tick(self, en: EnemyUnit) -> StepResult:
        """やけどの継続ダメージ。対象の行動タイミングを1回分消費する."""
        res = StepResult(effect="fire")
        res.lines.append(f"{en.name}は やけどで くるしんでいる！")
        self._hit_enemy(res, en, en.burn_dmg)
        en.burn_left -= 1
        if en.burn_left <= 0 and en.alive:
            en.flags.discard("burn")
            res.lines.append(f"{en.name}の ほのおが きえた。")
        return res

    def _try_steal(self, res: StepResult, target: EnemyUnit) -> None:
        if target.stolen or target.species.steal is None:
            res.lines.append("なにも もっていない！")
        elif self.rng.random() < 0.7:
            target.stolen = True
            gil = max(1, target.gil)
            self.inventory.gil += gil
            res.lines.append(f"{gil}ギルを ぬすんだ！")
        else:
            res.lines.append("ぬすめなかった！")

    def do_item(self, actor: Character, item_id: str,
                target: Character) -> StepResult:
        from jobquest.models import ITEMS

        res = StepResult()
        name, tag, power = ITEMS[item_id]
        self.inventory.use(item_id)
        res.lines.append(f"{actor.name}は {name}を つかった！")
        if tag == "heal":
            target.hp = min(target.max_hp, target.hp + power)
            res.popups.append(Popup(target, str(power), "heal"))
        elif tag == "mp":
            target.mp = min(target.max_mp, target.mp + power)
            res.popups.append(Popup(target, str(power), "mp"))
        self._spend_turn(actor)
        return res

    def do_defend(self, actor: Character) -> StepResult:
        actor.flags.add("defend")
        self._spend_turn(actor)
        return StepResult([f"{actor.name}は みをまもっている。"])

    def do_escape(self, actor: Character) -> StepResult:
        self._spend_turn(actor)
        if not self.can_escape:
            return StepResult(["にげられない！"])
        avg_p = sum(c.spd for c in self.party if c.alive) / \
            max(1, sum(1 for c in self.party if c.alive))
        avg_e = sum(e.spd for e in self.enemies if e.alive) / \
            max(1, sum(1 for e in self.enemies if e.alive))
        chance = min(0.9, max(0.25, 0.5 + (avg_p - avg_e) * 0.02))
        if self.rng.random() < chance:
            self.outcome = "escape"
            return StepResult(["うまく にげきれた！"])
        return StepResult([f"{actor.name}は にげだした… "
                           "しかし まわりこまれてしまった！"])

    def preview_damage(self, actor: Character, kind: str, payload,
                      target: object) -> tuple[int, int] | None:
        """カーソル/コマンド選択中のダメージ目安 (下限, 上限)。表示専用で

        rngは一切消費しない (実行結果の再現性に影響を与えないため)。
        対象外の組み合わせ (回復・自己バフ・敵以外など) は None を返す。
        """
        if not isinstance(target, EnemyUnit):
            return None
        charge = 2.0 if "charge" in actor.flags else 1.0
        if kind == "attack":
            return preview_phys_damage(actor.atk, target.vit, charge)
        if kind == "ability":
            ab: Ability = payload
            if ab.tag in ("phys", "phys_all"):
                return preview_phys_damage(actor.atk, target.vit,
                                           ab.power * charge)
            if ab.tag in ("magic", "magic_all"):
                lo, hi = preview_magic_damage(ab.power, actor.mag, target.vit)
                # 属性倍率 (きかい特効など) も予測に反映する
                mult = element_multiplier(ab.element, target)
                return max(1, int(lo * mult)), max(1, int(hi * mult))
            return None
        if kind == "combo":
            cb: Combo = payload
            members = [m for m in (self._member(n) for n in cb.members)
                      if m is not None]
            base = (sum(m.atk for m in members)
                    + sum(m.mag for m in members)) * 0.6 * cb.power
            return preview_magic_damage(base, 0, target.vit)
        return None

    # -- 連携技 ------------------------------------------------------------

    def available_combos(self, actor: Character) -> list[Combo]:
        ready_names = {c.name for c in self.ready if c.alive}
        out = []
        for cb in COMBOS:
            if actor.name not in cb.members:
                continue
            members = [self._member(n) for n in cb.members]
            if any(m is None or not m.alive for m in members):
                continue
            if not all(m.name in ready_names for m in members):
                continue
            if all(m.mp >= cost for m, cost in zip(members, cb.mp)):
                out.append(cb)
        return out

    def _member(self, name: str) -> Character | None:
        return next((c for c in self.party if c.name == name), None)

    def do_combo(self, cb: Combo, target: EnemyUnit | None,
                 group: list[EnemyUnit] | None = None) -> StepResult:
        members = [self._member(n) for n in cb.members]
        for ch, cost in zip(members, cb.mp):
            ch.mp -= cost
        res = StepResult([f"れんけいわざ 『{cb.name}』！"], actor=members[0],
                         effect=cb.effect)
        base = (sum(c.atk for c in members)
                + sum(c.mag for c in members)) * 0.6 * cb.power
        if cb.target == "enemies":
            targets = [e for e in self.enemies if e.alive]
        elif group is not None:
            targets = [e for e in group if e.alive]
        else:
            targets = [target]
        for en in targets:
            dmg = magic_damage(base, 0, en.vit, self.rng)
            self._hit_enemy(res, en, dmg)
        for ch in members:
            self._spend_turn(ch)
        self._check_outcome()
        return res

    # ------------------------------------------------------------------
    # 敵の行動
    # ------------------------------------------------------------------

    def _enemy_act(self, en: EnemyUnit) -> StepResult:
        en.atb = 0.0
        en.flags.discard("defend")
        action = self._pick_enemy_action(en)
        heroes = [c for c in self.party if c.alive]
        target = self.rng.choice(heroes)
        effects = {"attack": "slash", "fire": "fire", "fira": "fire",
                   "thunder": "bolt", "slow": "status", "meteo": "burst"}
        res = StepResult(actor=en, effect=effects.get(action, "slash"))
        if action == "attack":
            res.lines.append(f"{en.name}の こうげき！")
            dmg, crit = phys_damage(en.atk, target.vit, self.rng)
            if crit:
                res.lines.append("いたいところに あたった！")
            self._hit_hero(res, en, target, dmg, physical=True)
        elif action in ("fire", "fira", "thunder"):
            spell = ABILITIES[action]
            res.lines.append(f"{en.name}は {spell.name}を となえた！")
            dmg = magic_damage(spell.power, en.mag, target.vit, self.rng)
            self._hit_hero(res, en, target, dmg, physical=False)
        elif action == "slow":
            target.flags.discard("haste")
            target.flags.add("slow")
            res.lines.append(f"{en.name}の スロウ！ "
                             f"{target.name}は おそくなった！")
        elif action == "meteo":
            res.lines.append(f"{en.name}は いんせきを よびよせた！")
            for ch in heroes:
                dmg = magic_damage(70, en.mag, ch.vit, self.rng)
                self._hit_hero(res, en, ch, dmg, physical=False)
        return res

    def _pick_enemy_action(self, en: EnemyUnit) -> str:
        sp = en.species
        if (sp.desperation and en.hp < en.max_hp * 0.4
                and self.rng.random() < 0.35):
            return sp.desperation
        actions = [a for a, _ in sp.actions]
        weights = [w for _, w in sp.actions]
        return self.rng.choices(actions, weights=weights, k=1)[0]

    def _hit_hero(self, res: StepResult, attacker: EnemyUnit,
                  target: Character, dmg: int, physical: bool) -> None:
        if physical and "bunshin" in target.flags:
            target.flags.discard("bunshin")
            res.lines.append(f"{target.name}の ぶんしんが みがわりになった！")
            res.popups.append(Popup(target, "MISS", "miss"))
            return
        if physical and target.has_passive("p_kage") \
                and self.rng.random() < 0.25:
            res.lines.append(f"{target.name}は ひらりと かわした！")
            res.popups.append(Popup(target, "MISS", "miss"))
            return
        if "defend" in target.flags:
            dmg = int(dmg * 0.5)
        if physical and "protect" in target.flags:
            dmg = int(dmg * 0.7)
        dmg = max(1, dmg)
        target.hp = max(0, target.hp - dmg)
        res.popups.append(Popup(target, str(dmg)))
        if not target.alive:
            target.flags.clear()
            if target in self.ready:
                self.ready.remove(target)
            res.lines.append(f"{target.name}は たおれた！")
        elif physical and target.has_passive("p_counter"):
            cdmg, _ = phys_damage(target.atk, attacker.vit, self.rng)
            res.lines.append(f"{target.name}の カウンター！")
            self._hit_enemy(res, attacker, cdmg)

    # ------------------------------------------------------------------
    # 決着
    # ------------------------------------------------------------------

    def _check_outcome(self) -> None:
        if self.outcome:
            return
        if not any(e.alive for e in self.enemies):
            self.outcome = "victory"
        elif not any(c.alive for c in self.party):
            self.outcome = "defeat"

    def victory_lines(self) -> list[str]:
        """報酬とレベルアップの一括処理。メッセージ行を返す."""
        exp = sum(e.exp for e in self.enemies)
        abp = sum(e.abp for e in self.enemies)
        gil = sum(e.gil for e in self.enemies)
        self.inventory.gil += gil
        lines = ["たたかいに かった！",
                 f"EXP {exp}  ABP {abp}  {gil}ギル かくとく！"]
        for ch in self.party:
            if not ch.alive:
                continue
            lines += ch.gain_exp(exp)
            lines += ch.gain_abp(abp)
        for ch in self.party:
            ch.flags.clear()
            ch.hp = max(ch.hp, 1)
        from jobquest.nodes import full_restore

        full_restore(self.party)
        return lines
