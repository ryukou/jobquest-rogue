"""Chiptune-style sound effects synthesized at startup (音源ファイル不要).

矩形波/ノイズを16bitモノラルで直接生成する。numpy不要。
mixerが初期化できない環境では play() は何もしない。
"""

from __future__ import annotations

import math
import random
import struct

import pygame

_RATE = 22050
_sounds: dict[str, pygame.mixer.Sound] = {}
_ok = False


def _tone(freq: float, ms: int, vol: float = 0.5,
          shape: str = "square", slide: float = 1.0) -> bytes:
    """slide: 再生中に周波数を slide 倍まで変化させる."""
    n = max(1, int(_RATE * ms / 1000))
    out = bytearray()
    phase = 0.0
    rnd = random.Random(1234)
    for i in range(n):
        t = i / n
        f = freq * (1.0 + (slide - 1.0) * t)
        phase += f / _RATE
        if shape == "square":
            v = 1.0 if phase % 1.0 < 0.5 else -1.0
        elif shape == "noise":
            v = rnd.uniform(-1.0, 1.0)
        else:  # sine
            v = math.sin(math.tau * phase)
        attack = min(1.0, i / (0.01 * _RATE))
        release = min(1.0, (n - i) / (n * 0.35))
        out += struct.pack("<h", int(32767 * 0.30 * vol * v
                                     * attack * release))
    return bytes(out)


def _silence(ms: int) -> bytes:
    return b"\x00\x00" * max(1, int(_RATE * ms / 1000))


def _build() -> dict[str, bytes]:
    c5, e5, g5, c6 = 523.25, 659.26, 783.99, 1046.5
    return {
        "cursor": _tone(1750, 24, 0.35),
        "confirm": _tone(1046, 35, 0.4) + _tone(1568, 60, 0.4),
        "cancel": _tone(520, 60, 0.35, slide=0.6),
        "hit": _tone(220, 70, 0.7, "noise") + _tone(110, 60, 0.5, slide=0.5),
        "heal": _tone(660, 60, 0.35, "sine") + _tone(880, 60, 0.35, "sine")
        + _tone(1320, 100, 0.35, "sine"),
        "miss": _tone(880, 40, 0.3, slide=0.4),
        "magic": _tone(300, 220, 0.4, "sine", slide=5.0),
        "battle": _tone(160, 90, 0.6, "noise")
        + _tone(392, 70, 0.5) + _tone(311, 70, 0.5) + _tone(233, 120, 0.5),
        "victory": _tone(g5, 90, 0.45) + _tone(g5, 90, 0.45)
        + _tone(g5, 90, 0.45) + _tone(c6, 320, 0.45),
        "gameover": _tone(c5, 200, 0.4, slide=0.9)
        + _tone(415, 200, 0.4, slide=0.9) + _tone(330, 420, 0.4, slide=0.8),
        "save": _tone(c5, 70, 0.4, "sine") + _tone(e5, 70, 0.4, "sine")
        + _tone(g5, 70, 0.4, "sine") + _tone(c6, 200, 0.4, "sine"),
        "gate": _tone(1400, 550, 0.4, "sine", slide=0.12)
        + _tone(200, 250, 0.35, "noise"),
    }


def init() -> None:
    global _ok
    if _ok:
        return
    try:
        pygame.mixer.init(_RATE, -16, 1, 512)
        pygame.mixer.set_num_channels(8)
    except pygame.error:
        return
    for name, raw in _build().items():
        _sounds[name] = pygame.mixer.Sound(buffer=raw)
    _ok = True


def play(name: str) -> None:
    if _ok and name in _sounds:
        _sounds[name].play()
