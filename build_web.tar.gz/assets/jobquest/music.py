"""Chiptune BGM synthesized at startup (音源ファイル不要).

音名パターン文字列 ("c5:.5 e5:1 r:.5" = ド半拍 ミ1拍 休符半拍) を
矩形波/三角波/ノイズでレンダリングし、複数チャンネルをミックスして
ループ再生する。パース/レンダリングは pygame 非依存 (テスト対象)。
"""

from __future__ import annotations

import math
import random
import struct
from pathlib import Path

import pygame

_RATE = 22050
_ASSET_DIR = Path(__file__).parent / "assets" / "bgm"
_TRACK_NAMES = ("title", "field", "future", "battle", "boss", "ending")
_SEMI = {"c": 0, "d": 2, "e": 4, "f": 5, "g": 7, "a": 9, "b": 11}

_ok = False
_tracks: dict[str, pygame.mixer.Sound] = {}
_channel: pygame.mixer.Channel | None = None
_current: str | None = None


def note_freq(token: str) -> float:
    """"a4"=440Hz。s=シャープ f=フラット (例 "gs4", "bf3")."""
    letter = token[0]
    body = token[1:]
    acc = 0
    if body and body[0] == "s":
        acc, body = 1, body[1:]
    elif body and body[0] == "f":
        acc, body = -1, body[1:]
    midi = 12 * (int(body) + 1) + _SEMI[letter] + acc
    return 440.0 * 2 ** ((midi - 69) / 12)


def render(pattern: str, tempo: float, wave: str = "square",
           vol: float = 0.18, duty: float = 0.5,
           vibrato: float = 0.0) -> list[float]:
    """パターン文字列を -1..1 のサンプル列に変換する.

    duty: 矩形波のデューティ比 (0.25でファミコンのリード風)
    vibrato: >0 でビブラート (音程ゆらぎ) の深さ
    """
    beat = 60.0 / tempo
    out: list[float] = []
    rnd = random.Random(7)
    for token in pattern.split():
        name, dur_s = token.split(":")
        n = int(_RATE * beat * float(dur_s))
        if name == "r":
            out.extend(0.0 for _ in range(n))
            continue
        if name == "x":  # ノイズ (パーカッション)
            for i in range(n):
                env = max(0.0, 1.0 - i / (n * 0.45 + 1))
                out.append(rnd.uniform(-1, 1) * vol * env)
            continue
        freq = note_freq(name)
        phase = 0.0
        for i in range(n):
            f = freq
            if vibrato > 0 and i > 0.12 * _RATE:
                f *= 1.0 + vibrato * math.sin(math.tau * 5.5 * i / _RATE)
            phase += f / _RATE
            p = phase % 1.0
            if wave == "square":
                v = 1.0 if p < duty else -1.0
            else:  # tri
                v = 4.0 * abs(p - 0.5) - 1.0
            attack = min(1.0, i / (0.004 * _RATE))
            release = min(1.0, (n - i) / (0.02 * _RATE))
            out.append(v * vol * attack * release)
    return out


def echo(channel: list[float], delay: float = 0.16,
         gain: float = 0.32) -> list[float]:
    """エコーを重ねたチャンネルを返す。尾はループ先頭へ回り込ませる."""
    d = int(_RATE * delay)
    n = len(channel)
    out = list(channel)
    for i, s in enumerate(channel):
        out[(i + d) % n] += s * gain
    return out


def mix(*channels: list[float]) -> bytes:
    n = max(len(c) for c in channels)
    buf = bytearray()
    for i in range(n):
        s = sum(c[i] for c in channels if i < len(c))
        s = max(-0.95, min(0.95, s))
        buf += struct.pack("<h", int(s * 32767))
    return bytes(buf)


# ---------------------------------------------------------------------------
# 楽曲データ
# ---------------------------------------------------------------------------

def _bars(*bars: str) -> str:
    return " ".join(bars)


def _songs() -> dict[str, bytes]:
    songs: dict[str, bytes] = {}

    # タイトル: しずかなアルペジオ (C - Am - F - G)
    tempo = 100
    arp = _bars(
        "c4:.5 e4:.5 g4:.5 c5:.5 e5:.5 c5:.5 g4:.5 e4:.5",
        "a3:.5 c4:.5 e4:.5 a4:.5 c5:.5 a4:.5 e4:.5 c4:.5",
        "f3:.5 a3:.5 c4:.5 f4:.5 a4:.5 f4:.5 c4:.5 a3:.5",
        "g3:.5 b3:.5 d4:.5 g4:.5 b4:.5 g4:.5 d4:.5 b3:.5",
    )
    lead = _bars("g5:2 e5:2", "e5:2 c5:2", "a4:2 c5:2", "b4:2 d5:2")
    songs["title"] = mix(
        render(arp, tempo, "tri", 0.16),
        echo(render(lead, tempo, "square", 0.09, duty=0.25,
                    vibrato=0.006)))

    # フィールド (げんざい): あかるいマーチ (A-A'-B 12小節)
    tempo = 132
    melody = _bars(
        "g4:.5 c5:.5 e5:1 d5:.5 e5:.5 c5:1",
        "a4:.5 c5:.5 f5:1 e5:.5 d5:.5 c5:1",
        "g4:.5 b4:.5 d5:1 c5:.5 d5:.5 e5:1",
        "f5:.5 e5:.5 d5:.5 c5:.5 d5:1 g4:1",
        "e5:.5 g5:.5 c6:1 b5:.5 g5:.5 e5:1",
        "f5:.5 a5:.5 c6:1 a5:.5 f5:.5 d5:1",
        "d5:.5 g5:.5 b5:1 a5:.5 b5:.5 d6:1",
        "c6:1 g5:1 e5:1 c5:1",
        "e5:.5 d5:.5 c5:.5 d5:.5 e5:1 g5:1",
        "a5:.5 g5:.5 f5:.5 e5:.5 f5:1 a5:1",
        "g5:.5 f5:.5 e5:.5 d5:.5 e5:1 c5:1",
        "d5:1 e5:.5 d5:.5 c5:1 g4:1",
    )
    bass = _bars(
        "c3:1 g3:1 c3:1 g3:1", "f2:1 c3:1 f3:1 c3:1",
        "g2:1 d3:1 g3:1 d3:1", "c3:1 g2:1 c3:1 c3:1",
        "c3:1 g3:1 c3:1 g3:1", "f2:1 c3:1 f3:1 c3:1",
        "g2:1 d3:1 g3:1 d3:1", "c3:1 g2:1 c3:2",
        "c3:1 g3:1 a3:1 g3:1", "f2:1 c3:1 f3:1 c3:1",
        "c3:1 g3:1 a3:1 e3:1", "g2:1 g2:1 c3:2",
    )
    perc = " ".join(["x:1 r:.5 x:.5 x:1 r:1"] * 12)
    songs["field"] = mix(
        echo(render(melody, tempo, "square", 0.12, duty=0.25,
                    vibrato=0.005)),
        render(bass, tempo, "tri", 0.20),
        render(perc, tempo, "square", 0.05))

    # みらい (荒廃): くらいアンビエント
    tempo = 100
    pad = _bars("a3:2 e4:2", "c4:2 a3:2", "f3:2 c4:2", "e3:2 b3:2")
    lead = _bars("a4:3 r:1", "c5:3 r:1", "b4:3 r:1", "g4:2 e4:2")
    low = _bars("a2:4", "a2:4", "f2:4", "e2:4")
    songs["future"] = mix(
        render(pad, tempo, "tri", 0.15),
        echo(render(lead, tempo, "square", 0.06, duty=0.25,
                    vibrato=0.01), delay=0.24, gain=0.45),
        render(low, tempo, "tri", 0.16))

    # 通常戦闘: はしるAmロック
    tempo = 150
    melody = _bars(
        "a4:.5 c5:.5 e5:.5 c5:.5 d5:.5 c5:.5 b4:.5 g4:.5",
        "b4:.5 d5:.5 g5:.5 d5:.5 e5:.5 d5:.5 c5:.5 b4:.5",
        "a4:.5 c5:.5 f5:.5 c5:.5 d5:1 c5:.5 a4:.5",
        "gs4:.5 b4:.5 e5:.5 b4:.5 gs4:.5 e4:.5 b4:1",
        "a4:.5 e5:.5 a5:.5 e5:.5 f5:.5 e5:.5 d5:.5 c5:.5",
        "g4:.5 d5:.5 g5:.5 d5:.5 e5:.5 d5:.5 b4:.5 g4:.5",
        "f5:.5 e5:.5 d5:.5 c5:.5 bf4:.5 a4:.5 g4:.5 f4:.5",
        "e5:1 b4:.5 gs4:.5 e4:2",
    )

    def pump(root: str, fifth: str, sub: str) -> str:
        return (f"{root}:.5 {root}:.5 {fifth}:.5 {root}:.5 "
                f"{root}:.5 {root}:.5 {sub}:.5 {root}:.5")

    bass = _bars(pump("a2", "e3", "g2"), pump("g2", "d3", "f2"),
                 pump("f2", "c3", "e2"), pump("e2", "b2", "d2"),
                 pump("a2", "e3", "g2"), pump("g2", "d3", "f2"),
                 pump("f2", "c3", "e2"), pump("e2", "b2", "d2"))
    perc = " ".join(["x:.5 r:.5 x:.5 r:.5 x:.5 r:.5 x:.5 x:.5"] * 8)
    songs["battle"] = mix(
        render(melody, tempo, "square", 0.13, duty=0.25, vibrato=0.004),
        render(bass, tempo, "square", 0.11),
        render(perc, tempo, "square", 0.06))

    # ボス戦: おもいDm
    tempo = 140
    melody = _bars(
        "d5:1.5 e5:.5 f5:1 e5:.5 d5:.5",
        "c5:1.5 d5:.5 e5:1 c5:1",
        "bf4:1.5 c5:.5 d5:1 c5:.5 bf4:.5",
        "a4:2 cs5:1 a4:1",
    )

    def heavy(root: str, fifth: str, high: str) -> str:
        return (f"{root}:.5 {root}:.5 {fifth}:.5 {root}:.5 "
                f"{high}:.5 {root}:.5 {fifth}:.5 {root}:.5")

    bass = _bars(heavy("d2", "a2", "d3"), heavy("c2", "g2", "c3"),
                 heavy("bf2", "f3", "bf2"), heavy("a2", "e3", "a2"))
    perc = " ".join(["x:1 r:.5 x:.5 x:1 x:1"] * 4)
    songs["boss"] = mix(
        render(melody, tempo, "square", 0.14, duty=0.25, vibrato=0.007),
        render(bass, tempo, "tri", 0.22),
        render(perc, tempo, "square", 0.07))

    # エンディング: あたたかいバラード (C - G - F - C)
    tempo = 84
    melody = _bars(
        "e5:1 g5:1 c6:2",
        "d6:1 b5:1 g5:2",
        "c6:1 a5:1 f5:2",
        "g5:1.5 e5:.5 c5:2",
        "a5:1 g5:1 e5:2",
        "f5:1 e5:1 d5:2",
        "e5:1 d5:1 c5:1 d5:1",
        "c5:4",
    )
    arp = _bars(
        "c3:.5 g3:.5 c4:.5 e4:.5 g4:.5 e4:.5 c4:.5 g3:.5",
        "g3:.5 d4:.5 g4:.5 b4:.5 d5:.5 b4:.5 g4:.5 d4:.5",
        "f3:.5 c4:.5 f4:.5 a4:.5 c5:.5 a4:.5 f4:.5 c4:.5",
        "c3:.5 g3:.5 c4:.5 e4:.5 g4:.5 e4:.5 c4:.5 g3:.5",
        "a3:.5 e4:.5 a4:.5 c5:.5 e5:.5 c5:.5 a4:.5 e4:.5",
        "f3:.5 c4:.5 f4:.5 a4:.5 c5:.5 a4:.5 f4:.5 c4:.5",
        "g3:.5 d4:.5 g4:.5 b4:.5 d5:.5 b4:.5 g4:.5 d4:.5",
        "c3:.5 g3:.5 c4:.5 e4:.5 g4:.5 c5:.5 e5:.5 g5:.5",
    )
    songs["ending"] = mix(
        echo(render(melody, tempo, "square", 0.10, duty=0.25,
                    vibrato=0.008), delay=0.22, gain=0.4),
        render(arp, tempo, "tri", 0.15))
    return songs


# ---------------------------------------------------------------------------
# 再生
# ---------------------------------------------------------------------------

def _load_prerendered() -> dict[str, bytes] | None:
    """ビルド時に書き出した .raw があれば合成をスキップ (WASM高速起動用)."""
    if not _ASSET_DIR.exists():
        return None
    out: dict[str, bytes] = {}
    for name in _TRACK_NAMES:
        path = _ASSET_DIR / f"{name}.raw"
        if not path.exists():
            return None
        out[name] = path.read_bytes()
    return out


def export_assets(dest: str) -> None:
    """全曲を .raw (16bit mono PCM) として書き出す (ビルドスクリプト用)."""
    dest_path = Path(dest)
    dest_path.mkdir(parents=True, exist_ok=True)
    for name, raw in _songs().items():
        (dest_path / f"{name}.raw").write_bytes(raw)


def init() -> None:
    """sfx.init() の後に呼ぶ (mixer初期化済みが前提)."""
    global _ok, _channel
    if _ok or not pygame.mixer.get_init():
        return
    pygame.mixer.set_reserved(1)
    _channel = pygame.mixer.Channel(0)
    songs = _load_prerendered() or _songs()
    for name, raw in songs.items():
        sound = pygame.mixer.Sound(buffer=raw)
        sound.set_volume(0.55)
        _tracks[name] = sound
    _ok = True


def play(name: str) -> None:
    global _current
    if not _ok or name == _current:
        return
    _current = name
    _channel.play(_tracks[name], loops=-1, fade_ms=350)


def stop(fade_ms: int = 400) -> None:
    global _current
    if not _ok:
        return
    _current = None
    _channel.fadeout(fade_ms)
