"""Japanese font loading: 同梱ピクセルフォント優先、システムフォントへフォールバック.

同梱の PixelMplus10 (M+ FONT LICENSE) を使うことで
- ブラウザ (pygbag/WASM) でも日本語が表示できる
- デスクトップでもスーファミ風のドット文字になる
"""

from __future__ import annotations

from pathlib import Path

import pygame

BUNDLED = Path(__file__).parent / "assets" / "fonts" / \
    "PixelMplus10-Regular.ttf"

# システムフォント候補 (同梱フォントが無い場合の保険)
_PATH_CANDIDATES = (
    "/System/Library/Fonts/ヒラギノ角ゴシック W4.ttc",
    "/System/Library/Fonts/Hiragino Sans W3.ttc",
    "C:/Windows/Fonts/meiryo.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
)

_resolved_path: str | None = None
_resolved = False
_cache: dict[int, pygame.font.Font] = {}


def _resolve() -> str | None:
    if BUNDLED.exists():
        return str(BUNDLED)
    for path in _PATH_CANDIDATES:
        if Path(path).exists():
            return path
    return pygame.font.match_font("hiraginosans,notosanscjkjp,meiryo")


def get_font(size: int) -> pygame.font.Font:
    """Return a cached font that can render Japanese text."""
    global _resolved, _resolved_path
    if not _resolved:
        _resolved_path = _resolve()
        _resolved = True
    font = _cache.get(size)
    if font is None:
        font = pygame.font.Font(_resolved_path, size)
        _cache[size] = font
    return font
