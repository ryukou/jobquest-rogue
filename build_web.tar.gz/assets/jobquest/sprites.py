"""Programmatic 16x16 pixel art (SNES風ドット絵).

pattern は 16行x16文字。'.' は透明、他の文字はパレットで色に変換。
キャラクター/敵にはアウトライン (暗色縁取り) を自動で付ける。
勇者キャラは 前/後ろ × 歩行2フレーム を部品合成で生成する。
頭部はジョブごとにシルエットも変える (ヘルメット/頭巾/とんがり帽子など) ので、
色だけでなく形でも見分けがつく。
"""

from __future__ import annotations

import pygame

OUTLINE = (24, 20, 40)

# ---------------------------------------------------------------------------
# タイル
# ---------------------------------------------------------------------------

GRASS = (
    "GGGGGGGGGGGGGGGG",
    "GGGgGGGGGGGGGGGG",
    "GGGGGGGGGGgGGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGgGGGGGGGGG",
    "GgGGGGGGGGGGGGgG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGGGgGGGGGG",
    "GGGGgGGGGGGGGGGG",
    "GGGGGGGGGGGGGgGG",
    "GgGGGGGGGGGGGGGG",
    "GGGGGGGgGGGGGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGgGGGGGGGGgGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGgGGGGGGGGG",
)

TREE = (
    "GGGGGLLLLLGGGGGG",
    "GGGLLLLLLLLLGGGG",
    "GGLLlLLLLLLLLGGG",
    "GLLLLLLLLlLLLLGG",
    "GLLlLLLLLLLLLLGG",
    "GLLLLLLLLLLLlLGG",
    "GLLLLLlLLLLLLLGG",
    "GGLLLLLLLLlLLGGG",
    "GGGLLLLLLLLLGGGG",
    "GGGGLLLLLLLGGGGG",
    "GGGGGGtttGGGGGGG",
    "GGGGGGtttGGGGGGG",
    "GGGGGGtttGGGGGGG",
    "GGGGGtttttGGGGGG",
    "GGgGGGGGGGGGgGGG",
    "GGGGGGGGGGGGGGGG",
)

WATER = (
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWwwwWWWWWWWWWWW",
    "WWWWWWWWWWwwwWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWwwWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWwwWW",
    "WWwwWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWwwwWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWwwWWWWWWWwwWWW",
    "WWWWWWWWWWWWWWWW",
)

WATER2 = (
    "WWWWWWWWWWWWWWWW",
    "WWwwwWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWwwwWW",
    "WWWWWWwwWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWwwWWWWWWWWWWW",
    "WWWWWWWWWWWwwWWW",
    "WWWWWWWWWWWWWWWW",
    "WWwwWWWWWWWWWWWW",
    "WWWWWWWWwwwWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWwwWWWWWWWwwWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
)

PATH = (
    "PPPPPPPPPPPPPPPP",
    "PPPpPPPPPPPPPPPP",
    "PPPPPPPPPPpPPPPP",
    "PPPPPPPPPPPPPPPP",
    "PPPPPpPPPPPPPPpP",
    "PPPPPPPPPPPPPPPP",
    "PpPPPPPPPpPPPPPP",
    "PPPPPPPPPPPPPPPP",
    "PPPPPPpPPPPPPpPP",
    "PPPPPPPPPPPPPPPP",
    "PPpPPPPPPPPpPPPP",
    "PPPPPPPPPPPPPPPP",
    "PPPPPPPPpPPPPPPP",
    "PpPPPPPPPPPPPPpP",
    "PPPPPPPPPPPPPPPP",
    "PPPPpPPPPPPPPPPP",
)

CRYSTAL = (
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGxGGGGGGGG",
    "GGGGGGxXxGGGGGGG",
    "GGGGGxXXXxGGGGGG",
    "GGGGxXXsXXxGGGGG",
    "GGGxXXssXXXxGGGG",
    "GGGxXXXXXXXxGGGG",
    "GGGGxXXXXXxGGGGG",
    "GGGGGxXXXxGGGGGG",
    "GGGGGGxXxGGGGGGG",
    "GGGGGGGxGGGGGGGG",
    "GGGGGmmmmmGGGGGG",
    "GGGGmmmmmmmGGGGG",
    "GGGGmmmmmmmGGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGGGGGGGGGG",
)

CRYSTAL2 = (
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGxGGGGGGGG",
    "GGGGGGxXxGGGGGGG",
    "GGGGGxXXXxGGGGGG",
    "GGGGxXXXXXxGGGGG",
    "GGGxXXXXsXXxGGGG",
    "GGGxXXXssXXxGGGG",
    "GGGGxXXXXXxGGGGG",
    "GGGGGxXXXxGGGGGG",
    "GGGGGGxXxGGGGGGG",
    "GGGGGGGxGGGGGGGG",
    "GGGGGmmmmmGGGGGG",
    "GGGGmmmmmmmGGGGG",
    "GGGGmmmmmmmGGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGGGGGGGGGG",
)

FLOOR = (
    "FFFFFFFfFFFFFFFf",
    "FFFFFFFfFFFFFFFf",
    "FFFFFFFfFFFFFFFf",
    "ffffffffffffffff",
    "FFFfFFFFFFFfFFFF",
    "FFFfFFFFFFFfFFFF",
    "FFFfFFFFFFFfFFFF",
    "ffffffffffffffff",
    "FFFFFFFfFFFFFFFf",
    "FFFFFFFfFFFFFFFf",
    "FFFFFFFfFFFFFFFf",
    "ffffffffffffffff",
    "FFFfFFFFFFFfFFFF",
    "FFFfFFFFFFFfFFFF",
    "FFFfFFFFFFFfFFFF",
    "ffffffffffffffff",
)

WALL = (
    "RRRRRRRrRRRRRRRr",
    "RRRRRRRrRRRRRRRr",
    "RRRRRRRrRRRRRRRr",
    "rrrrrrrrrrrrrrrr",
    "RRRrRRRRRRRrRRRR",
    "RRRrRRRRRRRrRRRR",
    "RRRrRRRRRRRrRRRR",
    "rrrrrrrrrrrrrrrr",
    "RRRRRRRrRRRRRRRr",
    "RRRRRRRrRRRRRRRr",
    "RRRRRRRrRRRRRRRr",
    "rrrrrrrrrrrrrrrr",
    "RRRrRRRRRRRrRRRR",
    "RRRrRRRRRRRrRRRR",
    "RRRrRRRRRRRrRRRR",
    "rrrrrrrrrrrrrrrr",
)

# 未来 (荒廃) タイル: かれくさ / かれき
DEAD_GRASS = tuple(row.translate(str.maketrans("Gg", "Dd")) for row in GRASS)
DEAD_TREE = (
    "DDDDDDkDDDDDDDDD",
    "DDkDDDkDDDkDDDDD",
    "DDDkDDkDDkDDDDDD",
    "DDDDkDkkDkDDDDDD",
    "DDDDDkkkkkDDkDDD",
    "DDDDDDtkkDkkDDDD",
    "DDDDDDtktkDDDDDD",
    "DDDDDDttkDDDDDDD",
    "DDDDDDttDDDDDDDD",
    "DDDDDDttDDDDDDDD",
    "DDDDDDttDDDDDDDD",
    "DDDDDDttDDDDDDDD",
    "DDDDDttttDDDDDDD",
    "DDDDDDDDDDDDDDDD",
    "DDDDDDDDDDDDDDDD",
    "DDDDDDDDDDDDDDDD",
)

TILE_PALETTE = {
    "G": (104, 176, 88), "g": (84, 152, 72),
    "L": (48, 112, 56), "l": (80, 152, 80), "t": (92, 68, 48),
    "W": (64, 112, 216), "w": (136, 176, 248),
    "P": (200, 168, 112), "p": (176, 144, 92),
    "x": (72, 200, 224), "X": (144, 240, 248), "s": (255, 255, 255),
    "m": (128, 128, 140),
    "F": (152, 148, 160), "f": (116, 112, 128),
    "R": (92, 88, 108), "r": (56, 52, 72),
    "D": (146, 128, 84), "d": (122, 106, 68), "k": (150, 132, 108),
}

# タイル: kind -> フレーム列 (アニメーションは複数フレーム)
TILE_PATTERNS: dict[str, tuple[tuple[str, ...], ...]] = {
    "G": (GRASS,), "T": (TREE,), "W": (WATER, WATER2), "P": (PATH,),
    "C": (CRYSTAL, CRYSTAL2), "F": (FLOOR,), "R": (WALL,),
    "D": (DEAD_GRASS,), "S": (DEAD_TREE,),
}

# 装飾 (草原の花や荒野の岩): タイルの上に重ねる
DECOR_PATTERNS = {
    "flower_r": (
        "................", "................", "................",
        "................", "......a.........", ".....aRa........",
        "......a.........", "......g.........", "................",
        "................", "..........a.....", ".........aRa....",
        "..........a.....", "..........g.....", "................",
        "................",
    ),
    "flower_y": (
        "................", "................", "................",
        "................", "................", "....Y...........",
        "...YsY..........", "....Y...........", "....g...........",
        "................", "................", "...........Y....",
        "..........YsY...", "...........Y....", "...........g....",
        "................",
    ),
    "tuft": (
        "................", "................", "................",
        "................", "................", "................",
        "................", "....g..g........", "....g.g.g.......",
        ".....gg.........", "................", "................",
        ".........g..g...", ".........g.g....", "..........g.....",
        "................",
    ),
    "rock": (
        "................", "................", "................",
        "................", "................", "................",
        "......mm........", ".....mmmm.......", ".....mmmm.......",
        "....mmmmmm......", "................", "................",
        "................", "................", "................",
        "................",
    ),
    "chest": (
        "................", "................", "................",
        "...bbbbbbbbbb...", "..bBBBBBBBBBBb..", "..bBBBBBBBBBBb..",
        "..bbbbbbbbbbbb..", "..bBBBBqqBBBBb..", "..bBBBBqqBBBBb..",
        "..bBBBBBBBBBBb..", "..bBBBBBBBBBBb..", "..bbbbbbbbbbbb..",
        "................", "................", "................",
        "................",
    ),
    "chest_open": (
        "................", "................", "................",
        "...bbbbbbbbbb...", "..bkkkkkkkkkkb..", "..bkkkkkkkkkkb..",
        "..bbbbbbbbbbbb..", "..bBBBBBBBBBBb..", "..bBBBBqqBBBBb..",
        "..bBBBBBBBBBBb..", "..bBBBBBBBBBBb..", "..bbbbbbbbbbbb..",
        "................", "................", "................",
        "................",
    ),
    "stairs": (
        "................", "..kkkkkkkkkkkk..", "..kkkkkkkkkkkk..",
        "..kkmmmmmmmmkk..", "..kkkkkkkkkkkk..", "..kkmmmmmmkkkk..",
        "..kkkkkkkkkkkk..", "..kkmmmmkkkkkk..", "..kkkkkkkkkkkk..",
        "..kkmmkkkkkkkk..", "..kkkkkkkkkkkk..", "..kkkkkkkkkkkk..",
        "..kkkkkkkkkkkk..", "................", "................",
        "................",
    ),
}

DECOR_PALETTE = {
    "a": (240, 240, 248), "R": (232, 96, 112), "Y": (248, 216, 88),
    "s": (255, 255, 255), "g": (72, 136, 64), "m": (108, 96, 76),
    "b": (146, 96, 48), "B": (196, 144, 72), "q": (248, 216, 88),
    "k": (28, 26, 40),
}

# ---------------------------------------------------------------------------
# キャラクター: 部品合成で 前/後ろ × 歩行2フレーム
# ---------------------------------------------------------------------------

_HERO_HEAD_FRONT = (
    "....hhhhhhhh....",
    "...hhhhhhhhhh...",
    "..hhhhhhhhhhhh..",
    "..hhsssssssshh..",
    "..hssssssssssh..",
    "..hsskssskssh...",
    "...ssssssssss...",
    "....ssssssss....",
)

_HERO_HEAD_BACK = (
    "....hhhhhhhh....",
    "...hhhhhhhhhh...",
    "..hhhhhhhhhhhh..",
    "..hhhhhhhhhhhh..",
    "..hhhhhhhhhhhh..",
    "..hhhhhhhhhhhh..",
    "...hhhhhhhhhh...",
    "....ssssssss....",
)

# ジョブごとの頭部シルエット (色だけでなく形も変えて一目で見分けられるように)。
# 'c' はジョブカラー (体と共通)、'e' は魔法職の光る目 (固定の明るい色)。
# 未登録のジョブ (すっぴん等) は素の髪型 (_HERO_HEAD_FRONT/BACK) を使う。
_JOB_HEAD_FRONT = {
    "knight": (  # 顔まわりを覆う金属ヘルメット
        "....cccccccc....",
        "...cccccccccc...",
        "..cccccccccccc..",
        "..ccsssssssscc..",
        "..cssssssssssc..",
        "..csskssskssc...",
        "...ssssssssss...",
        "....ssssssss....",
    ),
    "monk": (  # 鉢巻き (髪はそのまま見える)
        "....hhhhhhhh....",
        "...hhhhhhhhhh...",
        "..hhhhhhhhhhhh..",
        "..cccccccccccc..",
        "..hssssssssssh..",
        "..hsskssskssh...",
        "...ssssssssss...",
        "....ssssssss....",
    ),
    "thief": (  # 頭に巻いたバンダナ (縁がギザギザ)
        "....cccccccc....",
        "...cccccccccc...",
        "..cccccccccccc..",
        "..chchchchchcc..",
        "..cssssssssssc..",
        "..csskssskssc...",
        "...ssssssssss...",
        "....ssssssss....",
    ),
    "ninja": (  # 頭巾+マスクで目もとしか見えない
        "....cccccccc....",
        "...cccccccccc...",
        "..cccccccccccc..",
        "..cckkcckkccc...",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "...cccccccccc...",
    ),
    "black": (  # 目深にかぶった とんがり帽子。素顔は見えず目だけ光る
        "........c.......",
        ".......ccc......",
        "......ccccc.....",
        ".....ccccccc....",
        "....ccccccccc...",
        "..ccccceeeccc...",
        "..cccccccccccc..",
        "...cccccccccc...",
    ),
    "white": (  # やわらかいフード (顔は見える)
        "....cccccccc....",
        "...cccccccccc...",
        "..cccccccccccc..",
        "..cscscscscscc..",
        "..cssssssssssc..",
        "..csskssskssc...",
        "...ssssssssss...",
        "....ssssssss....",
    ),
    "time": (  # つばの広い とんがり帽子。素顔は見える
        ".......cc.......",
        "......cccc......",
        ".....cccccc.....",
        "....ccccccccc...",
        "..ccsssssssscc..",
        "..csskssskssc...",
        "...ssssssssss...",
        "....ssssssss....",
    ),
}

_JOB_HEAD_BACK = {
    "knight": (
        "....cccccccc....",
        "...cccccccccc...",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "...cccccccccc...",
        "....ssssssss....",
    ),
    "monk": (
        "....hhhhhhhh....",
        "...hhhhhhhhhh...",
        "..hhhhhhhhhhhh..",
        "..cccccccccccc..",
        "..hhhhhhhhhhhh..",
        "..hhhhhhhhhhhh..",
        "...hhhhhhhhhh...",
        "....ssssssss....",
    ),
    "thief": (
        "....cccccccc....",
        "...cccccccccc...",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "...cccccccccc...",
        "....ssssssss....",
    ),
    "ninja": (
        "....cccccccc....",
        "...cccccccccc...",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "...cccccccccc...",
        "....cccccccc....",
    ),
    "black": (
        "........c.......",
        ".......ccc......",
        "......ccccc.....",
        ".....ccccccc....",
        "....ccccccccc...",
        "..ccccccccccc...",
        "..cccccccccccc..",
        "...cccccccccc...",
    ),
    "white": (
        "....cccccccc....",
        "...cccccccccc...",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "...cccccccccc...",
        "....ssssssss....",
    ),
    "time": (
        ".......cc.......",
        "......cccc......",
        ".....cccccc.....",
        "....ccccccccc...",
        "..cccccccccccc..",
        "..cccccccccccc..",
        "...cccccccccc...",
        "....ssssssss....",
    ),
}

_HERO_BODY = (
    "...cccccccccc...",
    "..sccccccccccs..",
    "..sccccccccccs..",
    "...cccccccccc...",
)

_HERO_LEGS = (
    (
        "...cccc..cccc...",
        "...bbb....bbb...",
        "..bbbb....bbbb..",
        "................",
    ),
    (
        "...cccc..cccc...",
        "....bbb..bbb....",
        "....bbb..bbb....",
        "................",
    ),
)

GOBLIN = (  # 怒った眉・光る目・きば・つめ で狂暴さを出す
    "................",
    "..g..........g..",
    ".gg.gggggggg.gg.",
    "...gnnnggnnng...",
    "...gkkggggkkg...",
    "...gggggggggg...",
    "....gnnnnnng....",
    ".....t.gg.t.....",
    "..gggggggggggg..",
    "nggggggggggggggn",
    "n.gggggggggggg.n",
    "...ggddddddgg...",
    "...ggddddddgg...",
    "....ggg..ggg....",
    "....ggg..ggg....",
    "...nnnn..nnnn...",
)

WOLF = (  # 逆立った背中の毛・光る目・きば・するどいツメ
    "................",
    "................",
    "...a............",
    "..aaa...........",
    ".aakaa.a.a.a....",
    ".aaaaaaaaaaaaaa.",
    ".aaaaaaaaaaaaaaa",
    ".aaaaaaaaaaaaass",
    ".wwwwwwwwwwwww..",
    "..wwwwwwwwwww...",
    "...aaaaaaaaa....",
    "...aa....aa.....",
    "...aa....aa.....",
    "...aa....aa.....",
    "..kaak..kaak....",
    "................",
)

MAGE = (  # 深いフードで顔を隠し、つえを持つ黒魔道士風の敵
    ".......mm.......",
    "......mmmm......",
    ".o...mmmmmm.....",
    ".o..mmmmmmmm....",
    ".O.mmmmmmmmmm...",
    ".o.mmmmmmmmmmmm.",
    ".o...kkkkkk.....",
    ".o..kkykkykk....",
    ".o...kkkkkk.....",
    ".o..rrrrrrrr....",
    ".o.rrrrrrrrrr...",
    ".o.rrrrrrrrrr.r.",
    "...r.rrrrrrrr.r.",
    "....rrrrrrrr....",
    "....rr....rr....",
    "................",
)

GOLEM = (  # ヒビの入った岩の巨体、光る核と目
    "................",
    ".....ssssss.....",
    ".....ssnsss.....",
    ".....skssks.....",
    ".....ssssss.....",
    "...ssssssssss...",
    ".ss.ssssssss.ss.",
    ".ss.snssssns.ss.",
    ".ss.snnkksss.ss.",
    ".ss.ssskkssn.ss.",
    "sss.ssssssss.sss",
    "sss.ssssssss.sss",
    "....nnnnssss....",
    "....ssssssss....",
    "....snsssnss....",
    "....ssssssss....",
)

MUTANT = (  # 3つ目・光る腫瘍で異形さを出す変異体
    "................",
    "......gggg......",
    ".....ggeggg.....",
    ".....gggggg.....",
    ".....gkggkg.....",
    "....gggggggg....",
    "..ggggggggggggg.",
    "..ggggeggvggggg.",
    "..ggggggggggggg.",
    ".nngggggggggggg.",
    "....ggggggggggg.",
    ".....ggg.gggnnn.",
    ".....ggg.ggg.n..",
    ".....ggg.nng....",
    ".....ggg........",
    ".....nng........",
)

ROBOT = (  # アンテナ・バイザー・光る核を持つ量産機
    "........a.......",
    "....mmmmmmmm....",
    "...mmmmmmmmmm...",
    "...cckcccckcc...",
    "...mmmmmmmmmm...",
    "....mmmmmmmm....",
    "..acccccccccca..",
    "mmcmccccccccmcmm",
    "mmccccckkcccccmm",
    "mmccccckkcccccmm",
    "mmmmmmmmmmmmmmmm",
    "...mmmm..mmmm...",
    "...aaaa..aaaa...",
    "...mmmm..mmmm...",
    "...mmmm..mmmm...",
    "................",
)

GUARDIAN_BOSS = (  # 肩の大砲・単眼バイザー・重装甲脚をもつ守護者
    "....a......a....",
    "...mmmmmmmmmm...",
    "..mmmmmmmmmmmm..",
    "...ccckkkkccc...",
    "...ccckkkkccc...",
    "..mmmmmmmmmmmm..",
    "aaaccccccccccaaa",
    "akaccccccccccaka",
    "aaaccckkkkcccaaa",
    "aaaccckkkkcccaaa",
    "...cccccccccc...",
    "..mmmmmmmmmmmm..",
    "...mmmm..mmmm...",
    "...aaaa..aaaa...",
    "...mmmm..mmmm...",
    "...mmmm..mmmm...",
)

BANDIT = (  # フードで顔を隠し、ナイフをかまえるならずもの
    "................",
    ".....cccccc.....",
    "....cccccccc....",
    "....cckcckcc....",
    "....cccccccc..d.",
    ".....nnnnnn..d..",
    "...ccccccccccnn.",
    ".ccccccccccccnn.",
    ".ccccccccccccnn.",
    ".ccccccccccccnn.",
    "..cnnnnnnnnnnc..",
    "....cccccccc....",
    "....cccccccc....",
    "....cccccccc....",
    "....nnnnnnnn....",
    "....cccccccc....",
)

BOSS = (
    ".hh...........hh",
    ".hhh.........hhh",
    "..hhh.ddddd.hhh.",
    "...hdddddddddh..",
    "...ddddddddddd..",
    "..ddkkdddddkkdd.",
    "..ddddddddddddd.",
    "...ddddddddddd..",
    "..dddsdddddsddd.",
    ".dddddsdddsddddd",
    ".ddd.ddddddd.ddd",
    ".dd..ddddddd..dd",
    ".....ddddddd....",
    "....ddddddddd...",
    "...ddddddddddd..",
    "..ddddddddddddd.",
)

ENEMY_PALETTES = {
    "goblin": {"g": (96, 168, 72), "k": (232, 64, 48), "d": (152, 112, 64),
              "n": (40, 30, 20), "t": (245, 245, 245)},
    "wolf": {"a": (152, 152, 168), "k": (240, 208, 64),
             "w": (224, 224, 232), "s": (255, 255, 255)},
    "mage": {"m": (56, 48, 112), "k": (16, 12, 24), "y": (248, 216, 72),
             "r": (88, 72, 152), "o": (110, 84, 56), "O": (255, 220, 80)},
    "golem": {"s": (148, 132, 116), "k": (255, 150, 64), "n": (96, 84, 72)},
    "boss": {"d": (60, 40, 88), "h": (216, 208, 224), "k": (255, 64, 48),
             "s": (168, 64, 200)},
    "mutant": {"g": (150, 84, 172), "k": (248, 216, 72),
               "e": (140, 255, 120), "v": (90, 220, 90),
               "n": (40, 20, 50)},
    "robot": {"m": (150, 158, 176), "k": (255, 72, 56),
              "a": (96, 104, 124), "c": (92, 112, 148)},
    "guardian": {"m": (112, 100, 136), "k": (255, 88, 208),
                 "a": (72, 62, 92), "c": (58, 48, 92)},
    "bandit": {"c": (86, 72, 64), "k": (255, 220, 90),
               "n": (40, 32, 28), "d": (220, 224, 232)},
}

ENEMY_PATTERNS = {
    "goblin": GOBLIN, "wolf": WOLF, "mage": MAGE,
    "golem": GOLEM, "boss": BOSS,
    "mutant": MUTANT, "robot": ROBOT, "guardian": GUARDIAN_BOSS,
    "bandit": BANDIT,
}

_SKIN = (248, 208, 168)
_BOOT = (96, 72, 56)
_EYE = (32, 32, 48)
_EYE_GLOW = (255, 240, 140)  # 黒魔道士系のフードで光る目 (固定色)

_cache: dict[tuple, pygame.Surface] = {}


def build(pattern: tuple[str, ...], palette: dict[str, tuple[int, int, int]],
          scale: int, outline: bool = False) -> pygame.Surface:
    surf = pygame.Surface((16 * scale, 16 * scale), pygame.SRCALPHA)

    def filled(x: int, y: int) -> bool:
        if not (0 <= y < len(pattern) and 0 <= x < len(pattern[y])):
            return False
        ch = pattern[y][x]
        return ch != "." and ch in palette

    for y, row in enumerate(pattern):
        for x, ch in enumerate(row):
            if ch != "." and ch in palette:
                surf.fill(palette[ch], (x * scale, y * scale, scale, scale))
            elif outline and any(
                    filled(x + dx, y + dy)
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                surf.fill(OUTLINE, (x * scale, y * scale, scale, scale))
    return surf


def tile(kind: str, scale: int, frame: int = 0) -> pygame.Surface:
    frames = TILE_PATTERNS[kind]
    frame %= len(frames)
    key = ("tile", kind, scale, frame)
    if key not in _cache:
        _cache[key] = build(frames[frame], TILE_PALETTE, scale)
    return _cache[key]


def decor(kind: str, scale: int) -> pygame.Surface:
    key = ("decor", kind, scale)
    if key not in _cache:
        _cache[key] = build(DECOR_PATTERNS[kind], DECOR_PALETTE, scale)
    return _cache[key]


def hero(cloth: tuple[int, int, int], hair: tuple[int, int, int],
         scale: int, facing: str = "down", frame: int = 0,
         job_id: str = "suppin") -> pygame.Surface:
    key = ("hero", cloth, hair, scale, facing, frame % 2, job_id)
    if key not in _cache:
        if facing == "up":
            head = _JOB_HEAD_BACK.get(job_id, _HERO_HEAD_BACK)
        else:
            head = _JOB_HEAD_FRONT.get(job_id, _HERO_HEAD_FRONT)
        pattern = tuple(head) + _HERO_BODY + _HERO_LEGS[frame % 2]
        palette = {"h": hair, "s": _SKIN, "k": _EYE, "c": cloth, "b": _BOOT,
                  "e": _EYE_GLOW}
        _cache[key] = build(pattern, palette, scale, outline=True)
    return _cache[key]


def enemy(kind: str, scale: int) -> pygame.Surface:
    key = ("enemy", kind, scale)
    if key not in _cache:
        _cache[key] = build(ENEMY_PATTERNS[kind], ENEMY_PALETTES[kind],
                            scale, outline=True)
    return _cache[key]


def chara(ch: object, scale: int, facing: str = "down",
          frame: int = 0) -> pygame.Surface:
    """キャラクターの見た目 (勇者ドット、ジョブカラーで服を染め、頭部の形も

    ジョブごとに変える。ヘルメット/頭巾/とんがり帽子など見た目で判別できる)。
    """
    return hero(ch.job.color, ch.hair, scale, facing, frame,
               job_id=ch.job_id)
