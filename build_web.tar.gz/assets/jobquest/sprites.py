"""Programmatic 16x16 pixel art (SNES風ドット絵).

pattern は 16行x16文字。'.' は透明、他の文字はパレットで色に変換。
キャラクター/敵にはアウトライン (暗色縁取り) を自動で付ける。
勇者とロボは 前/後ろ × 歩行2フレーム を部品合成で生成する。
"""

from __future__ import annotations

import pygame

OUTLINE = (24, 20, 40)

# ---------------------------------------------------------------------------
# タイル
# ---------------------------------------------------------------------------

GRASS = (
    "GGGGGGGGGGGGGGGG",
    "GGGgGGGGGGGGGGGG",
    "GGGGGGGGGGgGGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGgGGGGGGGGG",
    "GgGGGGGGGGGGGGgG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGGGgGGGGGG",
    "GGGGgGGGGGGGGGGG",
    "GGGGGGGGGGGGGgGG",
    "GgGGGGGGGGGGGGGG",
    "GGGGGGGgGGGGGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGgGGGGGGGGgGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGgGGGGGGGGG",
)

TREE = (
    "GGGGGLLLLLGGGGGG",
    "GGGLLLLLLLLLGGGG",
    "GGLLlLLLLLLLLGGG",
    "GLLLLLLLLlLLLLGG",
    "GLLlLLLLLLLLLLGG",
    "GLLLLLLLLLLLlLGG",
    "GLLLLLlLLLLLLLGG",
    "GGLLLLLLLLlLLGGG",
    "GGGLLLLLLLLLGGGG",
    "GGGGLLLLLLLGGGGG",
    "GGGGGGtttGGGGGGG",
    "GGGGGGtttGGGGGGG",
    "GGGGGGtttGGGGGGG",
    "GGGGGtttttGGGGGG",
    "GGgGGGGGGGGGgGGG",
    "GGGGGGGGGGGGGGGG",
)

WATER = (
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWwwwWWWWWWWWWWW",
    "WWWWWWWWWWwwwWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWwwWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWwwWW",
    "WWwwWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWwwwWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWwwWWWWWWWwwWWW",
    "WWWWWWWWWWWWWWWW",
)

WATER2 = (
    "WWWWWWWWWWWWWWWW",
    "WWwwwWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWwwwWW",
    "WWWWWWwwWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWwwWWWWWWWWWWW",
    "WWWWWWWWWWWwwWWW",
    "WWWWWWWWWWWWWWWW",
    "WWwwWWWWWWWWWWWW",
    "WWWWWWWWwwwWWWWW",
    "WWWWWWWWWWWWWWWW",
    "WWWwwWWWWWWWwwWW",
    "WWWWWWWWWWWWWWWW",
    "WWWWWWWWWWWWWWWW",
)

PATH = (
    "PPPPPPPPPPPPPPPP",
    "PPPpPPPPPPPPPPPP",
    "PPPPPPPPPPpPPPPP",
    "PPPPPPPPPPPPPPPP",
    "PPPPPpPPPPPPPPpP",
    "PPPPPPPPPPPPPPPP",
    "PpPPPPPPPpPPPPPP",
    "PPPPPPPPPPPPPPPP",
    "PPPPPPpPPPPPPpPP",
    "PPPPPPPPPPPPPPPP",
    "PPpPPPPPPPPpPPPP",
    "PPPPPPPPPPPPPPPP",
    "PPPPPPPPpPPPPPPP",
    "PpPPPPPPPPPPPPpP",
    "PPPPPPPPPPPPPPPP",
    "PPPPpPPPPPPPPPPP",
)

CRYSTAL = (
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGxGGGGGGGG",
    "GGGGGGxXxGGGGGGG",
    "GGGGGxXXXxGGGGGG",
    "GGGGxXXsXXxGGGGG",
    "GGGxXXssXXXxGGGG",
    "GGGxXXXXXXXxGGGG",
    "GGGGxXXXXXxGGGGG",
    "GGGGGxXXXxGGGGGG",
    "GGGGGGxXxGGGGGGG",
    "GGGGGGGxGGGGGGGG",
    "GGGGGmmmmmGGGGGG",
    "GGGGmmmmmmmGGGGG",
    "GGGGmmmmmmmGGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGGGGGGGGGG",
)

CRYSTAL2 = (
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGxGGGGGGGG",
    "GGGGGGxXxGGGGGGG",
    "GGGGGxXXXxGGGGGG",
    "GGGGxXXXXXxGGGGG",
    "GGGxXXXXsXXxGGGG",
    "GGGxXXXssXXxGGGG",
    "GGGGxXXXXXxGGGGG",
    "GGGGGxXXXxGGGGGG",
    "GGGGGGxXxGGGGGGG",
    "GGGGGGGxGGGGGGGG",
    "GGGGGmmmmmGGGGGG",
    "GGGGmmmmmmmGGGGG",
    "GGGGmmmmmmmGGGGG",
    "GGGGGGGGGGGGGGGG",
    "GGGGGGGGGGGGGGGG",
)

FLOOR = (
    "FFFFFFFfFFFFFFFf",
    "FFFFFFFfFFFFFFFf",
    "FFFFFFFfFFFFFFFf",
    "ffffffffffffffff",
    "FFFfFFFFFFFfFFFF",
    "FFFfFFFFFFFfFFFF",
    "FFFfFFFFFFFfFFFF",
    "ffffffffffffffff",
    "FFFFFFFfFFFFFFFf",
    "FFFFFFFfFFFFFFFf",
    "FFFFFFFfFFFFFFFf",
    "ffffffffffffffff",
    "FFFfFFFFFFFfFFFF",
    "FFFfFFFFFFFfFFFF",
    "FFFfFFFFFFFfFFFF",
    "ffffffffffffffff",
)

WALL = (
    "RRRRRRRrRRRRRRRr",
    "RRRRRRRrRRRRRRRr",
    "RRRRRRRrRRRRRRRr",
    "rrrrrrrrrrrrrrrr",
    "RRRrRRRRRRRrRRRR",
    "RRRrRRRRRRRrRRRR",
    "RRRrRRRRRRRrRRRR",
    "rrrrrrrrrrrrrrrr",
    "RRRRRRRrRRRRRRRr",
    "RRRRRRRrRRRRRRRr",
    "RRRRRRRrRRRRRRRr",
    "rrrrrrrrrrrrrrrr",
    "RRRrRRRRRRRrRRRR",
    "RRRrRRRRRRRrRRRR",
    "RRRrRRRRRRRrRRRR",
    "rrrrrrrrrrrrrrrr",
)

# 未来 (荒廃) タイル: かれくさ / かれき
DEAD_GRASS = tuple(row.translate(str.maketrans("Gg", "Dd")) for row in GRASS)
DEAD_TREE = (
    "DDDDDDkDDDDDDDDD",
    "DDkDDDkDDDkDDDDD",
    "DDDkDDkDDkDDDDDD",
    "DDDDkDkkDkDDDDDD",
    "DDDDDkkkkkDDkDDD",
    "DDDDDDtkkDkkDDDD",
    "DDDDDDtktkDDDDDD",
    "DDDDDDttkDDDDDDD",
    "DDDDDDttDDDDDDDD",
    "DDDDDDttDDDDDDDD",
    "DDDDDDttDDDDDDDD",
    "DDDDDDttDDDDDDDD",
    "DDDDDttttDDDDDDD",
    "DDDDDDDDDDDDDDDD",
    "DDDDDDDDDDDDDDDD",
    "DDDDDDDDDDDDDDDD",
)

TILE_PALETTE = {
    "G": (104, 176, 88), "g": (84, 152, 72),
    "L": (48, 112, 56), "l": (80, 152, 80), "t": (92, 68, 48),
    "W": (64, 112, 216), "w": (136, 176, 248),
    "P": (200, 168, 112), "p": (176, 144, 92),
    "x": (72, 200, 224), "X": (144, 240, 248), "s": (255, 255, 255),
    "m": (128, 128, 140),
    "F": (152, 148, 160), "f": (116, 112, 128),
    "R": (92, 88, 108), "r": (56, 52, 72),
    "D": (146, 128, 84), "d": (122, 106, 68), "k": (150, 132, 108),
}

# タイル: kind -> フレーム列 (アニメーションは複数フレーム)
TILE_PATTERNS: dict[str, tuple[tuple[str, ...], ...]] = {
    "G": (GRASS,), "T": (TREE,), "W": (WATER, WATER2), "P": (PATH,),
    "C": (CRYSTAL, CRYSTAL2), "F": (FLOOR,), "R": (WALL,),
    "D": (DEAD_GRASS,), "S": (DEAD_TREE,),
}

# 装飾 (草原の花や荒野の岩): タイルの上に重ねる
DECOR_PATTERNS = {
    "flower_r": (
        "................", "................", "................",
        "................", "......a.........", ".....aRa........",
        "......a.........", "......g.........", "................",
        "................", "..........a.....", ".........aRa....",
        "..........a.....", "..........g.....", "................",
        "................",
    ),
    "flower_y": (
        "................", "................", "................",
        "................", "................", "....Y...........",
        "...YsY..........", "....Y...........", "....g...........",
        "................", "................", "...........Y....",
        "..........YsY...", "...........Y....", "...........g....",
        "................",
    ),
    "tuft": (
        "................", "................", "................",
        "................", "................", "................",
        "................", "....g..g........", "....g.g.g.......",
        ".....gg.........", "................", "................",
        ".........g..g...", ".........g.g....", "..........g.....",
        "................",
    ),
    "rock": (
        "................", "................", "................",
        "................", "................", "................",
        "......mm........", ".....mmmm.......", ".....mmmm.......",
        "....mmmmmm......", "................", "................",
        "................", "................", "................",
        "................",
    ),
    "chest": (
        "................", "................", "................",
        "...bbbbbbbbbb...", "..bBBBBBBBBBBb..", "..bBBBBBBBBBBb..",
        "..bbbbbbbbbbbb..", "..bBBBBqqBBBBb..", "..bBBBBqqBBBBb..",
        "..bBBBBBBBBBBb..", "..bBBBBBBBBBBb..", "..bbbbbbbbbbbb..",
        "................", "................", "................",
        "................",
    ),
    "chest_open": (
        "................", "................", "................",
        "...bbbbbbbbbb...", "..bkkkkkkkkkkb..", "..bkkkkkkkkkkb..",
        "..bbbbbbbbbbbb..", "..bBBBBBBBBBBb..", "..bBBBBqqBBBBb..",
        "..bBBBBBBBBBBb..", "..bBBBBBBBBBBb..", "..bbbbbbbbbbbb..",
        "................", "................", "................",
        "................",
    ),
    "stairs": (
        "................", "..kkkkkkkkkkkk..", "..kkkkkkkkkkkk..",
        "..kkmmmmmmmmkk..", "..kkkkkkkkkkkk..", "..kkmmmmmmkkkk..",
        "..kkkkkkkkkkkk..", "..kkmmmmkkkkkk..", "..kkkkkkkkkkkk..",
        "..kkmmkkkkkkkk..", "..kkkkkkkkkkkk..", "..kkkkkkkkkkkk..",
        "..kkkkkkkkkkkk..", "................", "................",
        "................",
    ),
}

DECOR_PALETTE = {
    "a": (240, 240, 248), "R": (232, 96, 112), "Y": (248, 216, 88),
    "s": (255, 255, 255), "g": (72, 136, 64), "m": (108, 96, 76),
    "b": (146, 96, 48), "B": (196, 144, 72), "q": (248, 216, 88),
    "k": (28, 26, 40),
}

# ---------------------------------------------------------------------------
# キャラクター: 部品合成で 前/後ろ × 歩行2フレーム
# ---------------------------------------------------------------------------

_HERO_HEAD_FRONT = (
    "....hhhhhhhh....",
    "...hhhhhhhhhh...",
    "..hhhhhhhhhhhh..",
    "..hhsssssssshh..",
    "..hssssssssssh..",
    "..hsskssskssh...",
    "...ssssssssss...",
    "....ssssssss....",
)

_HERO_HEAD_BACK = (
    "....hhhhhhhh....",
    "...hhhhhhhhhh...",
    "..hhhhhhhhhhhh..",
    "..hhhhhhhhhhhh..",
    "..hhhhhhhhhhhh..",
    "..hhhhhhhhhhhh..",
    "...hhhhhhhhhh...",
    "....ssssssss....",
)

_HERO_BODY = (
    "...cccccccccc...",
    "..sccccccccccs..",
    "..sccccccccccs..",
    "...cccccccccc...",
)

_HERO_LEGS = (
    (
        "...cccc..cccc...",
        "...bbb....bbb...",
        "..bbbb....bbbb..",
        "................",
    ),
    (
        "...cccc..cccc...",
        "....bbb..bbb....",
        "....bbb..bbb....",
        "................",
    ),
)

_ROBO_HEAD_FRONT = (
    "....mmmmmmmm....",
    "...mmmmmmmmmm...",
    "...mkkmmmmkkm...",
    "...mmmmmmmmmm...",
    "....mmmmmmmm....",
    ".....aa..aa.....",
)

_ROBO_HEAD_BACK = (
    "....mmmmmmmm....",
    "...mmmmmmmmmm...",
    "...mmmmmmmmmm...",
    "...mmmmmmmmmm...",
    "....mmmmmmmm....",
    ".....aa..aa.....",
)

_ROBO_BODY = (
    "...cccccccccc...",
    "..mccccccccccm..",
    "..mccccccccccm..",
    "..mmccccccccmm..",
    "...mmmmmmmmmm...",
)

_ROBO_LEGS = (
    (
        "...mmm....mmm...",
        "...mmm....mmm...",
        "..mmmm....mmmm..",
        "................",
        "................",
    ),
    (
        "....mmm..mmm....",
        "....mmm..mmm....",
        "...mmmm..mmmm...",
        "................",
        "................",
    ),
)

GOBLIN = (
    "................",
    ".....gggggg.....",
    "....gggggggg....",
    "...gggggggggg...",
    "...gkkggggkkg...",
    "...gggggggggg...",
    "....ggggggggg...",
    ".....gggggg.....",
    "...ggddddddgg...",
    "..gg.dddddd.gg..",
    ".....dddddd.....",
    "....gggggggg....",
    "....gg....gg....",
    "...ggg....ggg...",
    "................",
    "................",
)

WOLF = (
    "................",
    "................",
    "..aa............",
    "..aaa...........",
    "..akaa..........",
    "..aaaaaaaaaa.a..",
    "...aaaaaaaaaaa..",
    "..waaaaaaaaaa...",
    "..wwaaaaaaaaa...",
    "...aaaaaaaaaa...",
    "...aaa...aaa....",
    "...aa.....aa....",
    "...aa.....aa....",
    "..aaa....aaa....",
    "................",
    "................",
)

MAGE = (
    ".......mm.......",
    "......mmmm......",
    ".....mmmmmm.....",
    "....mmmmmmmm....",
    "...mmmmmmmmmm...",
    "..mmmmmmmmmmmm..",
    ".....kkkkkk.....",
    "....kkykkykk....",
    ".....kkkkkk.....",
    "....rrrrrrrr....",
    "...rrrrrrrrrr...",
    "..rrrrrrrrrrrr..",
    "..r.rrrrrrrr.r..",
    "....rrrrrrrr....",
    "....rr....rr....",
    "................",
)

GOLEM = (
    "................",
    "....ssssssss....",
    "...ssssssssss...",
    "...sskssssksss..",
    "...ssssssssss...",
    "....ssssssss....",
    "..ssssssssssss..",
    ".sss.ssssss.sss.",
    ".sss.ssssss.sss.",
    ".sss.ssssss.sss.",
    "..s..ssssss..s..",
    ".....ssssss.....",
    "....sss..sss....",
    "....sss..sss....",
    "...ssss..ssss...",
    "................",
)

BOSS = (
    ".hh...........hh",
    ".hhh.........hhh",
    "..hhh.ddddd.hhh.",
    "...hdddddddddh..",
    "...ddddddddddd..",
    "..ddkkdddddkkdd.",
    "..ddddddddddddd.",
    "...ddddddddddd..",
    "..dddsdddddsddd.",
    ".dddddsdddsddddd",
    ".ddd.ddddddd.ddd",
    ".dd..ddddddd..dd",
    ".....ddddddd....",
    "....ddddddddd...",
    "...ddddddddddd..",
    "..ddddddddddddd.",
)

ROBO_ENEMY = tuple(_ROBO_HEAD_FRONT + _ROBO_BODY + _ROBO_LEGS[0])

ENEMY_PALETTES = {
    "goblin": {"g": (96, 168, 72), "k": (232, 64, 48), "d": (152, 112, 64)},
    "wolf": {"a": (152, 152, 168), "k": (240, 208, 64),
             "w": (224, 224, 232)},
    "mage": {"m": (56, 48, 112), "k": (16, 12, 24), "y": (248, 216, 72),
             "r": (88, 72, 152)},
    "golem": {"s": (148, 132, 116), "k": (255, 96, 64)},
    "boss": {"d": (60, 40, 88), "h": (216, 208, 224), "k": (255, 64, 48),
             "s": (168, 64, 200)},
    "mutant": {"g": (150, 84, 172), "k": (248, 216, 72),
               "d": (84, 56, 96)},
    "robot": {"m": (150, 158, 176), "k": (255, 72, 56),
              "a": (96, 104, 124), "c": (92, 112, 148)},
    "guardian": {"m": (112, 100, 136), "k": (255, 88, 208),
                 "a": (72, 62, 92), "c": (58, 48, 92)},
}

ENEMY_PATTERNS = {
    "goblin": GOBLIN, "wolf": WOLF, "mage": MAGE,
    "golem": GOLEM, "boss": BOSS,
    "mutant": GOBLIN, "robot": ROBO_ENEMY, "guardian": ROBO_ENEMY,
}

_SKIN = (248, 208, 168)
_BOOT = (96, 72, 56)
_EYE = (32, 32, 48)

_cache: dict[tuple, pygame.Surface] = {}


def build(pattern: tuple[str, ...], palette: dict[str, tuple[int, int, int]],
          scale: int, outline: bool = False) -> pygame.Surface:
    surf = pygame.Surface((16 * scale, 16 * scale), pygame.SRCALPHA)

    def filled(x: int, y: int) -> bool:
        if not (0 <= y < len(pattern) and 0 <= x < len(pattern[y])):
            return False
        ch = pattern[y][x]
        return ch != "." and ch in palette

    for y, row in enumerate(pattern):
        for x, ch in enumerate(row):
            if ch != "." and ch in palette:
                surf.fill(palette[ch], (x * scale, y * scale, scale, scale))
            elif outline and any(
                    filled(x + dx, y + dy)
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                surf.fill(OUTLINE, (x * scale, y * scale, scale, scale))
    return surf


def tile(kind: str, scale: int, frame: int = 0) -> pygame.Surface:
    frames = TILE_PATTERNS[kind]
    frame %= len(frames)
    key = ("tile", kind, scale, frame)
    if key not in _cache:
        _cache[key] = build(frames[frame], TILE_PALETTE, scale)
    return _cache[key]


def decor(kind: str, scale: int) -> pygame.Surface:
    key = ("decor", kind, scale)
    if key not in _cache:
        _cache[key] = build(DECOR_PATTERNS[kind], DECOR_PALETTE, scale)
    return _cache[key]


def hero(cloth: tuple[int, int, int], hair: tuple[int, int, int],
         scale: int, facing: str = "down", frame: int = 0) -> pygame.Surface:
    key = ("hero", cloth, hair, scale, facing, frame % 2)
    if key not in _cache:
        head = _HERO_HEAD_BACK if facing == "up" else _HERO_HEAD_FRONT
        pattern = tuple(head + _HERO_BODY + _HERO_LEGS[frame % 2])
        palette = {"h": hair, "s": _SKIN, "k": _EYE, "c": cloth, "b": _BOOT}
        _cache[key] = build(pattern, palette, scale, outline=True)
    return _cache[key]


def _robo_sprite(cloth: tuple[int, int, int], scale: int,
                 facing: str, frame: int) -> pygame.Surface:
    key = ("robo", cloth, scale, facing, frame % 2)
    if key not in _cache:
        head = _ROBO_HEAD_BACK if facing == "up" else _ROBO_HEAD_FRONT
        pattern = tuple(head + _ROBO_BODY + _ROBO_LEGS[frame % 2])
        palette = {"m": (172, 182, 200), "k": (255, 210, 84),
                   "a": (110, 118, 140), "c": cloth}
        _cache[key] = build(pattern, palette, scale, outline=True)
    return _cache[key]


def enemy(kind: str, scale: int) -> pygame.Surface:
    key = ("enemy", kind, scale)
    if key not in _cache:
        _cache[key] = build(ENEMY_PATTERNS[kind], ENEMY_PALETTES[kind],
                            scale, outline=True)
    return _cache[key]


def chara(ch: object, scale: int, facing: str = "down",
          frame: int = 0) -> pygame.Surface:
    """キャラクターの見た目 (ロボは専用ドット、他は勇者ドット)."""
    if getattr(ch, "sprite", "hero") == "robo":
        return _robo_sprite(ch.job.color, scale, facing, frame)
    return hero(ch.job.color, ch.hair, scale, facing, frame)
