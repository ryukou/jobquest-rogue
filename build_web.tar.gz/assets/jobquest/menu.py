"""Menu scene: ステータス / ジョブチェンジ / アビリティ付替え."""

from __future__ import annotations

from typing import Callable

import pygame

from jobquest import config as C
from jobquest import sfx, sprites, ui
from jobquest.jobs import ABILITIES, JOB_ORDER, JOBS
from jobquest.models import ITEMS, Character, Inventory

# アビリティ一覧のスクロール窓 (行の高さはスマホの推奨タップ領域に合わせる)
ABILITY_ROW_H = 42
ABILITY_VISIBLE = 8


class MenuScene:
    def __init__(self, party: list[Character], inventory: Inventory,
                 on_close: Callable[[], None]) -> None:
        self.party = party
        self.inventory = inventory
        self.on_close = on_close
        # party / char / job / ability / equip_kind / equip_target
        self.mode = "party"
        self.p_index = 0
        self.c_index = 0
        self.j_index = 0
        self.a_index = 0
        self.e_kind_index = 0
        self.e_targets: list[Character] = []
        self.e_target_index = 0

    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        key = event.key
        confirm = key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE)
        cancel = key in (pygame.K_x, pygame.K_ESCAPE, pygame.K_m)
        if key in (pygame.K_UP, pygame.K_DOWN):
            sfx.play("cursor")
        elif confirm:
            sfx.play("confirm")
        elif cancel:
            sfx.play("cancel")

        if self.mode == "party":
            if key == pygame.K_UP:
                self.p_index = (self.p_index - 1) % len(self.party)
            elif key == pygame.K_DOWN:
                self.p_index = (self.p_index + 1) % len(self.party)
            elif confirm:
                self.mode = "char"
                self.c_index = 0
            elif cancel:
                self.on_close()
        elif self.mode == "char":
            options = self._char_options()
            if key == pygame.K_UP:
                self.c_index = (self.c_index - 1) % len(options)
            elif key == pygame.K_DOWN:
                self.c_index = (self.c_index + 1) % len(options)
            elif confirm:
                choice = options[self.c_index]
                if choice == "ジョブチェンジ":
                    self.mode = "job"
                    self.j_index = JOB_ORDER.index(self.char.job_id)
                elif choice == "アビリティ":
                    self.mode = "ability"
                    self.a_index = 0
                elif choice == "そうび":
                    self.mode = "equip_kind"
                    self.e_kind_index = 0
            elif cancel:
                self.mode = "party"
        elif self.mode == "equip_kind":
            kinds = self._equip_kinds()
            if key == pygame.K_UP:
                self.e_kind_index = (self.e_kind_index - 1) % len(kinds)
            elif key == pygame.K_DOWN:
                self.e_kind_index = (self.e_kind_index + 1) % len(kinds)
            elif confirm:
                self.e_targets = [c for c in self.party if c is not self.char]
                self.e_target_index = 0
                self.mode = "equip_target"
            elif cancel:
                self.mode = "char"
        elif self.mode == "equip_target":
            if key == pygame.K_UP:
                self.e_target_index = (self.e_target_index - 1) \
                    % len(self.e_targets)
            elif key == pygame.K_DOWN:
                self.e_target_index = (self.e_target_index + 1) \
                    % len(self.e_targets)
            elif confirm:
                self._swap_equipment(self.e_targets[self.e_target_index])
                self.mode = "char"
            elif cancel:
                self.mode = "equip_kind"
        elif self.mode == "job":
            if key == pygame.K_UP:
                self.j_index = (self.j_index - 1) % len(JOB_ORDER)
            elif key == pygame.K_DOWN:
                self.j_index = (self.j_index + 1) % len(JOB_ORDER)
            elif confirm:
                self.char.change_job(JOB_ORDER[self.j_index])
                self.mode = "char"
            elif cancel:
                self.mode = "char"
        elif self.mode == "ability":
            options = self._ability_options()
            if key == pygame.K_UP:
                self.a_index = (self.a_index - 1) % len(options)
            elif key == pygame.K_DOWN:
                self.a_index = (self.a_index + 1) % len(options)
            elif confirm:
                self.char.equipped = options[self.a_index][0]
                ch = self.char
                ch.hp = min(ch.hp, ch.max_hp)
                ch.mp = min(ch.mp, ch.max_mp)
                self.mode = "char"
            elif cancel:
                self.mode = "char"

    @property
    def char(self) -> Character:
        return self.party[self.p_index]

    def _char_options(self) -> list[str]:
        opts = ["ジョブチェンジ", "アビリティ"]
        if len(self.party) > 1:  # 交換できる相手がいるときだけ出す
            opts.append("そうび")
        return opts

    @staticmethod
    def _equip_kinds() -> list[tuple[str, str]]:
        return [("weapon", "ぶき"), ("trinket", "おまもり")]

    def _equip_label(self, ch: Character, kind: str) -> str:
        if kind == "weapon":
            return ch.weapon.name if ch.weapon else "ぶきなし"
        return ABILITIES[ch.trinket].name if ch.trinket else "おまもりなし"

    def _swap_equipment(self, other: Character) -> None:
        kind, _ = self._equip_kinds()[self.e_kind_index]
        ch = self.char
        if kind == "weapon":
            ch.weapon, other.weapon = other.weapon, ch.weapon
        else:
            ch.trinket, other.trinket = other.trinket, ch.trinket
        for c in (ch, other):
            c.hp = min(c.hp, c.max_hp)
            c.mp = min(c.mp, c.max_mp)

    def _ability_options(self) -> list[tuple[str | None, str]]:
        opts: list[tuple[str | None, str]] = [(None, "――はずす――")]
        for ab in self.char.all_learned():
            opts.append((ab.id, ab.name))
        return opts

    def _tap_rows(self, pos: tuple[float, float], attr: str,
                 rects: list[pygame.Rect], cancel_on_miss: bool) -> None:
        hit = ui.tap_in_rects(pos, rects, getattr(self, attr),
                              lambda v: setattr(self, attr, v))
        if not hit and cancel_on_miss:
            ui.post_key(pygame.K_x)

    def handle_tap(self, pos: tuple[float, float]) -> None:
        if self.mode == "party":
            spacing = 130 if len(self.party) <= 4 else 110
            rects = [pygame.Rect(28, 44 + i * spacing, 384, spacing - 14)
                     for i in range(len(self.party))]
            # トップ階層は誤爆防止のため枠外タップでは閉じない
            # (「もどる」ボタン / Xキーで閉じる)
            self._tap_rows(pos, "p_index", rects, cancel_on_miss=False)
        elif self.mode == "char":
            options = self._char_options()
            box = self._char_menu_rect(options)
            rects = [pygame.Rect(box.x + 8, box.y + 8 + i * 48,
                                 box.width - 16, 44)
                    for i in range(len(options))]
            self._tap_rows(pos, "c_index", rects, cancel_on_miss=True)
        elif self.mode == "equip_kind":
            kinds = self._equip_kinds()
            box = self._char_menu_rect(kinds)
            rects = [pygame.Rect(box.x + 8, box.y + 8 + i * 48,
                                 box.width - 16, 44) for i in range(len(kinds))]
            self._tap_rows(pos, "e_kind_index", rects, cancel_on_miss=True)
        elif self.mode == "equip_target":
            rects = [pygame.Rect(464, 222 + i * 56, 452, 50)
                     for i in range(len(self.e_targets))]
            self._tap_rows(pos, "e_target_index", rects, cancel_on_miss=True)
        elif self.mode == "job":
            rects = [pygame.Rect(448, 168 + i * 56, 484, 52)
                     for i in range(len(JOB_ORDER))]
            self._tap_rows(pos, "j_index", rects, cancel_on_miss=True)
        elif self.mode == "ability":
            options = self._ability_options()
            top = ui.visible_window(self.a_index, len(options),
                                    ABILITY_VISIBLE)
            n = min(ABILITY_VISIBLE, len(options) - top)
            rects = [pygame.Rect(448, 170 + i * ABILITY_ROW_H, 484,
                                 ABILITY_ROW_H - 2) for i in range(n)]
            hit = ui.tap_in_rects(
                pos, rects, self.a_index - top,
                lambda v: setattr(self, "a_index", top + v))
            if not hit:
                ui.post_key(pygame.K_x)

    def update(self, dt: float) -> None:
        pass

    # ------------------------------------------------------------------

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((24, 24, 48))
        self._draw_party(dst)
        self._draw_top(dst)
        if self.mode == "char":
            self._draw_char_menu(dst)
        elif self.mode == "job":
            self._draw_jobs(dst)
        elif self.mode == "ability":
            self._draw_abilities(dst)
        elif self.mode == "equip_kind":
            self._draw_equip_kind(dst)
        elif self.mode == "equip_target":
            self._draw_equip_target(dst)
        else:
            self._draw_detail(dst)

    def _draw_top(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(440, 20, 500, 80)
        ui.draw_window(dst, rect)
        ui.text(dst, f"しょじきん  {self.inventory.gil}ギル",
                (rect.x + 20, rect.y + 8), 20)
        items = "  ".join(f"{ITEMS[iid][0]}×{n}"
                          for iid, n in self.inventory.listing()) or "なし"
        ui.text(dst, items, (rect.x + 20, rect.y + 40), 18, C.COLOR_TEXT_DIM)

    def _draw_party(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(20, 20, 400, 600)
        ui.draw_window(dst, rect)
        spacing = 130 if len(self.party) <= 4 else 110
        for i, ch in enumerate(self.party):
            y = rect.y + 30 + i * spacing
            if i == self.p_index:
                ui.cursor(dst, (rect.x + 14, y + 20))
            img = sprites.chara(ch, 4)
            dst.blit(img, (rect.x + 40, y))
            x = rect.x + 130
            ui.text(dst, ch.name, (x, y), 24)
            ui.text(dst, f"Lv{ch.level}  {ch.job.name} "
                    f"JLv{ch.job_level(ch.job_id)}", (x, y + 30), 18,
                    C.COLOR_TEXT_YELLOW)
            ui.text(dst, f"HP {ch.hp}/{ch.max_hp}", (x, y + 56), 18)
            ui.text(dst, f"MP {ch.mp}/{ch.max_mp}", (x + 130, y + 56), 18,
                    C.COLOR_MPNUM)
            equip = ABILITIES[ch.equipped].name if ch.equipped else "――"
            ui.text(dst, f"アビリティ: {equip}", (x, y + 82), 16,
                    C.COLOR_TEXT_DIM)

    def _draw_detail(self, dst: pygame.Surface) -> None:
        from jobquest.battle_scene import BattleScene

        ch = self.char
        rect = pygame.Rect(440, 120, 500, 500)
        ui.draw_window(dst, rect)
        x, y = rect.x + 24, rect.y + 16
        ui.text(dst, f"{ch.name} のステータス", (x, y), 22,
                C.COLOR_TEXT_YELLOW)
        rows = [
            f"レベル {ch.level}   つぎまで {ch.level * ch.level * 10 - ch.exp}",
            f"こうげき {ch.atk}   まりょく {ch.mag}",
            f"すばやさ {ch.spd}   たいりょく {ch.vit}",
            "",
            "つかえるコマンド:",
        ]
        for i, row in enumerate(rows):
            ui.text(dst, row, (x, y + 40 + i * 30), 20)
        attack = [] if BattleScene._has_basic_attack(ch) else ["たたかう"]
        cmds = attack + [ab.name for ab in ch.battle_commands()] \
            + ["アイテム", "ぼうぎょ"]
        ui.text(dst, " / ".join(cmds), (x, y + 40 + len(rows) * 30), 18,
                C.COLOR_TEXT_DIM)
        ui.text(dst, "Z:せんたく  X:とじる", (x, rect.bottom - 46), 16,
                C.COLOR_TEXT_DIM)

    @staticmethod
    def _char_menu_rect(options: list) -> pygame.Rect:
        return pygame.Rect(460, 400, 280, 16 + 48 * len(options))

    def _draw_char_menu(self, dst: pygame.Surface) -> None:
        self._draw_detail(dst)
        options = self._char_options()
        rect = self._char_menu_rect(options)
        ui.draw_window(dst, rect)
        for i, label in enumerate(options):
            y = rect.y + 8 + i * 48
            if i == self.c_index:
                ui.cursor(dst, (rect.x + 14, y + 12))
            ui.text(dst, label, (rect.x + 40, y + 12), 22)

    def _draw_equip_kind(self, dst: pygame.Surface) -> None:
        self._draw_detail(dst)
        kinds = self._equip_kinds()
        rect = self._char_menu_rect(kinds)
        ui.draw_window(dst, rect)
        for i, (kind, label) in enumerate(kinds):
            y = rect.y + 8 + i * 48
            if i == self.e_kind_index:
                ui.cursor(dst, (rect.x + 14, y + 12))
            current = self._equip_label(self.char, kind)
            ui.text(dst, f"{label}: {current}", (rect.x + 40, y + 12), 20)

    def _draw_equip_target(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(440, 120, 500, 500)
        ui.draw_window(dst, rect)
        kind, label = self._equip_kinds()[self.e_kind_index]
        ui.text(dst, f"だれと {label}を いれかえる？",
                (rect.x + 24, rect.y + 14), 20, C.COLOR_TEXT_YELLOW)
        ui.text(dst, f"{self.char.name}: {self._equip_label(self.char, kind)}",
                (rect.x + 24, rect.y + 44), 16, C.COLOR_TEXT_DIM)
        for i, c in enumerate(self.e_targets):
            y = rect.y + 108 + i * 56
            if i == self.e_target_index:
                ui.cursor(dst, (rect.x + 14, y + 6))
            ui.text(dst, c.name, (rect.x + 40, y), 22,
                    ui.readable_color(c.job.color))
            ui.text(dst, self._equip_label(c, kind), (rect.x + 250, y + 4),
                    18, C.COLOR_TEXT_DIM)
        ui.text(dst, "Z:いれかえる  X:もどる", (rect.x + 24, rect.bottom - 40),
                16, C.COLOR_TEXT_DIM)

    def _draw_jobs(self, dst: pygame.Surface) -> None:
        ch = self.char
        rect = pygame.Rect(440, 120, 500, 500)
        ui.draw_window(dst, rect)
        ui.text(dst, f"{ch.name} のジョブ", (rect.x + 24, rect.y + 14), 22,
                C.COLOR_TEXT_YELLOW)
        for i, jid in enumerate(JOB_ORDER):
            job = JOBS[jid]
            y = rect.y + 52 + i * 56
            if i == self.j_index:
                ui.cursor(dst, (rect.x + 14, y + 6))
            mark = "▶" if jid == ch.job_id else " "
            ui.text(dst, f"{mark} {job.name}", (rect.x + 40, y), 22)
            lv = ch.job_level(jid)
            pts = ch.job_abp(jid)
            nxt = next((cost for cost, _ in job.learnset if pts < cost), None)
            info = f"JLv{lv}  ABP {pts}" + (f"/{nxt}" if nxt else "  マスター")
            if not job.learnset:
                info = "―"
            ui.text(dst, info, (rect.x + 250, y + 4), 16, C.COLOR_TEXT_DIM)
            pygame.draw.rect(dst, job.color,
                             (rect.x + 44, y + 30, 180, 4))

    def _draw_abilities(self, dst: pygame.Surface) -> None:
        ch = self.char
        rect = pygame.Rect(440, 120, 500, 500)
        ui.draw_window(dst, rect)
        ui.text(dst, f"{ch.name} のアビリティ", (rect.x + 24, rect.y + 14),
                22, C.COLOR_TEXT_YELLOW)
        options = self._ability_options()
        top = ui.visible_window(self.a_index, len(options), ABILITY_VISIBLE)
        for row, (aid, label) in enumerate(
                options[top:top + ABILITY_VISIBLE]):
            y = rect.y + 52 + row * ABILITY_ROW_H
            if top + row == self.a_index:
                ui.cursor(dst, (rect.x + 14, y + 8))
            mark = "Ｅ" if aid is not None and aid == ch.equipped else "　"
            ui.text(dst, f"{mark}{label}", (rect.x + 40, y + 6), 20)
        if 0 <= self.a_index < len(options):
            aid = options[self.a_index][0]
            desc = ABILITIES[aid].desc if aid else "アビリティを はずす"
            ui.text(dst, desc, (rect.x + 24, rect.bottom - 46), 16,
                    C.COLOR_TEXT_DIM)
