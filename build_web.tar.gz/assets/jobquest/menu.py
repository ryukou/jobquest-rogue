"""Menu scene: ステータス / ジョブチェンジ / アビリティ付替え."""

from __future__ import annotations

from typing import Callable

import pygame

from jobquest import config as C
from jobquest import sfx, sprites, ui
from jobquest.jobs import ABILITIES, JOB_ORDER, JOBS
from jobquest.models import ITEMS, Character, Inventory


class MenuScene:
    def __init__(self, party: list[Character], inventory: Inventory,
                 on_close: Callable[[], None]) -> None:
        self.party = party
        self.inventory = inventory
        self.on_close = on_close
        self.mode = "party"        # party / char / job / ability
        self.p_index = 0
        self.c_index = 0
        self.j_index = 0
        self.a_index = 0

    # ------------------------------------------------------------------

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        key = event.key
        confirm = key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE)
        cancel = key in (pygame.K_x, pygame.K_ESCAPE, pygame.K_m)
        if key in (pygame.K_UP, pygame.K_DOWN):
            sfx.play("cursor")
        elif confirm:
            sfx.play("confirm")
        elif cancel:
            sfx.play("cancel")

        if self.mode == "party":
            if key == pygame.K_UP:
                self.p_index = (self.p_index - 1) % len(self.party)
            elif key == pygame.K_DOWN:
                self.p_index = (self.p_index + 1) % len(self.party)
            elif confirm:
                self.mode = "char"
                self.c_index = 0
            elif cancel:
                self.on_close()
        elif self.mode == "char":
            if key == pygame.K_UP:
                self.c_index = (self.c_index - 1) % 2
            elif key == pygame.K_DOWN:
                self.c_index = (self.c_index + 1) % 2
            elif confirm:
                if self.c_index == 0:
                    self.mode = "job"
                    self.j_index = JOB_ORDER.index(self.char.job_id)
                else:
                    self.mode = "ability"
                    self.a_index = 0
            elif cancel:
                self.mode = "party"
        elif self.mode == "job":
            if key == pygame.K_UP:
                self.j_index = (self.j_index - 1) % len(JOB_ORDER)
            elif key == pygame.K_DOWN:
                self.j_index = (self.j_index + 1) % len(JOB_ORDER)
            elif confirm:
                self.char.change_job(JOB_ORDER[self.j_index])
                self.mode = "char"
            elif cancel:
                self.mode = "char"
        elif self.mode == "ability":
            options = self._ability_options()
            if key == pygame.K_UP:
                self.a_index = (self.a_index - 1) % len(options)
            elif key == pygame.K_DOWN:
                self.a_index = (self.a_index + 1) % len(options)
            elif confirm:
                self.char.equipped = options[self.a_index][0]
                ch = self.char
                ch.hp = min(ch.hp, ch.max_hp)
                ch.mp = min(ch.mp, ch.max_mp)
                self.mode = "char"
            elif cancel:
                self.mode = "char"

    @property
    def char(self) -> Character:
        return self.party[self.p_index]

    def _ability_options(self) -> list[tuple[str | None, str]]:
        opts: list[tuple[str | None, str]] = [(None, "――はずす――")]
        for ab in self.char.all_learned():
            opts.append((ab.id, ab.name))
        return opts

    def update(self, dt: float) -> None:
        pass

    # ------------------------------------------------------------------

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((24, 24, 48))
        self._draw_party(dst)
        self._draw_top(dst)
        if self.mode == "char":
            self._draw_char_menu(dst)
        elif self.mode == "job":
            self._draw_jobs(dst)
        elif self.mode == "ability":
            self._draw_abilities(dst)
        else:
            self._draw_detail(dst)

    def _draw_top(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(440, 20, 500, 80)
        ui.draw_window(dst, rect)
        ui.text(dst, f"しょじきん  {self.inventory.gil}ギル",
                (rect.x + 20, rect.y + 8), 20)
        items = "  ".join(f"{ITEMS[iid][0]}×{n}"
                          for iid, n in self.inventory.listing()) or "なし"
        ui.text(dst, items, (rect.x + 20, rect.y + 40), 18, C.COLOR_TEXT_DIM)

    def _draw_party(self, dst: pygame.Surface) -> None:
        rect = pygame.Rect(20, 20, 400, 600)
        ui.draw_window(dst, rect)
        spacing = 130 if len(self.party) <= 4 else 110
        for i, ch in enumerate(self.party):
            y = rect.y + 30 + i * spacing
            if i == self.p_index:
                ui.cursor(dst, (rect.x + 14, y + 20))
            img = sprites.chara(ch, 4)
            dst.blit(img, (rect.x + 40, y))
            x = rect.x + 130
            ui.text(dst, ch.name, (x, y), 24)
            ui.text(dst, f"Lv{ch.level}  {ch.job.name} "
                    f"JLv{ch.job_level(ch.job_id)}", (x, y + 30), 18,
                    C.COLOR_TEXT_YELLOW)
            ui.text(dst, f"HP {ch.hp}/{ch.max_hp}", (x, y + 56), 18)
            ui.text(dst, f"MP {ch.mp}/{ch.max_mp}", (x + 130, y + 56), 18,
                    C.COLOR_MPNUM)
            equip = ABILITIES[ch.equipped].name if ch.equipped else "――"
            ui.text(dst, f"アビリティ: {equip}", (x, y + 82), 16,
                    C.COLOR_TEXT_DIM)

    def _draw_detail(self, dst: pygame.Surface) -> None:
        ch = self.char
        rect = pygame.Rect(440, 120, 500, 500)
        ui.draw_window(dst, rect)
        x, y = rect.x + 24, rect.y + 16
        ui.text(dst, f"{ch.name} のステータス", (x, y), 22,
                C.COLOR_TEXT_YELLOW)
        rows = [
            f"レベル {ch.level}   つぎまで {ch.level * ch.level * 10 - ch.exp}",
            f"こうげき {ch.atk}   まりょく {ch.mag}",
            f"すばやさ {ch.spd}   たいりょく {ch.vit}",
            "",
            "つかえるコマンド:",
        ]
        for i, row in enumerate(rows):
            ui.text(dst, row, (x, y + 40 + i * 30), 20)
        cmds = ["たたかう"] + [ab.name for ab in ch.battle_commands()] \
            + ["アイテム", "ぼうぎょ"]
        ui.text(dst, " / ".join(cmds), (x, y + 40 + len(rows) * 30), 18,
                C.COLOR_TEXT_DIM)
        ui.text(dst, "Z:せんたく  X:とじる", (x, rect.bottom - 46), 16,
                C.COLOR_TEXT_DIM)

    def _draw_char_menu(self, dst: pygame.Surface) -> None:
        self._draw_detail(dst)
        rect = pygame.Rect(460, 400, 280, 110)
        ui.draw_window(dst, rect)
        for i, label in enumerate(("ジョブチェンジ", "アビリティ")):
            y = rect.y + 16 + i * 36
            if i == self.c_index:
                ui.cursor(dst, (rect.x + 14, y + 2))
            ui.text(dst, label, (rect.x + 40, y), 22)

    def _draw_jobs(self, dst: pygame.Surface) -> None:
        ch = self.char
        rect = pygame.Rect(440, 120, 500, 500)
        ui.draw_window(dst, rect)
        ui.text(dst, f"{ch.name} のジョブ", (rect.x + 24, rect.y + 14), 22,
                C.COLOR_TEXT_YELLOW)
        for i, jid in enumerate(JOB_ORDER):
            job = JOBS[jid]
            y = rect.y + 52 + i * 56
            if i == self.j_index:
                ui.cursor(dst, (rect.x + 14, y + 6))
            mark = "▶" if jid == ch.job_id else " "
            ui.text(dst, f"{mark} {job.name}", (rect.x + 40, y), 22)
            lv = ch.job_level(jid)
            pts = ch.job_abp(jid)
            nxt = next((cost for cost, _ in job.learnset if pts < cost), None)
            info = f"JLv{lv}  ABP {pts}" + (f"/{nxt}" if nxt else "  マスター")
            if not job.learnset:
                info = "―"
            ui.text(dst, info, (rect.x + 250, y + 4), 16, C.COLOR_TEXT_DIM)
            pygame.draw.rect(dst, job.color,
                             (rect.x + 44, y + 30, 180, 4))

    def _draw_abilities(self, dst: pygame.Surface) -> None:
        ch = self.char
        rect = pygame.Rect(440, 120, 500, 500)
        ui.draw_window(dst, rect)
        ui.text(dst, f"{ch.name} のアビリティ", (rect.x + 24, rect.y + 14),
                22, C.COLOR_TEXT_YELLOW)
        options = self._ability_options()
        for i, (aid, label) in enumerate(options[:12]):
            y = rect.y + 52 + i * 34
            if i == self.a_index:
                ui.cursor(dst, (rect.x + 14, y + 2))
            mark = "Ｅ" if aid is not None and aid == ch.equipped else "　"
            ui.text(dst, f"{mark}{label}", (rect.x + 40, y), 20)
        if 0 <= self.a_index < len(options):
            aid = options[self.a_index][0]
            desc = ABILITIES[aid].desc if aid else "アビリティを はずす"
            ui.text(dst, desc, (rect.x + 24, rect.bottom - 46), 16,
                    C.COLOR_TEXT_DIM)
