"""Roguelike dungeon scene: 自動生成フロアの探索.

シンボルエンカウント/追跡/CT風その場バトルは従来どおり。
階段で次のフロアへ。宝箱・回復クリスタル・ボス (B5F/B10F) がある。
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Callable

import pygame

from jobquest import config as C
from jobquest import sfx, sprites, ui
from jobquest.dungeon_gen import (BLOCKED, GUARDIAN_FLOOR, MAX_FLOOR,
                                  THEME_NAMES, H as MAP_H, W as MAP_W,
                                  FloorPlan)
from jobquest.models import ITEMS, Character, Inventory

TP = C.TILE_PX
WORLD_W = MAP_W * TP
WORLD_H = MAP_H * TP

PLAYER_SPEED = 240.0
SYMBOL_SPEED = 55.0
CHASE_SPEED = 95.0

# フロアごとの宝箱テーブル: (アイテムid, 重み)
CHEST_TABLES = {
    "grass": (("potion", 5), ("ether", 2), ("hi_potion", 1)),
    "tech": (("potion", 3), ("hi_potion", 3), ("ether", 3)),
    "ruin": (("hi_potion", 4), ("ether", 3), ("potion", 1)),
}


def _tile_center(tile: tuple[int, int]) -> tuple[float, float]:
    return tile[0] * TP + TP / 2, tile[1] * TP + TP / 2


@dataclass
class Symbol:
    x: float
    y: float
    group: list[str]
    vx: float = 0.0
    vy: float = 0.0
    turn_timer: float = 0.0
    alive: bool = True

    @property
    def sprite(self) -> str:
        from jobquest.models import SPECIES

        return SPECIES[self.group[0]].sprite


class DungeonScene:
    def __init__(self, party: list[Character], inventory: Inventory,
                 rng: random.Random,
                 on_encounter: Callable[[list[str], str | None, dict], None],
                 on_menu: Callable[[], None],
                 on_descend: Callable[[], None]) -> None:
        self.party = party
        self.inventory = inventory
        self.rng = rng
        self.on_encounter = on_encounter
        self.on_menu = on_menu
        self.on_descend = on_descend
        self.time = 0.0
        self.moving = False
        self.facing = "down"
        self.heal_cooldown = 0.0
        self.stairs_cooldown = 0.0
        self.flash = 0.0
        self.messages: list[str] = []
        self.plan: FloorPlan | None = None

    # ------------------------------------------------------------------

    def load_floor(self, plan: FloorPlan) -> None:
        self.plan = plan
        self.px, self.py = _tile_center(plan.start)
        self.opened: set[tuple[int, int]] = set()
        self.boss_alive = plan.boss is not None
        self.symbols = [Symbol(*_tile_center((tx, ty)), group=group)
                        for tx, ty, group in plan.spawns]
        self.stairs_cooldown = 1.0
        self.flash = 1.0
        name = THEME_NAMES[plan.theme]
        self.queue_message(f"B{plan.floor}F  {name}")
        if plan.floor == GUARDIAN_FLOOR and plan.boss_id == "guardian":
            self.queue_message("…かいだんのまえに きかいの ばんにんが いる。")
        if plan.floor >= MAX_FLOOR:
            self.queue_message("さいかそう…！ まおうの けはいがする。")

    def queue_message(self, *lines: str) -> None:
        self.messages.extend(lines)

    # ------------------------------------------------------------------

    def _blocked_at(self, px: float, py: float) -> bool:
        tx, ty = int(px // TP), int(py // TP)
        if not (0 <= tx < MAP_W and 0 <= ty < MAP_H):
            return True
        return self.plan.grid[ty][tx] in BLOCKED

    def _rect_blocked(self, rect: pygame.Rect) -> bool:
        return any(self._blocked_at(x, y) for x, y in
                   (rect.topleft, rect.topright,
                    rect.bottomleft, rect.bottomright))

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        if self.messages:
            if event.key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE,
                             pygame.K_x):
                sfx.play("confirm")
                self.messages.pop(0)
            return
        if event.key in (pygame.K_x, pygame.K_ESCAPE, pygame.K_m):
            self.on_menu()

    # ------------------------------------------------------------------

    def update(self, dt: float) -> None:
        self.time += dt
        self.heal_cooldown = max(0.0, self.heal_cooldown - dt)
        self.stairs_cooldown = max(0.0, self.stairs_cooldown - dt)
        self.flash = max(0.0, self.flash - dt * 1.6)
        if self.messages:
            return

        from jobquest import touch

        keys = pygame.key.get_pressed()
        tdx, tdy = touch.get_dir()
        vx = max(-1.0, min(1.0, keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]
                           + tdx))
        vy = max(-1.0, min(1.0, keys[pygame.K_DOWN] - keys[pygame.K_UP]
                           + tdy))
        dx = vx * PLAYER_SPEED * dt
        dy = vy * PLAYER_SPEED * dt
        self.moving = bool(dx or dy)
        if dy < 0:
            self.facing = "up"
        elif dy > 0 or dx:
            self.facing = "down"
        self._move_player(dx, dy)
        self._update_symbols(dt)
        self._check_tiles()
        self._check_encounters()

    def _move_player(self, dx: float, dy: float) -> None:
        half = 16
        for axis_dx, axis_dy in ((dx, 0.0), (0.0, dy)):
            if not (axis_dx or axis_dy):
                continue
            nx, ny = self.px + axis_dx, self.py + axis_dy
            rect = pygame.Rect(int(nx - half), int(ny - half),
                               half * 2, half * 2)
            if not self._rect_blocked(rect):
                self.px, self.py = nx, ny

    def _update_symbols(self, dt: float) -> None:
        for sym in self.symbols:
            if not sym.alive:
                continue
            dist = math.hypot(self.px - sym.x, self.py - sym.y)
            if dist < 200:
                vx = (self.px - sym.x) / max(1, dist) * CHASE_SPEED
                vy = (self.py - sym.y) / max(1, dist) * CHASE_SPEED
            else:
                sym.turn_timer -= dt
                if sym.turn_timer <= 0:
                    sym.turn_timer = self.rng.uniform(0.8, 2.0)
                    ang = self.rng.uniform(0, math.tau)
                    sym.vx = math.cos(ang) * SYMBOL_SPEED
                    sym.vy = math.sin(ang) * SYMBOL_SPEED
                vx, vy = sym.vx, sym.vy
            nx, ny = sym.x + vx * dt, sym.y + vy * dt
            rect = pygame.Rect(int(nx - 14), int(ny - 14), 28, 28)
            if not self._rect_blocked(rect):
                sym.x, sym.y = nx, ny
            else:
                sym.turn_timer = 0.0

    # ------------------------------------------------------------------

    def _near(self, tile: tuple[int, int] | None, r: float) -> bool:
        if tile is None:
            return False
        cx, cy = _tile_center(tile)
        return math.hypot(self.px - cx, self.py - cy) < r

    def _check_tiles(self) -> None:
        plan = self.plan
        if self._near(plan.crystal, TP * 0.9) and self.heal_cooldown <= 0:
            self.heal_cooldown = 3.0
            for ch in self.party:
                ch.hp = ch.max_hp
                ch.mp = ch.max_mp
            sfx.play("save")
            self.queue_message("クリスタルの ひかりで ぜんかいふくした！")
        for chest in plan.chests:
            if chest not in self.opened and self._near(chest, TP * 0.8):
                self.opened.add(chest)
                table = CHEST_TABLES[plan.theme]
                items = [iid for iid, _ in table]
                weights = [w for _, w in table]
                item = self.rng.choices(items, weights=weights, k=1)[0]
                self.inventory.add(item)
                sfx.play("confirm")
                self.queue_message(
                    f"たからばこを あけた！ 『{ITEMS[item][0]}』を てにいれた。")
        if (plan.stairs is not None and not self.boss_alive_blocks_stairs()
                and self._near(plan.stairs, TP * 0.7)
                and self.stairs_cooldown <= 0):
            self.on_descend()

    def boss_alive_blocks_stairs(self) -> bool:
        """ガーディアン階では倒すまで階段が封じられる."""
        return (self.plan.boss_id == "guardian" and self.boss_alive)

    def _check_encounters(self) -> None:
        prect = pygame.Rect(int(self.px - 18), int(self.py - 18), 36, 36)
        plan = self.plan
        if self.boss_alive and plan.boss is not None:
            bx, by = _tile_center(plan.boss)
            if prect.colliderect(pygame.Rect(int(bx - 28), int(by - 28),
                                             56, 56)):
                self.px, self.py = bx, by + TP * 1.4
                self.on_encounter([plan.boss_id], plan.boss_id,
                                  self._battle_ctx(bx, by))
                return
        for sym in self.symbols:
            if sym.alive and prect.colliderect(
                    pygame.Rect(int(sym.x - 16), int(sym.y - 16), 32, 32)):
                sym.alive = False
                self.on_encounter(list(sym.group), None,
                                  self._battle_ctx(sym.x, sym.y))
                return

    def _camera(self) -> tuple[int, int]:
        return (int(min(max(self.px - C.SCREEN_W / 2, 0),
                        WORLD_W - C.SCREEN_W)),
                int(min(max(self.py - C.SCREEN_H / 2, 0),
                        WORLD_H - C.SCREEN_H)))

    def _battle_ctx(self, ex: float, ey: float) -> dict:
        cam_x, cam_y = self._camera()
        return {"player": (self.px - cam_x, self.py - cam_y),
                "enemy": (ex - cam_x, ey - cam_y)}

    # ------------------------------------------------------------------

    @staticmethod
    def _decor_at(kind: str, tx: int, ty: int) -> str | None:
        h = ((tx * 73856093) ^ (ty * 19349663)) & 0xFFFFF
        if kind == "G":
            if h % 41 == 0:
                return "flower_r"
            if h % 47 == 5:
                return "flower_y"
            if h % 13 == 2:
                return "tuft"
        elif kind == "D" and h % 17 == 3:
            return "rock"
        return None

    def draw(self, dst: pygame.Surface, hud: bool = True) -> None:
        cam_x, cam_y = self._camera()
        plan = self.plan
        anim = int(self.time * 1.8)
        tx0, ty0 = cam_x // TP, cam_y // TP
        for ty in range(ty0, min(MAP_H, ty0 + C.SCREEN_H // TP + 2)):
            for tx in range(tx0, min(MAP_W, tx0 + C.SCREEN_W // TP + 2)):
                kind = plan.grid[ty][tx]
                px, py = tx * TP - cam_x, ty * TP - cam_y
                dst.blit(sprites.tile(kind, C.SCALE, anim), (px, py))
                deco = self._decor_at(kind, tx, ty)
                if deco:
                    dst.blit(sprites.decor(deco, C.SCALE), (px, py))

        def blit_at(img: pygame.Surface, tile: tuple[int, int]) -> None:
            x, y = _tile_center(tile)
            dst.blit(img, img.get_rect(center=(int(x - cam_x),
                                               int(y - cam_y))))

        if plan.stairs is not None:
            blit_at(sprites.decor("stairs", C.SCALE), plan.stairs)
        if plan.crystal is not None:
            blit_at(sprites.tile("C", C.SCALE, anim), plan.crystal)
        for chest in plan.chests:
            kind = "chest_open" if chest in self.opened else "chest"
            blit_at(sprites.decor(kind, C.SCALE), chest)
        if self.boss_alive and plan.boss is not None:
            sprite = "boss" if plan.boss_id == "maou" else "guardian"
            blit_at(sprites.enemy(sprite, 4), plan.boss)

        for sym in self.symbols:
            if not sym.alive:
                continue
            img = sprites.enemy(sym.sprite, C.SCALE)
            dst.blit(img, img.get_rect(
                center=(int(sym.x - cam_x), int(sym.y - cam_y))))

        leader = self.party[0]
        frame = int(self.time * 7) % 2 if self.moving else 0
        img = sprites.chara(leader, C.SCALE, self.facing, frame)
        bob = int(abs(math.sin(self.time * 9)) * 3) if self.moving else 0
        dst.blit(img, img.get_rect(
            center=(int(self.px - cam_x), int(self.py - cam_y) - bob)))

        if plan.theme == "tech":
            tint = pygame.Surface(dst.get_size(), pygame.SRCALPHA)
            tint.fill((60, 20, 70, 42))
            dst.blit(tint, (0, 0))
        elif plan.theme == "ruin":
            tint = pygame.Surface(dst.get_size(), pygame.SRCALPHA)
            tint.fill((20, 24, 70, 52))
            dst.blit(tint, (0, 0))
        if self.flash > 0:
            white = pygame.Surface(dst.get_size(), pygame.SRCALPHA)
            white.fill((255, 255, 255, int(220 * self.flash)))
            dst.blit(white, (0, 0))

        if hud:
            hint = pygame.Rect(12, 12, 560, 40)
            ui.draw_window(dst, hint)
            leader = self.party[0]
            ui.text(dst, f"B{plan.floor}F  Lv{leader.level}  "
                    "やじるし:いどう  Z:けってい  X:メニュー",
                    (hint.x + 14, hint.y + 7), 18)

        if self.messages:
            box = pygame.Rect(60, C.SCREEN_H - 130, C.SCREEN_W - 120, 100)
            ui.draw_window(dst, box)
            ui.text(dst, self.messages[0], (box.x + 24, box.y + 20), 22)
            if int(self.time * 2) % 2 == 0:
                ui.text(dst, "▼", (box.right - 44, box.bottom - 36), 20,
                        C.COLOR_TEXT_YELLOW)
