"""JOB QUEST ROGUE: FF5風ジョブ × クロノトリガー風ATBのローグライクRPG.

ラン制: 毎回レベル1で自動生成ダンジョン (B1F〜B10F) に挑む。
全滅したらランは終了。だがジョブのABPだけは引き継がれる。

Usage:
    uv run python jobquest/main.py [--seed N]
    uv run python jobquest/main.py --smoke   # ヘッドレス自動走行 (CI用)
"""

from __future__ import annotations

import argparse
import asyncio
import os
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class Game:
    def __init__(self, seed: int | None = None) -> None:
        import pygame

        from jobquest import music, save, sfx
        from jobquest.config import FPS, SCREEN_H, SCREEN_W
        from jobquest.title import TitleScene

        pygame.init()
        sfx.init()
        music.init()
        self.pygame = pygame
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        pygame.display.set_caption("JOB QUEST ROGUE -クリスタルとまおう-")
        self.clock = pygame.time.Clock()
        self.fps = FPS

        self.rng = random.Random(seed)
        self.party = []
        self.inventory = None
        self.floor = 1
        self.robo_unlocked = False
        self.best_floor = 0
        self.play_seconds = 0.0
        self.runs = 0
        self.clears = 0
        self.boss_battle_id: str | None = None
        self.current_node = None
        self.last_route_id: int | None = None
        self.run_map = None
        self.menu_return_scene = None

        self.scene = TitleScene(save.exists(), self._on_title,
                                best_floor=self._saved_best())
        music.play("title")

    def _saved_best(self) -> int:
        from jobquest import save

        data = save.read()
        return int(data.get("best_floor", 0)) if data else 0

    # ------------------------------------------------------------------
    # ラン管理
    # ------------------------------------------------------------------

    def _on_title(self, load_save: bool) -> None:
        from jobquest import save

        meta = save.read() if load_save else None
        self.new_run(meta)

    def new_run(self, meta: dict | None) -> None:
        from jobquest import save
        from jobquest.models import Inventory, make_party, make_robo
        from jobquest.nodes import generate_run_map

        self.party = make_party(level=1)
        self.robo_unlocked = False
        self.best_floor = 0
        if meta is not None:
            flags = save.apply_meta(meta, self.party)
            self.robo_unlocked = flags["robo_unlocked"]
            self.best_floor = flags["best_floor"]
            self.play_seconds = float(flags["play_time"])
            self.runs = flags["runs"]
            self.clears = flags["clears"]
        if self.robo_unlocked:
            robo = make_robo(level=1)
            if meta is not None:
                save.apply_meta(meta, [robo])
            self.party.append(robo)
        self.runs += 1
        self.inventory = Inventory()
        self.floor = 1
        self.current_node = None
        self.last_route_id = None
        self.run_map = generate_run_map(self.rng, self.robo_unlocked)
        self._load_floor()

    def _load_floor(self) -> None:
        from jobquest import music, sfx
        from jobquest.node_scene import NodeSelectScene
        from jobquest.nodes import theme_for

        spots = self.run_map.next_choices(self.last_route_id)
        nodes = [spot.node for spot in spots]
        self.scene = NodeSelectScene(
            self.floor, nodes, self.party, self.inventory, self.rng,
            on_battle=self.pick_node,
            on_rewards=self._show_rewards_from_scene,
            on_shop=self._show_shop_from_scene,
            on_menu=self.open_menu,
            on_event=self._show_event)
        self.best_floor = max(self.best_floor, self.floor)
        self.save_meta()
        sfx.play("gate")
        theme_bgm = {"grass": "field", "tech": "future", "ruin": "boss"}
        music.play("future" if self.floor >= 10
                   else theme_bgm[theme_for(self.floor)])

    def descend(self) -> None:
        self.floor += 1
        self._load_floor()

    def pick_node(self, node) -> None:
        self.current_node = node
        if node.kind in ("battle", "elite", "boss"):
            self.start_battle(list(node.group), node.boss_id)

    def _selected_scene_node(self):
        return self.scene.nodes[self.scene.index]

    def _show_rewards_from_scene(self, rewards) -> None:
        self._show_rewards(rewards, self._selected_scene_node())

    def _show_shop_from_scene(self, rewards) -> None:
        self._show_shop(rewards, self._selected_scene_node())

    def _show_rewards(self, rewards, node=None) -> None:
        from jobquest.node_scene import RewardSelectScene

        if node is not None:
            self.current_node = node
        self.scene = RewardSelectScene(self.party, rewards, self.inventory,
                                      on_done=self._after_reward)

    def _show_shop(self, rewards, node=None) -> None:
        from jobquest.node_scene import RewardSelectScene

        if node is not None:
            self.current_node = node
        self.scene = RewardSelectScene(self.party, rewards, self.inventory,
                                      on_done=self._after_reward, shop=True)

    def _show_event(self, node) -> None:
        from jobquest.node_scene import EventScene
        from jobquest.nodes import apply_event

        self.current_node = node
        result = apply_event(self.party, self.inventory, self.floor, self.rng)
        self.scene = EventScene(result.lines, on_done=self._after_reward)

    def save_meta(self) -> None:
        from jobquest import save

        save.write(save.build_meta(self.party, self.robo_unlocked,
                                   self.best_floor, self.play_seconds,
                                   self.runs, self.clears))

    # ------------------------------------------------------------------
    # シーン遷移
    # ------------------------------------------------------------------

    def start_battle(self, group: list[str], boss_id: str | None = None,
                     ctx: dict | None = None) -> None:
        from jobquest import music, sfx
        from jobquest.battle_scene import BattleScene
        from jobquest.nodes import enemy_scale
        from jobquest.engine import BattleEngine
        from jobquest.models import spawn_group

        sfx.play("battle")
        music.play("boss" if boss_id else "battle")
        self.boss_battle_id = boss_id
        background = self._battle_background()
        scale = enemy_scale(self.floor)
        if boss_id:  # ボスは元々強いのでフロア倍率を緩和
            scale = 1.0 + (scale - 1.0) * 0.35
        enemies = spawn_group(group, scale=scale)
        engine = BattleEngine(self.party, enemies, self.inventory,
                              self.rng, can_escape=boss_id is None)
        self.scene = BattleScene(engine, background,
                                 on_finish=self.end_battle, ctx=ctx)

    def _battle_background(self):
        pygame = self.pygame
        bg = pygame.Surface(self.screen.get_size())
        bg.fill((18, 22, 34))
        pygame.draw.rect(bg, (26, 28, 44), (0, 0, bg.get_width(), 110))
        pygame.draw.rect(bg, (16, 18, 30), (0, 430, bg.get_width(), 210))
        return bg

    def end_battle(self, outcome: str) -> None:
        from jobquest import music
        from jobquest.ending import EndingScene, RunOverScene
        from jobquest.nodes import full_restore, generate_rewards, reward_tier

        if outcome == "defeat":
            self.save_meta()
            self.scene = RunOverScene(self.party, self.floor,
                                      self.inventory.gil,
                                      on_close=self._to_title)
            return
        if outcome == "victory" and self.boss_battle_id == "maou":
            self.clears += 1
            self.save_meta()
            self.boss_battle_id = None
            self.scene = EndingScene(self.party, self.play_seconds,
                                     self.inventory.gil,
                                     on_close=self._to_title)
            return
        if outcome == "victory" and self.boss_battle_id == "guardian":
            self._on_guardian_defeated()
        if outcome == "victory":
            tier = reward_tier(self.floor)
            if self.current_node is not None and self.current_node.kind == "elite":
                tier = min(4, tier + 1)
            rewards = generate_rewards(tier, self.rng)
            self.boss_battle_id = None
            music.play("field")
            self._show_rewards(rewards)
            return
        if outcome == "escape":
            full_restore(self.party)
            if self.current_node is not None and self.current_node.route_id >= 0:
                self.last_route_id = self.current_node.route_id
            self.current_node = None
        self.boss_battle_id = None
        self.descend()

    def _after_reward(self) -> None:
        if self.current_node is not None and self.current_node.route_id >= 0:
            self.last_route_id = self.current_node.route_id
        elif self.last_route_id is None and self.floor == 1:
            self.last_route_id = self.run_map.start_choices()[0].id
        self.current_node = None
        self.descend()

    def _on_guardian_defeated(self) -> None:
        from jobquest.models import make_robo

        self.robo_unlocked = True
        level = max(ch.level for ch in self.party)
        self.party.append(make_robo(level))
        self.save_meta()

    def _to_title(self) -> None:
        from jobquest import music, save
        from jobquest.title import TitleScene

        self.scene = TitleScene(save.exists(), self._on_title,
                                best_floor=self._saved_best())
        music.play("title")

    def open_menu(self) -> None:
        from jobquest.menu import MenuScene

        self.menu_return_scene = self.scene
        self.scene = MenuScene(self.party, self.inventory,
                               on_close=self.close_menu)

    def close_menu(self) -> None:
        self.scene = self.menu_return_scene
        self.menu_return_scene = None

    # ------------------------------------------------------------------
    # メインループ
    # ------------------------------------------------------------------

    def _dispatch_tap(self, event) -> None:
        """仮想パッド外のタップ/クリックをシーンへ渡す (スマホ直接操作)."""
        pygame = self.pygame
        from jobquest.config import SCREEN_H, SCREEN_W

        from jobquest import touch

        if event.type == pygame.FINGERDOWN:
            pos = (event.x * SCREEN_W, event.y * SCREEN_H)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if touch.finger_recent():  # タッチ由来のマウス擬似イベントは無視
                return
            pos = event.pos
        else:
            return
        handler = getattr(self.scene, "handle_tap", None)
        if handler is not None:
            handler(pos)

    async def run_async(self) -> None:
        """pygbag (ブラウザ/WASM) 対応のため async メインループ."""
        from jobquest import touch

        pygame = self.pygame
        running = True
        while running:
            dt = min(self.clock.tick(self.fps) / 1000.0, 0.05)
            self.play_seconds += dt
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif not touch.handle_event(event):
                    self._dispatch_tap(event)
                    self.scene.handle_event(event)
            touch.tick(dt)
            self.scene.update(dt)
            self.scene.draw(self.screen)
            touch.draw(self.screen)
            pygame.display.flip()
            await asyncio.sleep(0)
        pygame.quit()

    def run(self) -> None:
        asyncio.run(self.run_async())

    # ------------------------------------------------------------------
    # スモークテスト
    # ------------------------------------------------------------------

    def run_smoke(self, max_frames: int = 7200) -> None:
        pygame = self.pygame
        from jobquest.ending import RunOverScene
        from jobquest.node_scene import NodeSelectScene, RewardSelectScene

        # 0) タイトル -> 新しいラン (レベル1)
        self.scene.handle_event(
            pygame.event.Event(pygame.KEYDOWN, key=pygame.K_z))
        if not isinstance(self.scene, NodeSelectScene):
            pygame.quit()
            raise SystemExit("SMOKE FAILED: title did not start a run")
        if any(ch.level != 1 for ch in self.party):
            pygame.quit()
            raise SystemExit("SMOKE FAILED: run did not start at level 1")
        if self.inventory.listing():
            pygame.quit()
            raise SystemExit("SMOKE FAILED: consumable items were not removed")
        print("SMOKE OK: title -> new node run at Lv1")

        # 1) 戦闘 -> 報酬 -> 次フロア
        self.start_battle(["goblin"])
        frames = 0
        while frames < max_frames and not isinstance(self.scene,
                                                    RewardSelectScene):
            frames += 1
            if frames % 10 == 0:
                self.scene.handle_event(
                    pygame.event.Event(pygame.KEYDOWN, key=pygame.K_z))
            self.scene.update(1 / 60)
            self.scene.draw(self.screen)
        if not isinstance(self.scene, RewardSelectScene):
            pygame.quit()
            raise SystemExit("SMOKE FAILED: battle did not finish")
        for key in (pygame.K_z, pygame.K_z):
            self.scene.handle_event(
                pygame.event.Event(pygame.KEYDOWN, key=key))
            self.scene.update(1 / 60)
            self.scene.draw(self.screen)
        if not isinstance(self.scene, NodeSelectScene) or self.floor != 2:
            pygame.quit()
            raise SystemExit("SMOKE FAILED: reward did not advance floor")
        print(f"SMOKE OK: battle reward advanced to B{self.floor}F")

        # 2) メニュー: ジョブチェンジできること
        chris = self.party[0]
        job_before = chris.job_id
        self.open_menu()
        for key in (pygame.K_z, pygame.K_z, pygame.K_DOWN, pygame.K_DOWN,
                    pygame.K_z, pygame.K_x, pygame.K_x):
            self.scene.handle_event(
                pygame.event.Event(pygame.KEYDOWN, key=key))
            self.scene.update(1 / 60)
            self.scene.draw(self.screen)
        if not isinstance(self.scene, NodeSelectScene) \
                or chris.job_id == job_before:
            pygame.quit()
            raise SystemExit("SMOKE FAILED: job change did not work")
        print(f"SMOKE OK: job change {job_before} -> {chris.job_id}")

        # 3) ノード選択画面の更新と直接降下
        floor_before = self.floor
        self.descend()
        if self.floor != floor_before + 1:
            pygame.quit()
            raise SystemExit("SMOKE FAILED: node descend did not advance")
        self.scene.update(1 / 60)
        self.scene.draw(self.screen)
        print(f"SMOKE OK: descended to B{self.floor}F")

        # 4) 全滅 -> ランオーバー -> タイトル -> 新ランでLv1 & ABP引き継ぎ
        self.party[0].gain_abp(15)
        abp_before = self.party[0].job_abp(self.party[0].job_id)
        for ch in self.party:
            ch.hp = 0
        self.end_battle("defeat")
        if not isinstance(self.scene, RunOverScene):
            pygame.quit()
            raise SystemExit("SMOKE FAILED: run over scene did not open")
        self.scene.handle_event(
            pygame.event.Event(pygame.KEYDOWN, key=pygame.K_z))
        self.scene.handle_event(   # タイトル -> つづきから
            pygame.event.Event(pygame.KEYDOWN, key=pygame.K_z))
        if not isinstance(self.scene, NodeSelectScene):
            pygame.quit()
            raise SystemExit("SMOKE FAILED: could not start next run")
        chris = self.party[0]
        if chris.level != 1:
            pygame.quit()
            raise SystemExit("SMOKE FAILED: level did not reset to 1")
        if chris.job_abp(chris.job_id) == 0 and abp_before:
            pygame.quit()
            raise SystemExit("SMOKE FAILED: ABP was not carried over")
        print("SMOKE OK: death resets level, ABP carries over")
        pygame.quit()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--smoke", action="store_true",
                        help="run headless smoke test and exit")
    args = parser.parse_args()

    if args.smoke:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    game = Game(seed=args.seed)
    if args.smoke:
        game.run_smoke()
    else:
        game.run()


if __name__ == "__main__":
    main()
