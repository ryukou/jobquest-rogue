"""Touch support (スマホ/ブラウザ用).

操作はすべて「画面の直接タップ」(シングルタップ即決定)。
唯一の常設ボタンとして右下に「もどる」(キャンセル) を表示する。
デスクトップでは非表示・無効 (マウスクリックはタップとして扱われる)。
"""

from __future__ import annotations

import math
import sys

import pygame

from jobquest import config as C

ENABLED = sys.platform == "emscripten"

BACK_CENTER = (C.SCREEN_W - 64, C.SCREEN_H - 64)
BACK_R = 48

_last_finger_ms = -10_000


def finger_recent(window_ms: int = 400) -> bool:
    """直前に指タッチがあったか (タッチ->マウス二重発火の抑止用)."""
    return pygame.time.get_ticks() - _last_finger_ms < window_ms


def _pos_of(event: pygame.event.Event) -> tuple[float, float]:
    if hasattr(event, "x"):  # FINGER* は 0..1 正規化座標
        return event.x * C.SCREEN_W, event.y * C.SCREEN_H
    return event.pos


def handle_event(event: pygame.event.Event) -> bool:
    """「もどる」ボタンのタップを処理。消費したら True."""
    global _last_finger_ms
    if event.type in (pygame.FINGERDOWN, pygame.FINGERMOTION,
                      pygame.FINGERUP):
        _last_finger_ms = pygame.time.get_ticks()
    if not ENABLED:
        return False
    if event.type == pygame.FINGERDOWN:
        pass
    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        if finger_recent():
            return False  # タッチ由来の擬似マウスは指側で処理済み
    else:
        return False
    x, y = _pos_of(event)
    if math.hypot(x - BACK_CENTER[0], y - BACK_CENTER[1]) <= BACK_R * 1.25:
        pygame.event.post(pygame.event.Event(pygame.KEYDOWN,
                                             key=pygame.K_x))
        return True
    return False


def draw(dst: pygame.Surface) -> None:
    if not ENABLED:
        return
    overlay = pygame.Surface(dst.get_size(), pygame.SRCALPHA)
    pygame.draw.circle(overlay, (255, 255, 255, 36), BACK_CENTER, BACK_R)
    pygame.draw.circle(overlay, (255, 255, 255, 84), BACK_CENTER, BACK_R, 3)
    from jobquest.fonts import get_font

    font = get_font(20)
    img = font.render("もどる", True, (255, 255, 255))
    img.set_alpha(170)
    overlay.blit(img, img.get_rect(center=BACK_CENTER))
    dst.blit(overlay, (0, 0))
