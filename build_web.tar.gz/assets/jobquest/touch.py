"""Touch support (スマホ/ブラウザ用).

操作はすべて「画面の直接タップ」(シングルタップ即決定)。
唯一の常設ボタンとして右下に「もどる」(キャンセル) を表示する。
デスクトップでは非表示・無効 (マウスクリックはタップとして扱われる)。
"""

from __future__ import annotations

import math
import sys

import pygame

from jobquest import config as C

ENABLED = sys.platform == "emscripten"

BACK_CENTER = (C.SCREEN_W - 64, C.SCREEN_H - 64)
BACK_R = 48

# 「もどる」ボタンの安全領域: 他パネルはこの矩形を避けてレイアウトする。
# margin ぶん広めに取ってあるので、境界ぎりぎりの当たり判定でも被らない。
_SAFE_MARGIN = 20
SAFE_ZONE = pygame.Rect(
    BACK_CENTER[0] - BACK_R - _SAFE_MARGIN,
    BACK_CENTER[1] - BACK_R - _SAFE_MARGIN,
    (BACK_R + _SAFE_MARGIN) * 2, (BACK_R + _SAFE_MARGIN) * 2)

_last_finger_ms = -10_000
_overlay: pygame.Surface | None = None  # 毎フレーム再生成しないようキャッシュ


def safe_width(x: int, y: int, height: int, max_width: int) -> int:
    """(x, y, max_width, height)の帯が SAFE_ZONE の縦域と重なる場合のみ、

    もどるボタンに重ならない幅まで縮める (重ならない帯はそのまま)。
    """
    band = pygame.Rect(x, y, max_width, height)
    if not band.colliderect(SAFE_ZONE):
        return max_width
    return max(0, min(max_width, SAFE_ZONE.left - x))


def finger_recent(window_ms: int = 400) -> bool:
    """直前に指タッチがあったか (タッチ->マウス二重発火の抑止用)."""
    return pygame.time.get_ticks() - _last_finger_ms < window_ms


def _pos_of(event: pygame.event.Event) -> tuple[float, float]:
    if hasattr(event, "x"):  # FINGER* は 0..1 正規化座標
        return event.x * C.SCREEN_W, event.y * C.SCREEN_H
    return event.pos


def handle_event(event: pygame.event.Event) -> bool:
    """「もどる」ボタンのタップを処理。消費したら True."""
    global _last_finger_ms
    if event.type in (pygame.FINGERDOWN, pygame.FINGERMOTION,
                      pygame.FINGERUP):
        _last_finger_ms = pygame.time.get_ticks()
    if not ENABLED:
        return False
    if event.type == pygame.FINGERDOWN:
        pass
    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        if finger_recent():
            return False  # タッチ由来の擬似マウスは指側で処理済み
    else:
        return False
    x, y = _pos_of(event)
    if math.hypot(x - BACK_CENTER[0], y - BACK_CENTER[1]) <= BACK_R * 1.25:
        pygame.event.post(pygame.event.Event(pygame.KEYDOWN,
                                             key=pygame.K_x))
        return True
    return False


# ボタンぶんだけの小さいサーフェスにして、毎フレームの全画面ブリットを避ける
_OVERLAY_PAD = 4
_OVERLAY_SIZE = ((BACK_R + _OVERLAY_PAD) * 2, (BACK_R + _OVERLAY_PAD) * 2)
_OVERLAY_TOPLEFT = (BACK_CENTER[0] - BACK_R - _OVERLAY_PAD,
                    BACK_CENTER[1] - BACK_R - _OVERLAY_PAD)


def _build_overlay() -> pygame.Surface:
    from jobquest.fonts import get_font

    overlay = pygame.Surface(_OVERLAY_SIZE, pygame.SRCALPHA)
    local_center = (BACK_R + _OVERLAY_PAD, BACK_R + _OVERLAY_PAD)
    pygame.draw.circle(overlay, (255, 255, 255, 36), local_center, BACK_R)
    pygame.draw.circle(overlay, (255, 255, 255, 84), local_center, BACK_R, 3)
    font = get_font(20)
    img = font.render("もどる", True, (255, 255, 255))
    img.set_alpha(170)
    overlay.blit(img, img.get_rect(center=local_center))
    return overlay


def draw(dst: pygame.Surface, show_back: bool = True) -> None:
    global _overlay
    if not ENABLED or not show_back:
        return
    if _overlay is None:
        _overlay = _build_overlay()
    dst.blit(_overlay, _OVERLAY_TOPLEFT)
