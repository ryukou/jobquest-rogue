"""Virtual touch controls (スマホ/ブラウザ用の十字キー + Z/Xボタン).

pygbag (emscripten) 上では常に表示。デスクトップでは非表示・無効。
- 左下: 仮想十字キー (指の位置から8方向)
- 右下: Ｚ (けってい) / Ｘ (キャンセル) ボタン -> キーイベントとして注入
"""

from __future__ import annotations

import math
import sys

import pygame

from jobquest import config as C

ENABLED = sys.platform == "emscripten"

_PAD_CENTER = (120, C.SCREEN_H - 130)
_PAD_R = 100
_BTN_Z = (C.SCREEN_W - 70, C.SCREEN_H - 150)
_BTN_X = (C.SCREEN_W - 165, C.SCREEN_H - 62)
_BTN_R = 46

# ポインタid -> 役割 ("pad" | None)。マウスは "mouse" 固定id
_pointers: dict[object, str] = {}
_dir = (0.0, 0.0)


def _pos_of(event: pygame.event.Event) -> tuple[float, float]:
    if hasattr(event, "x"):  # FINGER* は 0..1 正規化座標
        return event.x * C.SCREEN_W, event.y * C.SCREEN_H
    return event.pos


def _pad_dir(x: float, y: float) -> tuple[float, float]:
    dx, dy = x - _PAD_CENTER[0], y - _PAD_CENTER[1]
    dist = math.hypot(dx, dy)
    if dist < 12:
        return 0.0, 0.0
    return dx / dist, dy / dist


def _hit_button(x: float, y: float) -> int | None:
    if math.hypot(x - _BTN_Z[0], y - _BTN_Z[1]) <= _BTN_R:
        return pygame.K_z
    if math.hypot(x - _BTN_X[0], y - _BTN_X[1]) <= _BTN_R:
        return pygame.K_x
    return None


def handle_event(event: pygame.event.Event) -> bool:
    """タッチ入力を処理。消費したら True."""
    global _dir
    if not ENABLED:
        return False
    if event.type in (pygame.FINGERDOWN, pygame.FINGERMOTION,
                      pygame.FINGERUP):
        pid = event.finger_id
    elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION,
                        pygame.MOUSEBUTTONUP):
        pid = "mouse"
        if event.type == pygame.MOUSEMOTION and pid not in _pointers:
            return False
    else:
        return False

    x, y = _pos_of(event)
    down = event.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN)
    up = event.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP)

    if down:
        if math.hypot(x - _PAD_CENTER[0], y - _PAD_CENTER[1]) <= _PAD_R * 1.4:
            _pointers[pid] = "pad"
            _dir = _pad_dir(x, y)
            return True
        key = _hit_button(x, y)
        if key is not None:
            _pointers[pid] = "btn"
            pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=key))
            return True
        return False
    if up:
        role = _pointers.pop(pid, None)
        if role == "pad":
            _dir = (0.0, 0.0)
        return role is not None
    # motion
    if _pointers.get(pid) == "pad":
        _dir = _pad_dir(x, y)
        return True
    return False


def get_dir() -> tuple[float, float]:
    return _dir


def draw(dst: pygame.Surface) -> None:
    if not ENABLED:
        return
    overlay = pygame.Surface(dst.get_size(), pygame.SRCALPHA)
    cx, cy = _PAD_CENTER
    pygame.draw.circle(overlay, (255, 255, 255, 34), (cx, cy), _PAD_R)
    pygame.draw.circle(overlay, (255, 255, 255, 70), (cx, cy), _PAD_R, 3)
    dx, dy = _dir
    knob = (int(cx + dx * 46), int(cy + dy * 46))
    pygame.draw.circle(overlay, (255, 255, 255, 90), knob, 34)
    for pos, label in ((_BTN_Z, "Z"), (_BTN_X, "X")):
        pygame.draw.circle(overlay, (255, 255, 255, 40), pos, _BTN_R)
        pygame.draw.circle(overlay, (255, 255, 255, 80), pos, _BTN_R, 3)
        font = pygame.font.Font(None, 44)
        img = font.render(label, True, (255, 255, 255))
        img.set_alpha(150)
        overlay.blit(img, img.get_rect(center=pos))
    dst.blit(overlay, (0, 0))
