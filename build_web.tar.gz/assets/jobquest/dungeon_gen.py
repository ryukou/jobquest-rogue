"""Procedural dungeon floor generation (pygame非依存の純ロジック).

部屋をランダム配置してL字通路で順につなぐ。全部屋が連結になるので
スタートから階段・宝箱へは必ず到達できる。
フロアが深くなるほどテーマが変わり (草原→機械→遺跡)、敵が強くなる。
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

W, H = 40, 30

BLOCKED = set("TWRS")

# テーマ: (壁タイル, 床タイル)
THEME_TILES = {
    "grass": ("T", "G"),
    "tech": ("S", "D"),
    "ruin": ("R", "F"),
}

THEME_NAMES = {"grass": "そうげんの かいそう",
               "tech": "きかいの かいそう",
               "ruin": "いせきの かいそう"}

GROUP_POOLS = {
    "grass": [["goblin"], ["goblin", "goblin"], ["goblin", "wolf"],
              ["wolf", "wolf"]],
    "tech": [["robot"], ["robot", "mutant"], ["mutant", "mutant"],
             ["robot", "robot", "mutant"]],
    "ruin": [["mage", "golem"], ["golem", "golem"],
             ["mage", "mage", "goblin"], ["mage", "robot", "robot"]],
}

MAX_FLOOR = 10
GUARDIAN_FLOOR = 5


def theme_for(floor: int) -> str:
    if floor <= 3:
        return "grass"
    if floor <= 6:
        return "tech"
    return "ruin"


def enemy_scale(floor: int) -> float:
    """フロアに応じた敵の強さ倍率."""
    return 1.0 + 0.16 * (floor - 1)


@dataclass
class Room:
    x: int
    y: int
    w: int
    h: int

    @property
    def center(self) -> tuple[int, int]:
        return self.x + self.w // 2, self.y + self.h // 2

    def overlaps(self, other: "Room") -> bool:
        return (self.x - 1 < other.x + other.w and
                other.x - 1 < self.x + self.w and
                self.y - 1 < other.y + other.h and
                other.y - 1 < self.y + self.h)


@dataclass
class FloorPlan:
    floor: int
    theme: str
    grid: list[str]
    start: tuple[int, int]
    stairs: tuple[int, int] | None
    chests: list[tuple[int, int]] = field(default_factory=list)
    crystal: tuple[int, int] | None = None
    boss: tuple[int, int] | None = None
    boss_id: str | None = None
    spawns: list[tuple[int, int, list[str]]] = field(default_factory=list)


def _carve_room(cells: list[list[str]], room: Room, ground: str) -> None:
    for y in range(room.y, room.y + room.h):
        for x in range(room.x, room.x + room.w):
            cells[y][x] = ground


def _carve_corridor(cells: list[list[str]], a: tuple[int, int],
                    b: tuple[int, int], ground: str,
                    rng: random.Random) -> None:
    (x1, y1), (x2, y2) = a, b
    if rng.random() < 0.5:
        mid = [(x, y1) for x in range(min(x1, x2), max(x1, x2) + 1)] \
            + [(x2, y) for y in range(min(y1, y2), max(y1, y2) + 1)]
    else:
        mid = [(x1, y) for y in range(min(y1, y2), max(y1, y2) + 1)] \
            + [(x, y2) for x in range(min(x1, x2), max(x1, x2) + 1)]
    for x, y in mid:
        cells[y][x] = ground


def _room_spot(room: Room, rng: random.Random,
               used: set[tuple[int, int]]) -> tuple[int, int]:
    for _ in range(20):
        pos = (rng.randrange(room.x, room.x + room.w),
               rng.randrange(room.y, room.y + room.h))
        if pos not in used:
            used.add(pos)
            return pos
    used.add(room.center)
    return room.center


def generate(floor: int, rng: random.Random,
             include_guardian: bool = True) -> FloorPlan:
    theme = theme_for(floor)
    wall, ground = THEME_TILES[theme]
    cells = [[wall] * W for _ in range(H)]

    rooms: list[Room] = []
    for _ in range(90):
        if len(rooms) >= 8:
            break
        w = rng.randrange(5, 10)
        h = rng.randrange(4, 8)
        room = Room(rng.randrange(1, W - w - 1), rng.randrange(1, H - h - 1),
                    w, h)
        if not any(room.overlaps(r) for r in rooms):
            rooms.append(room)
    for room in rooms:
        _carve_room(cells, room, ground)
    for a, b in zip(rooms, rooms[1:]):
        _carve_corridor(cells, a.center, b.center, ground, rng)

    used: set[tuple[int, int]] = set()
    start = rooms[0].center
    used.add(start)

    plan = FloorPlan(floor=floor, theme=theme,
                     grid=["".join(row) for row in cells],
                     start=start, stairs=None)

    last = rooms[-1]
    if floor >= MAX_FLOOR:
        plan.boss = last.center
        plan.boss_id = "maou"
        used.add(last.center)
    else:
        plan.stairs = last.center
        used.add(last.center)
        if floor == GUARDIAN_FLOOR and include_guardian:
            bx, by = last.center
            gpos = (bx, by - 1) if cells[by - 1][bx] == ground \
                else (bx - 1, by)
            plan.boss = gpos
            plan.boss_id = "guardian"
            used.add(gpos)

    mids = rooms[1:-1] or rooms[:1]
    for room in rng.sample(mids, k=min(len(mids), rng.randrange(2, 4))):
        plan.chests.append(_room_spot(room, rng, used))
    if floor % 3 == 0:
        plan.crystal = _room_spot(rng.choice(mids), rng, used)

    pools = GROUP_POOLS[theme]
    for room in rooms[1:]:
        if len(plan.spawns) >= 6:
            break
        if rng.random() < 0.75:
            pos = _room_spot(room, rng, used)
            plan.spawns.append((pos[0], pos[1], list(rng.choice(pools))))
    return plan


def reachable(plan: FloorPlan) -> set[tuple[int, int]]:
    """start から歩いて行けるタイル集合 (テスト用BFS)."""
    frontier = [plan.start]
    seen = {plan.start}
    while frontier:
        x, y = frontier.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if (0 <= nx < W and 0 <= ny < H and (nx, ny) not in seen
                    and plan.grid[ny][nx] not in BLOCKED):
                seen.add((nx, ny))
                frontier.append((nx, ny))
    return seen
