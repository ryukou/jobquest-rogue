# JOB QUEST ROGUE -クリスタルとまおう-

FF5のジョブシステム × クロノ・トリガー風ATBバトルの **ローグライクRPG**。
pygame-ce製、ドット絵・効果音・BGMはすべてプログラム生成
(フォントのみ同梱: PixelMplus, M+ FONT LICENSE)。

**ブラウザ版 (スマホ対応・公開中): https://ryukou.github.io/jobquest-rogue/**

## 起動

```sh
uv run python jobquest/main.py
uv run python jobquest/main.py --smoke   # ヘッドレス自動走行 (CI用)
uv run pytest tests/test_jobquest.py     # 純ロジックのユニットテスト
```

## ブラウザ版のビルドと公開

```sh
tools/build_web.sh --build   # pygbag (WASM) ビルド -> build_web/build/web/
tools/build_web.sh           # ビルド + ローカル配信 (localhost:8000)
```

- ローカル確認は **localhost:9000など「8」で始まらないポート** で静的配信すること
  (pygbagランタイムは URL が `localhost:8` で始まると開発サーバ用の
  `/cdn/` プロキシを探しに行き、pygame wheel の取得に失敗する)
- 公開は build_web/build/web/ を GitHub Pages (ryukou/jobquest-rogue リポジトリ) へ push
- pygbag エントリの main.py には `import pygame` が必須 (静的解析でパッケージ同梱を決める)
- ブラウザ版のセーブはページ内メモリのみ (リロードで消える)

## 操作

| キー | 動作 |
|---|---|
| 矢印 | 移動 / カーソル |
| Z / Enter | けってい |
| X / Esc | キャンセル / メニュー |

## ルール (ローグライク)

- 毎回 **レベル1** で自動生成ダンジョン (B1F〜B10F) に挑む
- **全滅したらランは終了**。レベル・アイテム・ギルは失われる
- ただし **ジョブのABP (ジョブレベル・習得アビリティ) だけは引き継がれる** —
  死ぬたびにジョブが熟練していく、FF5×ローグライトのメタ進行
- 深くなるほど敵が強くなり、テーマが変わる: そうげん(B1-3) → きかい(B4-6) → いせき(B7-10)
- **B5F**: ガーディアンが階段を封鎖。倒すと **ロボ** が永久解放 (以降のラン全てに参加)
- **B10F**: まおうグラドス。倒せばランクリア → エンディング
- 宝箱 (ポーション/エーテル類)、3フロアごとに全回復クリスタル
- 敵シンボルは近づくと追いかけてくる。触れると **その場の立ち位置のまま** ATBバトル

## バトル (クロノ・トリガー風)

- ウェイト式ATB (`config.py` の `BATTLE_ACTIVE=True` でアクティブ式に)
- 技名バナー + ダメージポップアップで戦闘は止まらない。斬撃/炎/氷/雷などのエフェクト + 画面シェイク
- **けり** / **グランドプレス** は狙った敵の周囲を巻き込む円形範囲
- ATB同時満タンで **れんけい**: Ｘぎり / かえんざん / しっぷうけん / グランドプレス / トリニティアタック(3人)

## ジョブ (FF5風)

すっぴん / ナイト / モンク / シーフ / にんじゃ / くろまどうし / しろまどうし / ときまどうし

戦闘でABPを獲得するとジョブレベルが上がり、コマンド・魔法・パッシブを習得。
Xメニューからジョブチェンジと、習得済みアビリティの付替え (1枠) ができる。

## 構成

| ファイル | 内容 |
|---|---|
| `jobs.py` / `models.py` / `engine.py` / `dungeon_gen.py` / `save.py` | pygame非依存の純ロジック (テスト対象) |
| `sprites.py` | 16x16ドット絵のプログラム生成 (歩行アニメ/アウトライン付き) |
| `sfx.py` / `music.py` | チップチューン効果音・BGM (5曲+ED) の合成 |
| `title.py` / `dungeon.py` / `battle_scene.py` / `menu.py` / `ending.py` | 各シーン |
| `ui.py` | FF風ウィンドウ・ゲージ描画 |
| `main.py` | ラン管理 / メインループ / smokeテスト |

メタ進行のセーブは `jobquest/save.json` (自動保存)。
