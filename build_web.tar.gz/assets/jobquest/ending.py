"""Ending scene (クリア) と RunOverScene (全滅)."""

from __future__ import annotations

import math
import random
from typing import Callable

import pygame

from jobquest import config as C
from jobquest import music, sfx, sprites, ui
from jobquest.models import Character

LINE_INTERVAL = 1.1


class EndingScene:
    show_back_button = False  # Zキー(タップ)専用。Xでのキャンセルは無い

    def __init__(self, party: list[Character], play_seconds: float,
                 gil: int, on_close: Callable[[], None]) -> None:
        self.party = party
        self.on_close = on_close
        self.time = 0.0
        self.closed = False
        rnd = random.Random(5)
        self.stars = [(rnd.randrange(0, C.SCREEN_W),
                       rnd.randrange(0, C.SCREEN_H - 160),
                       rnd.uniform(1.0, 3.0)) for _ in range(90)]

        minutes, seconds = divmod(int(play_seconds), 60)
        hours, minutes = divmod(minutes, 60)
        top_level = max(ch.level for ch in party)
        self.lines = [
            "まおうグラドスは たおされ",
            "ふたつのじだいに へいわが もどった。",
            "",
            f"プレイじかん  {hours:02d}:{minutes:02d}:{seconds:02d}",
            f"とうたつレベル  Lv{top_level}",
            f"しょじきん  {gil}ギル",
            "",
            "JOB QUEST -クリスタルとまおう-",
            "せいさく: RYUKO SOFT & Claude",
            "",
            "THE END",
        ]
        music.play("ending")

    @property
    def _shown(self) -> int:
        return min(len(self.lines), int(self.time / LINE_INTERVAL) + 1)

    def handle_tap(self, pos: tuple[float, float]) -> None:
        ui.post_key(pygame.K_z)

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN or self.closed:
            return
        if event.key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE):
            if self._shown < len(self.lines):
                self.time = len(self.lines) * LINE_INTERVAL  # スキップ
            else:
                sfx.play("confirm")
                self.closed = True
                self.on_close()

    def update(self, dt: float) -> None:
        self.time += dt

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((10, 10, 34))
        for x, y, size in self.stars:
            tw = 0.4 + 0.6 * abs(math.sin(self.time * 1.2 + x * 0.17))
            c = int(210 * tw)
            dst.fill((c, c, min(255, c + 40)), (x, y, int(size), int(size)))

        shown = self._shown
        for i, line in enumerate(self.lines[:shown]):
            if not line:
                continue
            size = 40 if line == "THE END" else 22
            color = C.COLOR_TEXT_YELLOW if line == "THE END" \
                else C.COLOR_TEXT
            ui.text_center(dst, line, (C.SCREEN_W // 2, 70 + i * 40),
                           size, color)

        # パーティが並んで手を振る(ぴょこぴょこ)
        n = len(self.party)
        for i, ch in enumerate(self.party):
            img = sprites.chara(ch, 5, frame=int(self.time * 3 + i) % 2)
            bob = int(abs(math.sin(self.time * 3 + i * 0.9)) * 8)
            x = C.SCREEN_W // 2 + (i - (n - 1) / 2) * 110
            dst.blit(img, img.get_rect(center=(int(x), 560 - bob)))

        if shown >= len(self.lines) and int(self.time * 2) % 2 == 0:
            ui.text_center(dst, "Z: タイトルへもどる",
                           (C.SCREEN_W // 2, C.SCREEN_H - 22), 16,
                           C.COLOR_TEXT_DIM)


class RunOverScene:
    """全滅: たんけん失敗。ABPは残ることを伝えてタイトルへ."""

    show_back_button = False  # Zキー(タップ)専用。Xでのキャンセルは無い

    def __init__(self, party: list[Character], floor: int, gil: int,
                 on_close: Callable[[], None]) -> None:
        self.party = party
        self.on_close = on_close
        self.time = 0.0
        self.closed = False
        top_level = max(ch.level for ch in party)
        self.lines = [
            "パーティは ぜんめつした……",
            "",
            f"とうたつフロア  B{floor}F",
            f"とうたつレベル  Lv{top_level}",
            f"かくとくギル  {gil}",
            "",
            "だが ジョブの けいけん (ABP) は うしなわれない。",
            "つよくなって もういちど いどもう！",
        ]
        music.stop(300)
        sfx.play("gameover")

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN or self.closed:
            return
        if event.key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE):
            sfx.play("confirm")
            self.closed = True
            self.on_close()

    def handle_tap(self, pos: tuple[float, float]) -> None:
        ui.post_key(pygame.K_z)

    def update(self, dt: float) -> None:
        self.time += dt

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((26, 10, 16))
        box = pygame.Rect(C.SCREEN_W // 2 - 320, 90, 640, 400)
        ui.draw_window(dst, box)
        for i, line in enumerate(self.lines):
            if not line:
                continue
            color = C.COLOR_TEXT_YELLOW if "ABP" in line or "いどもう" in line \
                else C.COLOR_TEXT
            ui.text_center(dst, line, (C.SCREEN_W // 2, box.y + 40 + i * 40),
                           22, color)
        for i, ch in enumerate(self.party):
            img = sprites.chara(ch, 4)
            img = pygame.transform.rotate(img, 90)
            img.set_alpha(150)
            n = len(self.party)
            x = C.SCREEN_W // 2 + (i - (n - 1) / 2) * 100
            dst.blit(img, img.get_rect(center=(int(x), 550)))
        if int(self.time * 2) % 2 == 0:
            ui.text_center(dst, "Z: タイトルへ",
                           (C.SCREEN_W // 2, C.SCREEN_H - 22), 16,
                           C.COLOR_TEXT_DIM)
