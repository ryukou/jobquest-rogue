"""SNES-style title screen: はじめから / つづきから."""

from __future__ import annotations

import math
import random
from typing import Callable

import pygame

from jobquest import config as C
from jobquest import build_info
from jobquest import sfx, sprites, ui


class TitleScene:
    show_back_button = False  # トップ画面には「もどる」先がない

    def __init__(self, has_save: bool, on_pick: Callable[[bool], None],
                 best_floor: int = 0) -> None:
        self.has_save = has_save
        self.on_pick = on_pick
        self.best_floor = best_floor
        self.index = 1 if has_save else 0
        self.time = 0.0
        rnd = random.Random(20260703)
        self.stars = [(rnd.randrange(0, C.SCREEN_W),
                       rnd.randrange(0, C.SCREEN_H - 200),
                       rnd.uniform(1.0, 3.0)) for _ in range(70)]

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        if event.key in (pygame.K_UP, pygame.K_DOWN):
            self.index = 1 - self.index
            sfx.play("cursor")
        elif event.key in (pygame.K_z, pygame.K_RETURN, pygame.K_SPACE):
            if self.index == 1 and not self.has_save:
                sfx.play("cancel")
                return
            sfx.play("confirm")
            self.on_pick(self.index == 1)

    def handle_tap(self, pos: tuple[float, float]) -> None:
        box = pygame.Rect(C.SCREEN_W // 2 - 170, 420, 340, 110)
        for i in range(2):
            row = pygame.Rect(box.x + 8, box.y + 8 + i * 48,
                              box.width - 16, 44)
            if row.collidepoint(pos):
                if i == 1 and not self.has_save:
                    sfx.play("cancel")
                    return
                ui.tap_select(self.index, i,
                              lambda v: setattr(self, "index", v))
                return

    def update(self, dt: float) -> None:
        self.time += dt

    def draw(self, dst: pygame.Surface) -> None:
        dst.fill((12, 12, 40))
        for x, y, size in self.stars:
            tw = 0.4 + 0.6 * abs(math.sin(self.time * 1.5 + x * 0.13))
            c = int(200 * tw)
            dst.fill((c, c, min(255, c + 40)),
                     (x, y, int(size), int(size)))

        # ロゴ: 影付き二重描き + 下線バー
        cx = C.SCREEN_W // 2
        ui.text_center(dst, "JOB QUEST", (cx + 4, 154), 72, (40, 32, 96))
        ui.text_center(dst, "JOB QUEST", (cx, 150), 72, C.COLOR_TEXT_YELLOW)
        pygame.draw.rect(dst, C.COLOR_TEXT_YELLOW, (cx - 220, 192, 440, 4))
        pygame.draw.rect(dst, (40, 32, 96), (cx - 220, 196, 440, 2))
        ui.text_center(dst, "- クリスタルと まおう -", (cx, 218), 26)
        # 草地背景を除いた宝石部分のみ描く
        gem_palette = {k: v for k, v in sprites.TILE_PALETTE.items()
                       if k in "xXsm"}
        pattern = sprites.CRYSTAL if int(self.time * 2) % 2 == 0 \
            else sprites.CRYSTAL2
        crystal = sprites.build(pattern, gem_palette, 4, outline=True)
        dst.blit(crystal, crystal.get_rect(center=(110, 96)))

        # 1人プレイ専用化: タイトルもクリス1人だけを見せる (仲間が
        # まだいるように見えてしまわないよう、旧トリオ表示は廃止)
        chris_img = sprites.hero((88, 120, 216), (240, 112, 56), 6,
                                 job_id="knight")
        bob = int(abs(math.sin(self.time * 3)) * 6)
        dst.blit(chris_img, chris_img.get_rect(
            center=(C.SCREEN_W // 2, 330 - bob)))
        boss = sprites.enemy("boss", 3)
        dst.blit(boss, boss.get_rect(center=(C.SCREEN_W - 130, 90)))

        box = pygame.Rect(C.SCREEN_W // 2 - 170, 420, 340, 110)
        ui.draw_window(dst, box)
        labels = ("さいしょから", "つづきから (ABPひきつぎ)")
        for i, label in enumerate(labels):
            y = box.y + 8 + i * 48
            if i == self.index:
                ui.cursor(dst, (box.x + 24, y + 12))
            color = C.COLOR_TEXT if (i == 0 or self.has_save) \
                else C.COLOR_TEXT_DIM
            ui.text(dst, label, (box.x + 54, y + 12), 22, color)
        if self.best_floor > 0:
            ui.text_center(dst, f"さいしんとうたつ  B{self.best_floor}F",
                           (C.SCREEN_W // 2, 550), 18, C.COLOR_TEXT_YELLOW)

        if int(self.time * 2) % 2 == 0:
            ui.text_center(dst, "タップ / Z で けってい",
                           (C.SCREEN_W // 2, 570), 18, C.COLOR_TEXT_DIM)
        ui.text_center(dst, "スマホは よこもちが おすすめ",
                       (C.SCREEN_W // 2, 592), 14, C.COLOR_TEXT_DIM)
        ui.text_center(dst, build_info.label(), (C.SCREEN_W // 2, 604),
                       12, C.COLOR_TEXT_DIM)
        ui.text_center(dst, "(c) 2026 RYUKO SOFT", (C.SCREEN_W // 2, 614),
                       14, C.COLOR_TEXT_DIM)
