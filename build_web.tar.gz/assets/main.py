"""pygbag entry point.

注意: pygbag はこのファイルのトップレベル import を静的解析して
WASM用パッケージを同梱するので、import pygame は必須。
"""
import asyncio
import sys
from pathlib import Path

import pygame  # noqa: F401  (pygbagのパッケージ検出に必要)

sys.path.insert(0, str(Path(__file__).parent))

from jobquest.main import Game


async def main():
    game = Game()
    await game.run_async()


asyncio.run(main())
